function tempTotalFuelPwr = TotalFuelPwrFunc(DesTrq,y,TestICTrq,z,ICtorqueIndex,fuelrate3,x,UpstreamHeatVal,CD,TestEMTrq,rpm2,RintCD,RintCS,Voc,MaxEMTrq,EMtorqueIndex,eff3,ElecUpstreamEff,GasUpstreamEff,BattEffAssump,EMEffAssump,ICEffAssump)

TestEMTrq = DesTrq(y) - TestICTrq(z);
tempICFuelPwr = interp1(ICtorqueIndex,fuelrate3(x-4,:),TestICTrq(z)) * UpstreamHeatVal; % Upstream Fuel Energy Rate = power ; note- use x-4 index because rpm index for fuelrate3 starts at 800 rpm
tempEMFuelPwr = EMFuelPwr(CD,x,TestEMTrq,rpm2,RintCD,RintCS,Voc,MaxEMTrq,EMtorqueIndex,eff3,ElecUpstreamEff,GasUpstreamEff,BattEffAssump,EMEffAssump,ICEffAssump);
if isinf(tempEMFuelPwr)
   tempTotalFuelPwr = inf;
else
   tempTotalFuelPwr = tempICFuelPwr + tempEMFuelPwr;
end
