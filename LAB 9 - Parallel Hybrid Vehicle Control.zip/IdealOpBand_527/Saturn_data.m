% 1999 Saturn 1.9L DOHC Data
%
% ---- PROPRIETARY GENERAL MOTORS DATA ----
%







%cd('C:\MATLABR11\work')

rpm=[800	1000	1200	1400	1600	1800	2000	2200	2400	2600	2800	3000	3200	3400	3600	3800	4000	4200	4400	4600	4800	5000	5200	5400	5600	5800	6000	6200	6400];
wot_torque=[112.77	120.81	126.99	131.08	136.27	146.88	151.28	151.22	152.72	152.685	152.65	155.055	157.46	155.465	153.47	154.325	155.18	156.685	158.19	158.07	157.95	157.175	156.4	151.985	147.57	141.16	134.75	128.56	122.37];
iol_torque=[102.86	107.17	113.49	115.77	120.39	130.23	136.21	136.36	136.79	137.595	138.4	140.64	142.88	139.81	136.74	132.12	127.5	128.04	128.58	120.845	113.11	105.275	97.44	95.99	94.54	91.585	88.63	78.615	68.6];
iol_throt=[18.68	18.68	21.84	24.18	27.33	35.74	55.22	60.72	59.14	60.52	61.9	63.475	65.05	62.555	60.06	53.115	46.17	48.33	50.49	45.76	41.03	39.285	37.54	38.45	39.36	40.035	40.71	39.03	37.35];

rpm2=[800:50:6400];
wot_torque2 = interp1(rpm,wot_torque,rpm2);
iol_torque2 = interp1(rpm,iol_torque,rpm2);
iol_throt2 = interp1(rpm,iol_throt,rpm2);

M=[rpm2;wot_torque2;iol_torque2;iol_throt2];

% this outputs a WK1 spreadsheet
if ~exist('DoNotOutputData')
   wk1write('iol_data',M)
end


% The data matrices below (data from "Saturn Torque vs TPS (orig from GM).xls")
% are indexed horizonally by the following rpm vector.
% The data is indexed vertically as defined by the 'torque' matrix below
% (WOT in first column, closed throttle in far right column). The increments are -roughly- 10% of max torque.
rpm=[800	1000	1200	1400	1600	1800	2000	2200	2400	2800	3200	3600	4000	4400	4800	5200	5600	6000	6400];

% Output Torque (N-m)
% ----NOTE---- torque matrix is multiplied by 100 to make it integer
torque=100*[
   112.77	102.86	90.57	79.13	68.57	56.57	45.82	34.49	22.56	11.79	4.87	-0.09	-5.47	-19.88
120.81	107.17	95.09	82.32	70.58	59.05	47.44	34.92	23.35	11.86	6.18	-0.03	-5.7	-21.03
126.99	113.49	100.16	87.64	75.29	62.81	50.28	37.79	25.15	12.71	6.66	0.69	-6.23	-21.41
131.08	115.77	103.07	90.87	77.7	64.38	51.79	38.74	25.46	12.67	6.5	-0.44	-7.2	-21.54
136.27	120.39	106.76	93.85	80.01	66.88	53.4	39.67	26.68	13.18	6.75	-0.18	-6.84	-22.53
146.88	130.23	116.33	101.72	87.44	72.45	57.89	43.48	29.39	14.37	6.93	0.23	-7.84	-23.73
151.28	136.21	121.34	105.87	90.91	75.77	60.63	45.56	30.31	14.98	7.69	-0.39	-7.9	-24.72
151.22	136.36	121.49	105.58	90.81	76.23	60.57	45.38	30.52	15.1	7.33	0.42	-7.18	-24.87
152.72	136.79	122.36	106.67	91.32	76.02	60.78	46.24	30.92	15.39	7.08	-0.44	-7.47	-24.9
152.65	138.4	122.69	107.59	92.02	76.76	61.34	46.54	30.78	15.73	7.06	-0.37	-7.35	-25.75
157.46	142.88	126.42	111.15	95.52	79.07	63.35	47.61	31.57	15.38	7.43	0.39	-7.23	-27.61
153.47	136.74	124.6	109.06	93.09	78.02	62.51	46.44	31.16	15.72	7.35	-0.33	-7.29	-30.49
155.18	143.27	127.5	111.37	95.28	79.8	63.47	47.74	31.54	15.71	8	0.04	-7.38	-32.34
158.19	145.22	128.58	113.15	96.84	80.52	64.7	48.59	32.27	16.15	7.86	-0.24	-7.89	-32.45
157.95	145.73	129.2	113.11	96.93	81.05	64.56	48.43	32.61	16.4	8.21	0.26	-8.32	-34.5
156.4	146.96	130.15	113.91	97.44	81.06	64.91	48.89	32.45	16.17	8.3	-0.01	-8.34	-37.58
147.57	141.89	126.05	110.42	94.54	78.84	63.12	46.98	31.44	15.64	8.14	-0.09	-7.7	-40.87
134.75	133.15	118.56	103.72	88.63	74.05	59.19	44.36	29.65	14.75	7.35	-0.18	-7.36	-44.01
122.79	122.37	109.54	96.32	82.2	68.6	54.78	40.98	27.37	13.57	6.79	-0.33	-7.19	-47.32];

% Throttle position (%)
throttle=[
   100	18.68	12.39	9.64	7.68	6.06	4.92	4.2	2.77	2.01	0.95	0.32	0.22	-0.92
100	18.68	14.35	12	9.65	8.12	7.3	6.05	4.56	3.26	2.63	2	0.93	-0.91
100	21.84	16.52	13.58	11.22	9.64	8.06	6.48	5.68	4.21	2.78	2.46	2.02	-0.91
100	24.18	19.47	15.93	13.59	11.92	10.44	8.06	6.48	4.92	4.56	3.28	2.77	-0.92
99.99	27.33	21.04	17.51	14.36	12.37	10.82	9.25	7.29	5.69	4.92	4.21	3.28	-0.92
99.99	35.74	25.75	20.24	17.11	14.35	12.38	10.45	8.86	6.48	5.68	4.92	4.22	-0.89
100	55.22	31.65	23.8	19.48	15.99	13.95	12.01	9.64	7.28	6.49	5.68	4.93	-0.92
99.99	60.72	34.4	26.94	21.83	17.89	15.54	13.54	10.83	8.86	7.66	7.27	5.71	-0.91
99.99	59.14	34.8	27.32	22.23	19.07	15.94	13.97	11.38	9.24	8.05	7.69	6.07	-0.91
99.99	61.9	38.35	30.45	25.34	21.05	18.44	15.53	13.54	10.82	9.25	8.16	7.31	-0.92
100	65.05	45.81	34.8	28.74	23.8	20.65	17.52	14.37	12.02	10.41	9.24	8.08	-0.93
100	60.06	41.95	34.42	29.74	26.54	23.3	19.46	16.73	13.95	12.4	11.21	10.44	-0.91
100	51.28	46.17	36.76	31.97	28.42	24.86	21.03	17.91	15.2	13.96	12.59	11.21	-0.92
100.01	55.01	50.49	39.12	34.27	30.07	26.53	23.39	20.24	16.74	15.54	14.32	12.38	-0.91
99.98	57.56	44.24	41.03	35.93	31.64	28.08	24.62	21.85	17.96	17.11	15.53	13.89	-0.92
99.99	68.07	47.92	41.1	37.54	33.28	29.69	26.5	22.62	19.48	17.93	16.75	15.16	-0.91
99.97	70.68	50.56	43.05	39.36	34.8	31.21	27.05	23.71	20.25	18.68	17.11	15.16	-0.91
99.99	86.82	53.16	44.61	40.71	36.29	32.81	28.9	24.92	21.17	19.47	17.9	15.97	-0.92
100.01	100	55.6	47	40.95	37.35	33.6	30.34	26.62	23.41	21.61	19.47	17.92	-0.91];
% normalize throttle from 0 to 100 (eliminate negative throttles in data)
minthrot=min(min(throttle));
maxthrot=max(max(throttle));
scalethrot=maxthrot-minthrot;
throttle=throttle-minthrot;
throttle=throttle/scalethrot*100;

% BSFC (g/kWh)
bsfc=[
   327.7	292.5	294.2	298.7	300.9	311.5	328.3	373.9	476.3	729.0	1588.9	inf	inf	inf
329.7	275.6	278.1	283.6	287.1	296.6	318.5	363.9	441.2	695.0	1222.6	inf	inf	inf
309.0	265.1	268.9	274.7	277.9	287.4	307.8	348.9	421.7	676.4	1118.9	9551.7	inf	inf
294.0	250.3	254.9	259.4	265.4	274.6	298.7	329.6	405.1	639.6	1133.3	inf	inf	inf
291.6	244.5	249.6	254.1	260.5	273.1	293.7	330.4	394.6	619.6	1082.5	inf	inf	inf
275.9	241.7	242.7	247.6	253.1	266.0	286.7	315.9	376.5	584.2	1073.7	29035.7	inf	inf
264.8	240.9	240.7	241.8	249.5	260.8	277.8	309.2	374.2	562.0	983.0	inf	inf	inf
259.5	240.6	239.3	244.3	249.6	260.7	281.2	310.6	368.7	580.6	1045.8	16375.4	inf	inf
270.1	242.0	240.0	244.4	252.6	265.7	282.8	312.9	375.3	586.4	1153.7	inf	inf	inf
280.6	240.3	240.9	246.4	254.6	267.0	288.0	319.0	382.6	577.1	1112.4	inf	inf	inf
278.8	240.6	241.3	245.5	253.0	266.2	284.8	313.5	377.6	579.7	1025.8	17316.7	inf	inf
283.0	244.5	244.6	249.6	259.7	274.3	295.1	325.0	389.2	589.6	1065.6	inf	inf	inf
291.3	298.8	248.7	253.9	262.5	275.6	297.8	329.3	397.7	612.6	1052.8	184778.9	inf	inf
297.2	303.4	259.4	258.2	266.1	282.2	304.2	335.8	406.5	633.4	1142.4	inf	inf	inf
312.8	312.4	308.0	263.2	271.8	287.0	307.1	343.1	417.1	646.1	1142.3	32222.8	inf	inf
329.9	344.7	337.4	343.7	276.2	292.0	312.8	347.6	426.0	670.6	1155.2	inf	inf	inf
349.0	355.2	353.6	360.7	286.4	303.6	327.8	368.5	449.1	714.4	1206.8	inf	inf	inf
369.7	379.5	374.5	379.4	299.9	318.8	349.5	392.8	489.0	784.8	1364.4	inf	inf	inf
376.7	368.3	371.2	379.5	390.5	341.5	372.8	428.5	537.6	878.5	1557.8	inf	inf	inf];

% Fuel consumption rate (g/s)
fuelrate=[
0.86	0.7	0.62	0.55	0.48	0.41	0.35	0.3	0.25	0.2	0.18	0.16	0.15	0
1.16	0.86	0.77	0.68	0.59	0.51	0.44	0.37	0.3	0.24	0.22	0.19	0.17	0
1.37	1.05	0.94	0.84	0.73	0.63	0.54	0.46	0.37	0.3	0.26	0.23	0.21	0
1.57	1.18	1.07	0.96	0.84	0.72	0.63	0.52	0.42	0.33	0.3	0.26	0.23	0
1.85	1.37	1.24	1.11	0.97	0.85	0.73	0.61	0.49	0.38	0.34	0.3	0.27	0
2.12	1.65	1.48	1.32	1.16	1.01	0.87	0.72	0.58	0.44	0.39	0.35	0.3	0
2.33	1.91	1.7	1.49	1.32	1.15	0.98	0.82	0.66	0.49	0.44	0.4	0.35	0
2.51	2.1	1.86	1.65	1.45	1.27	1.09	0.9	0.72	0.56	0.49	0.44	0.37	0
2.88	2.31	2.05	1.82	1.61	1.41	1.2	1.01	0.81	0.63	0.57	0.5	0.42	0
3.49	2.71	2.41	2.16	1.91	1.67	1.44	1.21	0.96	0.74	0.64	0.56	0.48	0
4.09	3.2	2.84	2.54	2.25	1.96	1.68	1.39	1.11	0.83	0.71	0.63	0.56	0
4.55	3.5	3.19	2.85	2.53	2.24	1.93	1.58	1.27	0.97	0.82	0.73	0.65	0
5.26	4.98	3.69	3.29	2.91	2.56	2.2	1.83	1.46	1.12	0.98	0.86	0.74	0
6.02	5.64	4.27	3.74	3.3	2.91	2.52	2.09	1.68	1.31	1.15	1.02	0.87	0
6.9	6.36	5.56	4.16	3.68	3.25	2.77	2.32	1.9	1.48	1.31	1.17	0.97	0
7.81	7.66	6.64	5.92	4.07	3.58	3.07	2.57	2.09	1.64	1.45	1.28	1.08	0
8.39	8.21	7.26	6.49	4.41	3.9	3.37	2.82	2.3	1.82	1.6	1.4	1.23	0
8.7	8.82	7.75	6.87	4.64	4.12	3.61	3.04	2.53	2.02	1.75	1.55	1.37	0
8.39	8.61	7.57	6.8	5.98	4.36	3.8	3.27	2.74	2.22	1.97	1.73	1.51	0];

%%% END OF DATA


% set up fixed increment index for torque direction
mint=min(min(torque));
maxt=max(max(torque));
%  NOTE- using 40 indices in the torque direction is insufficient- resulted in jumps of 10% throttle per index.. need to interpolate in torque direction (using lookup would require about 400 elements in torque direction)
%  -- the same holds for the rpm direction- using 20 indices in rpm direction results in jumps of 10% throttle per index.. also need to interpolate in rpm direction
%  ---->>>> USE INTEGER INTERPOLATION IN SATURN.CPP
%  with interpolation: 
%  -- 40 indices in torque direction looks OK -- then if torque request is over 97%, just set to 100% throttle (otherwise you won't get there due to interpolation)
%     -- set NAN's to zero or 100; rescale throttle from 0 to 100 (eliminate negative throttles in data); scale max throttle to 255
%  -- 30 indices (every 200 rpm) in rpm direction looks OK -- need to further interpolate below to get 200 rpm increments
mint;
inct=round((maxt-mint)/40);
maxt=mint+inct*40;
TorqueIndex=[mint:inct:maxt];  % input torque


% -- SET UP THROTTLE MATRIX --
% interpolate to scale throttle matrix to TorqueIndex
for i=1:length(rpm)
   %% could use 2nd order parabolic spline (spline toolbox??)
   throttle2(i,:) = interp1(torque(i,:),throttle(i,:),TorqueIndex,'linear');   % output throttle
end

% NaN's show up in throttle2 because interp1 does not extrapolate.  Set NaN's to 0 at low rpm, 100 at high rpm
throtsize=size(throttle2);
for x=1:throtsize(1)
   for y=1:throtsize(2)
      if isnan(throttle2(x,y))
         if y<20
            throttle2(x,y)=0;
         else
            throttle2(x,y)=100;
         end
      end
   end
end

% rpm=[800	1000	1200	1400	1600	1800	2000	2200	2400	2800	3200	3600	4000	4400	4800	5200	5600	6000	6400];
rpm2=[800:200:6000];

% interpolate to scale throttle2 matrix to rpm2 index
% Note-- throttle3 is indexed by inct horizontally and rpm2 vertically
throttle3 = interp1(rpm,throttle2,rpm2);

% this outputs a WK1 spreadsheet
if ~exist('DoNotOutputData')
   wk1write('throttle3',throttle3)
end

% -- SET UP BSFC MATRIX --
% interpolate to scale BSFC matrix to TorqueIndex
for i=1:length(rpm)
   %% could use 2nd order parabolic spline (spline toolbox??)
   bsfc2(i,:) = interp1(torque(i,:),bsfc(i,:),TorqueIndex,'linear');
end

% NaN's show up in bsfc2 because interp1 does not extrapolate.  Set NaN's to 30000 at low rpm, 400 at high rpm
bsfcsize=size(bsfc2);
for x=1:bsfcsize(1)
   for y=1:bsfcsize(2)
      if isnan(bsfc2(x,y))
         if y<20
            bsfc2(x,y)=30000;
         else
            bsfc2(x,y)=400;
         end
      end
   end
end

% interpolate to scale bsfc2 matrix to rpm2 index
% Note-- bsfc3 is indexed by inct horizontally and rpm2 vertically
bsfc3= interp1(rpm,bsfc2,rpm2);

% this outputs a WK1 spreadsheet
if ~exist('DoNotOutputData')
   wk1write('bsfc3',bsfc3)
end

% -- SET UP FUEL RATE MATRIX --
% interpolate to scale fuel rate matrix to TorqueIndex
for i=1:length(rpm)
   %% could use 2nd order parabolic spline (spline toolbox??)
   fuelrate2(i,:) = interp1(torque(i,:),fuelrate(i,:),TorqueIndex,'linear');
end

% NaN's show up in fuelrate2 because interp1 does not extrapolate.  Set NaN's to 0 at low rpm, max at high rpm
fuelratesize=size(fuelrate2);
for x=1:fuelratesize(1)
   firstnan=1;
   for y=1:fuelratesize(2)
      if isnan(fuelrate2(x,y))
         if y<20
            fuelrate2(x,y)=0;
         else
            if firstnan
               fuelrate2(x,y) = spline(TorqueIndex(1:y-1),fuelrate2(x,1:y-1),TorqueIndex(y));  % unlike interp1, spline extrapolates; use vector of fuelrate at same rpm to extrapolate last element
            else               
               fuelrate2(x,y) = max(max(fuelrate));
            end
            firstnan=0;
         end
      end
   end
end

% interpolate to scale fuelrate2 matrix to rpm2 index
% Note-- fuelrate3 is indexed by inct horizontally and rpm2 vertically
fuelrate3= interp1(rpm,fuelrate2,rpm2);

% this outputs a WK1 spreadsheet
if ~exist('DoNotOutputData')
   wk1write('fuelrate3',fuelrate3)
end