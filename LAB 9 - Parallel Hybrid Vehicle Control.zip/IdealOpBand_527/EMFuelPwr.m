function tempEMFuelPwr = EMFuelPwr(CD,x,TestEMTrq,rpm2,RintCD,RintCS,Voc,MaxEMTrq,EMtorqueIndex,eff3,ElecUpstreamEff,GasUpstreamEff,BattEffAssump,EMEffAssump,ICEffAssump)

if (TestEMTrq >= -MaxEMTrq(x)) & (TestEMTrq <= MaxEMTrq(x))
   if CD
      Rint=RintCD;
   else
      Rint=RintCS;
   end
   tempEMPwr = TestEMTrq * rpm2(x) * .1047;
   tempCurrent = min(roots([Rint -Voc tempEMPwr]));
   if rpm2(x) == 0
      tempEMFuelPwr = 407.5;	% use as proxy: running losses (W) at zero load of UQM 218 at 3000 rpm (ref RW Carlson thesis, Fig 3.4)
   else   
      if TestEMTrq > 0	% depleting
         tempEMEff = interp1(EMtorqueIndex,eff3(x,:),TestEMTrq)/100 * tempEMPwr/(tempEMPwr + tempCurrent^2 * Rint); % tempEMPwr/(tempEMPwr + tempCurrent^2 * Rint)  is the battery efficiency
         if CD
            tempEMFuelPwr = tempEMPwr / tempEMEff / ElecUpstreamEff;
         else	% CS
            tempEMFuelPwr = tempEMPwr / tempEMEff / BattEffAssump / EMEffAssump / ICEffAssump / GasUpstreamEff;
         end
      elseif TestEMTrq < 0		% generating
         tempEMEff = interp1(EMtorqueIndex,eff3(x,:),-TestEMTrq)/100*0.95 * (tempEMPwr + tempCurrent^2 * Rint)/tempEMPwr; % assume regen efficiency is 95% of map efficiency; (tempEMPwr - tempCurrent^2 * Rint)/tempEMPwr  is the battery efficiency during charge
         if CD
            tempEMFuelPwr = tempEMPwr * tempEMEff / ElecUpstreamEff;	% energy is valued at well; calculate losses to tranmission, then calculate avoided energy use at later time
            % the above is a simplification of the following energy conversion stream
            % tempEMFuelPwr = tempEMPwr * tempEMEff * BattEffAssump * EMEffAssump / EMEffAssump / BattEffAssump / ElecUpstreamEff;
         else	% CS
            tempEMFuelPwr = tempEMPwr * tempEMEff * BattEffAssump * EMEffAssump / ICEffAssump / GasUpstreamEff;
         end
      else
         tempEMFuelPwr = 407.5;	% running losses (W) at zero load of UQM 218 at 3000 rpm (ref RW Carlson thesis, Fig 3.4)
      end
   end
else
   tempEMFuelPwr = inf;
end
