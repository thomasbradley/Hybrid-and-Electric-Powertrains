% Matlab script to determine the instantaneously optimal powertrain operation of Sequoia (an all-electric capable in-line HEV powertrain)
%   The script calculates:	(1) optimal engine and electric motor torque while constrained to a hybrid state, based on an instantaneous minimization of full fuel-cycle power consumption
%									(2) optimal engine engagement state (engaged/hybrid or disengaged/all-electric)
%
% by Rob Schurhoff  3/8/02
% modified by Thomas Bradley to represent MECH 527 Simulation 10.23.17
%
close all
clear



% This script requires the files 'Saturn_data.m', 'EMFuelPwr.m' and 'TotalFuelPwrFunc.m' to be on the same Matlab path.

CD = 0
% Before calling this m-file, set the 'CD' variable to 1 if charge-depleting, 0 if charge-sustaining
if exist('CD')~=1
   error('Need to set CD variable')
else if CD==0
      disp('-- Running algorithm for charge-sustaining operation --')
   else if CD==1
         disp('-- Running algorithm for charge-depleting operation --')
      else
         error('Invalid setting for CD variable')
      end
   end
end

%%%%%%%%% SET UP ENGINE DATA %%%%%%%%%%%
% Data for Saturn 1.9L DOHC engine
% data from "Saturn Torque vs TPS (orig from GM).xls"

% this is maximum (wide-open-throttle) engine torque
rpm=[800	1000	1200	1400	1600	1800	2000	2200	2400	2600	2800	3000	3200	3400	3600	3800	4000	4200	4400	4600	4800	5000	5200	5400	5600	5800	6000	6200	6400];
wot_torque=[112.77	120.81	126.99	131.08	136.27	146.88	151.28	151.22	152.72	152.685	152.65	155.055	157.46	155.465	153.47	154.325	155.18	156.685	158.19	158.07	157.95	157.175	156.4	151.985	147.57	141.16	134.75	128.56	122.37];
rpm2=[0:200:6000];
ICWOTtorque = interp1(rpm,wot_torque,rpm2);	% indexed by rpm2
for x=1:length(ICWOTtorque)
   if isnan(ICWOTtorque(x))
      ICWOTtorque(x) = 0;
   end
end

% this is minimum (closed-throttle) engine torque
rpm=[800	1000	1200	1400	1600	1800	2000	2200	2400	2800	3200	3600	4000	4400	4800	5200	5600	6000	6400];
ct_torque=[-19.88 -21.03 -21.41 -21.54 -22.53 -23.73 -24.72 -24.87 -24.9 -25.75 -27.61 -30.49 -32.34 -32.45 -34.5 -37.58 -40.87 -44.01 -47.32];
rpm2=[0:200:6000];
ICCTtorque = interp1(rpm,ct_torque,rpm2);	% indexed by rpm2
for x=1:length(ICCTtorque)
   if isnan(ICCTtorque(x))
      ICCTtorque(x) = 0;
   end
end


%% RETREIVE ENGINE DATA from Saturn_data.m (proprietary engine data)
DoNotOutputData=0;
Saturn_data
clear DoNotOutputData;
ICtorque=torque/100;
clear torque;
ICtorqueIndex=TorqueIndex/100;
clear TorqueIndex;


%%%%%%%%% SET UP MOTOR DATA %%%%%%%%%%%
% Data for UQM CaliberEV 53 motor-controller system calibrated to 75 kW
%   UQM SR218N motor and CA40-300L controller
% data from ADVISOR file:  MC_PM32ev; edited by UC Davis using data from UQM CaliberEV53 specification sheet

% max torque in 200 rpm increments
MaxEMTrq = [240.00, 240.00, 240.00, 240.00, 240.00, 240.00, 240.00, 240.00, 240.00, 240.00,240.00, 240.00, 240.00, 240.00, 240.00, 238.73, 223.81, 210.65, 198.94, 188.47,179.05, 170.52, 162.77, 155.70, 149.21, 143.24, 137.73, 132.63, 127.89, 123.48,119.37];

rpm=[0	1200	1500	2000	2500	3000	3500	4000	4500	5000	6000	7000	7500];
EMtorque=[0	5	25	50	75	100	125	150	175	200	225 250];  % input torque

% the following matrix is indexed by rpm in rows, by torque in columns
eff=[
60	80.5	85	88	88	86	85	86	80	79	79 79
60	80.5	85	88	88	86	85	86	80	79	79 79
60	81	85	89	89	88	87	86	82	80	79.5 79.5
60	80	87	90	90.5	90	89	88	86	85	83 83
60	78	88	91.5	91.5	91	91	90	89	86	85 85
60	79	91	92.5	93	92.5	92	91	90	87	87 87
60	79	93	94	93.5	93	93	92	90	90	90 90
60	86	93	94	94	93	92.5	92	92	92	92 92
60	79	90	92	93	92	91	91	91	91	91 91
60	79	86	91	92	92	92	92	92	92	92 92
60	77.5	86	91	92	92	92	92	92	92	92 92
60	77.5	83	90	90.5	90.5	90.5	90.5	90.5	90.5	90.5 90.5
60	77.5	81	90	90	90	90	90	90	90	90 90];


rpm2=[0:200:6000];
EMtorqueIndex=[0:5:250];	% above 50 N-m, the spacing could be 25 N-m, but the 5 N-m increment is simpler

% -- now set up efficiency matrix --
% interpolate to scale original matrix to EMtorqueIndex
for i=1:length(rpm)
   eff2(i,:) = interp1(EMtorque,eff(i,:),EMtorqueIndex,'linear');   % output throttle
end

% interpolate to scale eff2 matrix to rpm2 index
% Note-- eff3 is indexed by EMtorqueIndex horizontally and rpm2 vertically
eff3= interp1(rpm,eff2,rpm2);


%%%%%%%%% COMBINED REAR POWERTRAIN DATA %%%%%%%%%%%

% max powertrain torque in 200 rpm increments
MaxRearTrq= [ 240.0, 240.0, 240.0, 240.0, 352.77,360.81,366.99,371.08,376.27,386.88,391.28,391.22,392.72,392.685,392.65,393.7874146,382.5505624,366.9137101,352.9820894,343.6057002,334.229311,327.7765638,321.3238167,314.0418442,307.5556465,300.4144488,294.4307416,284.8070343,275.617386,264.8667967,254.1162073 ];



%%%%%%%%% OPTIMAL ENERGY CONSUMPTION ALGORITHM %%%%%%%%%%%


% rpm2 is x index of table (first index)
DesTrq=[-240:5:400];		% This is desired torque -- y index of table (second index)

OptICTorque=zeros(length(rpm2),length(DesTrq));
OptEMTorque=zeros(length(rpm2),length(DesTrq));
TotalFuelPwr=zeros(length(rpm2),length(DesTrq));
EMOnlyFuelPwr=zeros(length(rpm2),length(DesTrq));
UseIC=zeros(length(rpm2),length(DesTrq));

BattChgEff = 0.951;		% efficiency of battery during recharge from charger (see thesis calcs)
ChargerEff = 0.88;		% battery charger eff (EPRI report TR1000349, p.4-11)
GenEff = 0.389;			% national-average Combined power generation, trans & distribution efficiency (Source: GREET 1.5a)
ElecUpstreamEff = BattChgEff * ChargerEff * GenEff;
EMEffAssump = 0.9;		% assumed electric motor efficiency, used in valuing regenerated energy
BattEffAssump = 0.96;	% assumed battery charge or discharge efficiency for valuing regenerated energy
ICEffAssump = 0.32;		% assumed engine efficiency while charge-sustaining
% ess_r_dis=[1.167 0.631	0.594	0.552	0.541	0.530	0.523	0.536	0.574	0.615	0.585]/1000; % from Advisor ESS_NIMH90_OVONIC.m (from Ovonic data)
RintCD = 0.08;		% ohms, assumed total internal resistance of battery pack in CD mode: average internal resistance from 20% to 100% SOC
RintCS = 0.08;		% ohms, assumed total internal resistance of battery pack in CS mode: internal resistance at 20% SOC
Voc = 345;		% assumed open-circuit voltage during operation
HeatVal = 43500; % J/g
GasUpstreamEff = 0.815;	% from GREET 1.5a
UpstreamHeatVal = HeatVal / GasUpstreamEff;
GasEff = HeatVal/3600000/GasUpstreamEff;	% kWh/gram

disp('Processing RPM:')
for x=1:length(rpm2)			% note index 1 is rpm=0
   disp(rpm2(x));
   for y=1:length(DesTrq)	% torque is desired torque
      if (DesTrq(y) <= MaxRearTrq(x)) & (DesTrq(y) >= -MaxEMTrq(x)) 
      
         if ICWOTtorque(x) > 0
            TestICTrq = [ICCTtorque(x):(ICWOTtorque(x)-ICCTtorque(x))/15:ICWOTtorque(x)];
            clear tempTotalFuelPwr;
            for z=1:16				% scan 16 test values of IC torque
               tempTotalFuelPwr(z) = TotalFuelPwrFunc(DesTrq,y,TestICTrq,z,ICtorqueIndex,fuelrate3,x,UpstreamHeatVal,CD,TestEMTrq,rpm2,RintCD,RintCS,Voc,MaxEMTrq,EMtorqueIndex,eff3,ElecUpstreamEff,GasUpstreamEff,BattEffAssump,EMEffAssump,ICEffAssump);
            end	% end of for z=1:16
            
            % find IC operating point with lowest energy consumption
            minPwr=min(tempTotalFuelPwr);
            minPwrIndex=find(tempTotalFuelPwr==minPwr);
            if length(minPwrIndex) > 1
               minPwrIndex=minPwrIndex(1);
            end
            % for next z loop, set minPwrIndex2 to index of second-to-lowest energy consumption
            % if the lowest energy consumption is at the end of the vector, set minPwrIndex2 to nearest index
            if minPwrIndex > 1
               if minPwrIndex < 16
                  if tempTotalFuelPwr(minPwrIndex-1) < tempTotalFuelPwr(minPwrIndex+1)
                     minPwrIndex2 = minPwrIndex-1;
                  else
                     minPwrIndex2 = minPwrIndex+1;
                  end
               else
                  minPwrIndex2 = 15;
               end
            else
               minPwrIndex2 = 2;
            end
            
            %%  Now scan 11 test values around the best from the first scan
            TestICTrq = [TestICTrq(minPwrIndex):(TestICTrq(minPwrIndex2) -TestICTrq(minPwrIndex))/10:TestICTrq(minPwrIndex2)];
            clear tempTotalFuelPwr;
            for z=1:11
               tempTotalFuelPwr(z) = TotalFuelPwrFunc(DesTrq,y,TestICTrq,z,ICtorqueIndex,fuelrate3,x,UpstreamHeatVal,CD,TestEMTrq,rpm2,RintCD,RintCS,Voc,MaxEMTrq,EMtorqueIndex,eff3,ElecUpstreamEff,GasUpstreamEff,BattEffAssump,EMEffAssump,ICEffAssump);
            end	% end of for z=1:11
            
            % find IC operating point with lowest energy consumption
            minPwr=min(tempTotalFuelPwr);		% this is the least energy consumption
            minPwrIndex=find(tempTotalFuelPwr==minPwr);
            if length(minPwrIndex) > 1
               minPwrIndex=minPwrIndex(1);
            end
            
            OptICTorque(x,y)=TestICTrq(minPwrIndex);
            
            % now check to see if disengaging engine would use less energy (does not affect optimal IC, EM matrices)
            TestEMTrq = DesTrq(y);
            EMOnlyFuelPwr(x,y) = EMFuelPwr(CD,x,TestEMTrq,rpm2,RintCD,RintCS,Voc,MaxEMTrq,EMtorqueIndex,eff3,ElecUpstreamEff,GasUpstreamEff,BattEffAssump,EMEffAssump,ICEffAssump);
            if minPwr < EMOnlyFuelPwr(x,y)
               UseIC(x,y) = 1;
            end
         else		% ICWOTtorque(x) is zero, i.e. the engine rpm is below idle
            OptICTorque(x,y)=0;
            TestEMTrq = DesTrq(y);
            EMOnlyFuelPwr(x,y) = EMFuelPwr(CD,x,TestEMTrq,rpm2,RintCD,RintCS,Voc,MaxEMTrq,EMtorqueIndex,eff3,ElecUpstreamEff,GasUpstreamEff,BattEffAssump,EMEffAssump,ICEffAssump);
            minPwr=EMOnlyFuelPwr(x,y);
         end		% END OF if ICWOTtorque(x) > 0
         OptEMTorque(x,y) = DesTrq(y) - OptICTorque(x,y);
         if (OptEMTorque(x,y) >= -MaxEMTrq(x)) & (OptEMTorque(x,y) <= MaxEMTrq(x))
            TotalFuelPwr(x,y)=minPwr;
         else
            OptICTorque(x,y)=0;
            OptEMTorque(x,y)=0;         
            TotalFuelPwr(x,y)=0;
         end
      else
         if (DesTrq(y) > 0) & ((DesTrq(y-1)) <= MaxRearTrq(x))		% when the desired torque is near the maximum powertrain torque, this allows PCM to round up the desired torque in its lookup table and get a non-zero value
	         OptICTorque(x,y)=OptICTorque(x,y-1);
            OptEMTorque(x,y)=OptEMTorque(x,y-1);
            TotalFuelPwr(x,y)=TotalFuelPwr(x,y-1);
         else
	         OptICTorque(x,y)=0;
            OptEMTorque(x,y)=0; 
            TotalFuelPwr(x,y)=0;
         end
      end			% END OF if (DesTrq(y) <= MaxRearTrq(x)) & (DesTrq(y) >= -MaxEMTrq(x)) 
   end
end





figure; hold on ; 
[c,h] = contourf(rpm2,DesTrq,OptICTorque',20);
clabel(c,h)
xlabel('Powertrain Speed, rpm')
ylabel('Desired Powertrain Output Torque, Nm')
title('Optimal Engine Torque')


figure; hold on ; 
[c,h] = contourf(rpm2,DesTrq,UseIC',20);
clabel(c,h)
xlabel('Powertrain Speed, rpm')
ylabel('Desired Powertrain Output Torque, Nm')
title('Optimal Engine on/off State')

figure; hold on ; 
[c,h] = contourf(rpm2,DesTrq,OptEMTorque',20);
clabel(c,h)
xlabel('Powertrain Speed, rpm')
ylabel('Desired Powertrain Output Torque, Nm')
title('Optimal Motor Torque')

OptimalControlData = rpm2, DesTrq, OptICTorque, UseIC
save('OptimalController', 'rpm2', 'DesTrq', 'OptICTorque', 'UseIC')
