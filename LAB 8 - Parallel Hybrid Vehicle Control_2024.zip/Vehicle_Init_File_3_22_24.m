
% Series Electric Vehicle Init File
clc
clear variables

%Drive Cycle
%load Drive_Cycles/Schedule_FU505_Ten_Times.mat
load Schedule_FU505.mat;
Sch_Cycle = [Sch_Cycle;Sch_Cycle;Sch_Cycle;Sch_Cycle;Sch_Cycle;Sch_Cycle;Sch_Cycle;Sch_Cycle;Sch_Cycle;Sch_Cycle]
Sch_Cycle(:,1) = [1:length(Sch_Cycle)];
%load Drive_Cycles/Schedule_Boston_Cab.mat;

%load Drive_Cycles/Schedule_Boston_Cab.mat;

%Vehicle Parameters
Vehicle_Mass = 1200;                %Vehicle mass, kg
Vehicle_Tire_Radius = 0.3;          %Tire radius, m
Vehicle_DShaft_Inertia = 1.5e-3;    %Driveshaft Inertia, kg m^2
Vehicle_Dr_HShaft_Inertia = 1.5e-3; %Driver Halfshaft Inertia, kg m^2
Vehicle_Pa_HShaft_Inertia = 1.5e-3; %Passenger Halfshaft Inertia, kg m^2
Vehicle_Rear_Diff_Ratio = 3.73;        %Rear Diff Ratio

%MG Parameters

MG_Inertia = 0.1;                   %MG Moment of inertia in kg m^2
MGA_Max_Torque = 200;               %MGA Max Torque, Nm
MGB_Max_Torque = 200;               %MGB Max Torque, Nm

%Logging Parameters
Logging_Sample_Time_s = 1;

%Battery Parameters
Battery_Voltage = 345;                  %Battery Open Circuit Voltage, V
Battery_Resistance = 0.06;           %Ohms
Battery_Capacity = 8.5;             %Battery Max Capacity, Ahr
Battery_Initial_SOC = 0.5;          %Battery Initial State of Charge (SOC)
Battery_Accessory_Load = 500;       % HV electrical load, W

%Controller Parameters
battery_soc_low = 0.1;              %Battery SOC Low Value
battery_soc_high = 0.3;             %Battery SOC High Value

%Engine Parameters
Engine_map_maker
% Engine_torque_goal_series = 50 ; %Nm
% Engine_speed_goal_series = 200 ; %rad/sec


close all


