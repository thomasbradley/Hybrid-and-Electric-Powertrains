%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: fd_393_prius.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% final drive														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 11/05/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% A.Rousseau (ANL) - 11/17/99 - add the final loss table calculation%
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fd_ratio_i_p		= 3.93;            % will be optimized in scaling algorithm
fd_inertia_i_p		= 0.05;
fd_mass				= 10;
fd_spd_thresh_i 	= 10;

fd_trq_eff_index    = [51.40,52.40,104.7,157.1,209.4,261.8,314.2,366.5,418.9,471.2,523.6];;
fd_spd_eff_index    = [0.500,6.000,33.90,67.80,101.7,135.6,169.5,203.4,237.3,271.2,305.1,339];
fd_eff_trq_map      = ones(size(fd_trq_eff_index,2),size(fd_spd_eff_index,2)).* 0.86;

fd_trq_loss_index   = fd_trq_eff_index;
fd_spd_loss_index   = fd_spd_eff_index;
fd_trq_loss_map     = zeros(length(fd_trq_loss_index), length(fd_spd_loss_index));

% create final drive loss tables
for i=1:size(fd_trq_loss_index,2)
   for j=1:size(fd_spd_loss_index,2)
      fd_trq_loss_map(i,j) = (1-fd_eff_trq_map(i,j))*fd_trq_loss_index(i);	
   end
end

% calculate the maximum efficiency 
fd_eff_max=max(max(fd_eff_trq_map));
