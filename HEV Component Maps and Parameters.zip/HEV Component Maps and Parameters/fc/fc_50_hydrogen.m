%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: fc_50_hydrogen.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: DIRECT HYDROGEN FUEL CELL     		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: S.Buyuktur - ANL						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: Dr. Romesh Kumar, Argonne National Lab	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% 	(1)	A.Rousseau (ANL) - 01/24/00 - delete all the parameter		%
% 			scaling_ratio that is useless in the initialization file%
%	(2)	G.Monnet - 01/24/00 - Separation, fuel cell and fuel cell.	%
%		acessories initialisation file(deleting all the accesories 	%
%			parameters)												%
% 	(3)Xi Wei - 08/02/00 - maximum power and efficiency calculation	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fc_tau_i_p    			= 0.2;                  %  transient load delay for first order lag
fc_spd_launch 			= 0;                    % not used this phase
fc_temp_tau_hot_i_p     = 600;
fc_temp_tau_cold_i_p	= 1800;
fc_warmup_init_i_p 	    = 0;
accmech_mass 			= 20;
fc_mass       			= 100.4 ; 
fc_mass_vol 			= 50.0;						% Capacity of tank in kg

% Only here to satisfy dependencies in other models.  
eng_spd_idle       			= 0;  %temporary for sft
fc_displ_init     	    = 0; 
fc_spd_opt_i_p          = 0;
fc_fuel_carbon_ratio    = 0.0;
fc_co2_init 			= 0.0;

% Define the following variable to satisfy the series power controller's dependency on an optimal point
fc_pwr_opt 				= 23700 ; % from the tables provided by ANL, max eff; W (7/7/00)

% Fuel Parameters 
fc_fuel_density_val     = 18;            % kg/m3 or g/L
fc_fuel_heating_val   = 120000000;     % J/kg; specific LHV of Hydrogen
fc_fuel_carbon_ratio = 0.0;              % since fuel is H2, this for

% Hot power
fc_pwr_hot_index   	= [ 0   5   7.5 10  20  30  40  50] * 1000; % W
fc_pwr_hot_max 		= max(fc_pwr_hot_index);           % Max DC power of fuel cell, W
fc_h2_hot_map 		= [0.012    0.085   0.117   0.149  0.280    0.423   0.594   0.821  ] /1000;             % kg/s;

% Cold power
fc_pwr_cold_index   = [ 0   5   7.5 10  20  30  37.7] * 1000;          % W
fc_pwr_cold_max 	= max(fc_pwr_cold_index); % Max DC power of fuel cell, W
fc_h2_cold_map 		= [ 0.011   0.085	  0.120   0.154  0.303   0.500   0.869 ] /1000;           % kg/s converted from g/s;

% Polarization Curves
fc_stck_curr_hot_index 	= [ 7.6 55.6 76.9 97.9 183.5 277.3 389.1 538.5 ];      % A
fc_stck_volt_hot_map 	= [ 143.3 134 131.8 130 123.5 117.2 110 100 ];           % V
fc_stck_curr_cold_index = [ 7.4 56 78.5 100.9 198.8 327.7 570 ]; 
fc_stck_volt_cold_map 	= [ 143.1 131.7 128.5 125.6 114.3 100.6 74.68 ];

% Power vs Voltage values                             % <------------- from data provided by ANL (10/04/00 - Selim)
fc_power_index 		= [ 0.443 0.7107 0.9662 1.481 2.046 5.165 10.12 19.67 36.44 52.51 67.71 80.00]* 1000;                % W
fc_ucell_volt_map 	= [ 0.9260 0.9190 0.9120 0.9059 0.9041 0.8936 0.8761 0.8409 0.7829 0.7554 0.7280 0.7004 ];        % V/cell 
fc_nb_cell 			= 400;  % later put it in the test file (fc_nb_cell = gui_*)

fc_h2_hot_max       = max(fc_h2_hot_map) ; % Direct hydrogen PEM fuel cell warmup factors
fc_mass 			= 1.6*fc_pwr_hot_max/1000 ;     %1.6 kg/kW
fc_pwr_max			= max(fc_pwr_hot_index);% maximum power calculation

% Hot accessory power
accmech_pwr_hot_pump     	  = [0.587  0.697   0.727   0.752  0.880  0.942  1.020  1.443  ] *1000;   % W; pump/fan
accmech_pwr_hot_compressor    = [0.46   1.90   2.21   2.42  3.15   4.01   5.37   7.44    ] *1000;   % W; compressor
accmech_pwr_hot_expander      = [ 0.02   0.21   0.34   0.51  1.37   2.45   3.60   4.99    ] *1000;   % W; expander
accmech_pwr_hot_radiator      = [ 0.59   3.90   5.34   6.77 13.16  21.25  32.50  50.29   ] *1000;   % W; radiator duty

% Cold accesory power
accmech_pwr_cold_pump 			= [ 0.616  0.616  0.616 0.616 0.616 0.616   0.616]*1000;       	% W; pump/fan
accmech_pwr_cold_compressor	    = [ 0.45   1.91   2.22  2.44  3.24   4.52   7.87 ]*1000;        % W; compressor
accmech_pwr_cold_expander		= [ 0.01   0.15   0.25  0.38  1.10   2.18   4.79 ]*1000;        % W; expander
accmech_pwr_cold_radiator		= [ 0.00   0.00   0.00  0.00  0.00   0.00   0.00 ]*1000;        % W; radiator by-passed

%calculate the maximum efficiency
eff_hot=fc_pwr_hot_index/fc_fuel_heating_val./fc_h2_hot_map;
eff_cold=fc_pwr_cold_index/fc_fuel_heating_val./fc_h2_cold_map;
idx=find(eff_hot<0); eff_hot(idx)=0;
idx2=find(eff_cold<0); eff_cold(idx2)=0;
fc_eff_max=max(max(eff_hot));

clear idx idx2

