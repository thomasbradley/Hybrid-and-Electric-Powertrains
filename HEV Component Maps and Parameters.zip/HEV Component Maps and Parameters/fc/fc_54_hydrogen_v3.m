%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		    : fc_54_hydrogen_v3.m		           	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: PEM FUEL CELL                 		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: S.Deshpande - UA						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

accmech_mass 			= 20;
fc_mass       			= 100.4 ; 
fc_mass_vol 			= 50.0;			% Capacity of tank in kg

% Fuel Parameters 
fc_fuel_density_val     = 18;            % kg/m3 or g/L
fc_fuel_heating_val   = 120000000;     % J/kg; specific LHV of Hydrogen
fc_fuel_carbon_ratio = 0.0;              % since fuel is H2, this for
fc_pwr_max			= 54000;           % maximum power calculation

Patm=1; %atmospheric pressure in (Atm)
Tatm=298.15; %atmospheric temperature in (K)
den_air=1.23; %density of air in (kg/m^3)
Dc=0.2286; %compressor diameter in (m)

%regression constants
a4=-0.00003699056149;
a3=0.00027039932787;
a2=-0.00053623540171;
a1=-0.00004636845793;
a0=0.00221194680963;
b2=1.76566519765589;
b1=-1.34836801554691;
b0=2.44418790092002;
c5=-0.00978754892186;
c4=0.10580782154809;
c3=-0.42936513568305;
c2=0.80120999043258;
c1=-0.68344136821569;
c0=0.43331043048640;

% Parameter for compressor efficiency lookup table
alliedsignaleff=[200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200
60	60	50	50	50	40	30	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	10	10	20
70	70	60	60	50	50	40	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	10	10	20
76	76	70	70	60	50	50	40	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	10	20
76	76	76	76	70	60	50	50	40	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	20
78	78	76	76	76	70	60	50	50	40	30	20	20	20	10	10	10	10	10	10	10	10	10	10	10	20
76	76	78	76	76	70	70	60	50	50	40	30	30	20	20	10	10	10	10	10	10	10	10	10	10	20
70	70	77	77	76	76	70	70	60	50	50	40	40	30	20	20	10	10	10	10	10	10	10	10	10	20
65	65	75.5	78	77	77	77	70	70	60	50	50	50	40	30	20	20	10	10	10	10	10	10	10	10	20
57	57	72	77	79	78	77.5	77	77	70	60	60	50	50	40	30	20	20	20	10	10	10	10	10	10	10
54	54	68.3	75	78.7	79	79	78.3	77	76.5	70	70	60	50	50	40	30	20	20	20	10	10	10	10	10	10
50	50	63	72.5	76.7	79	79	79	78.9	78.4	77.6	77	70	60	50	50	40	30	30	20	20	20	20	10	10	10
45	50	60	70	74.7	78	79	79	79	79	78.5	78	77	70	60	50	50	40	40	30	20	20	20	20	20	20
45	50	56	65	72	75.5	78.2	79	79	79	79	76	77.7	70	70	60	50	50	50	40	30	30	30	20	20	20
40	45	50	60.5	69.5	74	74.8	78.2	79	79	79	79	78	77	77	70	60	60	60	50	40	40	30	30	30	30
40	45	50	56.5	65	71	74.4	75.4	78.1	78.8	79	79	78.8	78.3	77.5	77.5	70	70	60	60	50	50	40	40	30	30
35	40	45	50	61.3	68	71	74.7	76.4	78.1	78.7	78.8	78.9	78.8	78.32	78	76.7	76.7	70	70	60	60	50	50	40	40
30	35	40	50	57	64.3	69.7	72.8	74.7	76	78	78.4	78.6	78.7	78.6	78.3	78	77	76	76	70	60	60	60	50	50
25	30	35	45	50	60	66	70	72.5	74.6	75	77.4	78.2	78.5	78.6	78.4	78.3	78.1	77	76	75	70	70	60	60	60
25	30	35	40	50	56	62	67.2	70.2	72.8	74.6	75.5	77	78.2	78.4	78.3	78.3	78.2	77.9	76.7	75.9	75.3	74	70	70	70
20	25	30	35	45	50	58	64	67.8	70.2	72.2	74.3	75.2	76.4	78	78.1	78.2	78.2	78.1	77.4	76.6	75.8	75.2	74	73	73
20	20	25	30	40	50	55	60	65	68	70	71.8	74.2	75	75.9	77.3	78	78.1	78	77.6	76.9	76.3	75.6	74.4	73	73
15	20	20	30	35	45	50	56	61.5	60.8	63	69.5	70.8	73.5	74.6	75.3	76.3	77.1	77.5	77.4	77	76.5	76	74.7	73.3	73
10	15	20	25	30	40	45	50	56	62.5	66	68	69	70.5	72.2	74	74.8	75.6	76.3	76.8	76.7	76.4	76.1	75.1	73.7	73
5	10	15	25	30	35	40	45	50	57	63.5	66.3	68	69.2	70	70.8	72.2	73.4	74.3	75	75.4	75.5	75.3	74.8	74	73
20	10	15	20	25	30	35	40	45	50	60	65	66.4	67.7	69	69.5	70.2	70.8	71.75	72.8	73.4	74	74.2	74.2	73	73
20	5	10	20	25	30	35	40	45	45	50	50	65	66.5	67.5	68.2	69	69.5	69.7	69.8	70	70.5	70.7	73	73	73];

alliedsignalflow=[-0.5 0 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5 5.5 6 6.5 7 7.5 8 8.5 9 9.5 10 10.5 11 11.5 12 12.5];

alliedsignalpr=[1 1.1 1.2 1.3 1.4 1.5 1.6	1.7 1.8 1.9	2 2.1	2.2 2.3 2.4	2.5 2.6 2.7	2.8 2.9 3 3.1 3.2	3.3 3.4 3.5];

gam=1.4; %specific heat ratio for air
Ra=286.9; %air gas constant in (J/kg-K)
Jcp=5*10^(-5); %combined inertia of compressor and motor in (kg-m^2)
eff_cm=0.98; %motor mechanical efficiency
Kt=0.0225; %(N-m/Amp)
Rcm=1.2; %(Ohm)
Kv=0.0153; %V/(rad/sec)
cm_maxtorque = 1.5; % N-m
eff_cp=0.8; %compressor efficiency
Cp=1004; %specific heat capacity of air in (J/kg-K)
Ksm_out=0.36293861487e-5; %supply manifold outlet orifice constant in kg/(s.Pa)
Ru=8.31451; %universal gas constant in (J/mol-K)
Vsm=0.02; %lumped supply manifold volume in (m^3)
Kca_out=0.21776316896166e-5; %cathode outlet orifice constant in kg/(s.Pa)
Trm=353.15; %Return manifold temperature in (K)
Vrm=0.005; %return manifold (lumped) volumed in (m^3)
Cd_rm=0.0124; %coefficient of discharge for return manifold nozzle 
At_rm=0.002; %throat area in (m^2) (Return manifold)
phi_atm=0.5; %atmospheric relative humidity
phi_des=0.8; %desired relative humidity
Mv=18.02/1000; %molar mass of vapor=water in (kg/mol)
Ma=28.97/1000; %molar mass of air in (kg/mol)
Tm=0.01275; %membrane thickness in (cm)
B11=0.005139; %constant used to calculate sig_m in fuel cell stack model
B12=0.00326; %constant used to calculate sig_m in fuel cell stack model
B2=350; %constant used to calculate sig_m in fuel cell stack model
Tfc=353.15; %fuel cell temperature in (K)
Tst=353.15; %fuel cell stack temperature in (K)
C1=10; %constant used to calculate Va in fuel cell stack model
Afc=280; %area of fuel cell in (cm^2)
C3=2; %constant used to calculate Vcon in fuel cell stack model
Imax=2.2; %constant used to calculate Vcon in fuel cell stack model
n=381; %number of cells in fuel cell stack
F=96485; %faraday's constant in (C/mol)
Den_m_dry=0.002; %membrane dry density in (kg/cm^3)
M_m_dry=1.1; %membrane dry equivalent weight in (kg/mol)
Tca=353.15; %cathode temperature in (K)
Tcl=353.15; %air cooler temperature in (K)
Vca=0.01; %lumped cathode volume in (m^3)
Rv=461.5; %vepor gas constant in (J/kg-K)
Rn2=296.8; %nitrogen gas constant in (J/kg-K)
Ro2=259.8; %oxygen gas constant in (J/kg-K)
Y_O2_ca_in=0.21; %inlet oxygen mole fraction
M_O2=31.999/1000; %molar mass of O2 in (kg/mol)
M_N2=28.013/1000; %molar mass of O2 in (kg/mol)
Van=0.005; %lumped anode volume in (m^3)
Rh2=4124.3; %hydrogen gas constant in (J/kg.k)
Tan=353.15; %anode temperature in (K)
M_H2=2.016/1000; %molar mass of H2 in (kg/mol)
W_H2_out=0; %assumed Wan,out=0 in kg/sec
Wv_an_out=0; %assumed Wan,out=0
fc_mass_vol=50.0; % Capacity of tank in kg

%Look up table data for max lam and power
Pdes=[0 0.00539 0.0307 0.17469 0.352996 0.52943 0.704 0.87669 1.0475 1.2164 1.3834 ...
        1.5485 1.7119 3.2652 4.6965 6.0352 7.2991 8.509 9.6776 10.8125 11.92461 13.0179 ...
        14.0932 15.1583 16.2131 17.2592 18.302 19.3425 20.373 21.3985 22.4246 23.4375 ...
        24.43491 25.43455 26.4205 27.40081 28.37388 29.35479 30.31919 31.26967 32.20574 ...
        33.12711 34.03365 34.92758 35.80866 36.67199 37.52293 38.36284 39.18915 39.99663 ...
        40.78513 41.56593 42.32619 43.06853 43.79678 44.50867 45.20698 45.88563 46.54573 ...
        47.18927 47.81411 48.41567 48.99639 49.54708 50.07038 50.57589 51.05419 51.504 ...
        51.94236 52.35031 52.73115 53.09956 53.44096 53.74065 54.00124];

Ist=[0 0.03 0.1 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5 10 15 20 25 30 35 40 45 50 55 60 65 70 ...
        75 80 85 90 95 100 105 110 115 120 125 130 135 140 145 150 155 160 165 170 ...
        175 180 185 190 195 200 205 210 215 220 225 230 235 240 245 250 255 260 ...
        265 270 275 280 285 290 295 300 305 310 315];

Vcm=[0 16 16 16 16 16 16 16 16 16 16 16 16.96 26.14 34.08 40.42 46.09 52.45 ...
        57.11 61.59 67.32 71.38 75.21 80.71 84.51 89.31 95.22 99.8 103.81 109.54 ...
        113.99 115.44 121.25 125.47 129.73 134.51 138.71 145.44 147.18 148.9 150.62 ...
        152.3 154.79 158.24  160.75 163.39 168.47 172.38 172.53 176.06 179.42 182.83 ...
        183.98 187.39 190.02 193.76 196.79 198.46 201.86 203.44 206.48 208.59 210.03 ...
        210.17 214.17 214.31 217 218.43 222.84 223.97 226.82 231.73 231.51 231.3 233.2];

excess_ratio_O2=[0 458.5919 137.6851 27.66 13.90686 9.32247 7.03026 5.6549 4.73805 ...
        4.0831 3.5919 3.2098 3.1481 2.9199 2.836 2.7287 2.6459 2.6654 2.5947 2.5389 ...
        2.568 2.5178 2.4693 2.4987 2.4616 2.4663 2.5105 2.5096 2.4909 2.5241 2.521 ...
        2.44 2.4712 2.4647 2.45879 2.4652 2.45953 2.50583 2.4523 2.4024 2.3539 2.31206 ...
        2.28509 2.27626 2.2529 2.23283 2.25256 2.25431 2.19957 2.19703 2.19228 2.18981 ...
        2.15592 2.15485 2.14396 2.14904 2.14521 2.12366 2.12569 2.10459 2.10284 2.0895 ...
        2.06857 2.03295 2.04241 2.00861 2.00354 1.98499 1.99806 1.97702 1.97319 1.98848 ...
        1.9559 1.92446 1.91147];

% Define the following variable to satisfy the series power controller's dependency on an optimal point
fc_pwr_opt = 23700 ; 