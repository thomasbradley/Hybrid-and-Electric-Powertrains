%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: fc_50_pox_gasoline.m							   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: POx REFORMED GASOLINE FUELED FUEL CELL       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: S.Buyuktur - ANL							   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : Dr. Romesh Kumar, Argonne National Lab 		   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 												    %
%     Dr. William E. Kramer										    	    %
%     Idaho National Engineering Laboratoy									%
%     P.O. Box 1625														    %
%     Idaho Falls, Idaho  83415-3830									    %
%     (208)526-7986															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 												%
%	(1)	Modify by Gilles Monnet on 2/10/00 Cut the accesories               %
%			initialisation parameters and create specific accessorie file   %
%			for Pox Fuel cell. Keep initialisation value and deleted scaling%
%			to create specific scaling file for Pox Fuel cell               %												
% 	(2)  Xi Wei - 08/02/00 - maximum power and efficiency calculation	    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fc_tau_i_p    				= 1.0;                  %  transient load delay for first order lag
fc_fuel_density_val         = 749;            % kg/m3 or g/L
fc_fuel_heating_val         = 43000000;     % J/kg; specific LHV of Hydrogen
fc_fuel_carbon_ratio 		= 0.86;              %  carried for compatability
fc_mass       				= 100.4 ;         % kg; PLACEHOLDER
fc_mass_vol 				= 50.0;						% Capacity of tank in kg 
fc_temp_tau_hot_i_p 		= 128;  
fc_temp_tau_cold_i_p 		= 1800;
fc_warmup_init_i_p 			= 0;
fc_pwr_opt_i_p 				= 23700 ; % from the tables provided by ANL, max eff; W
fc_temp_tau_ex_i_p   		= 20; % sec; catalyst light-off time
fc_temp_tau_reformer_i_p	= 30; % sec; reformer warm up to feed H2 to fuel cell

% Only here to satisfy dependencies in other models.  
eng_spd_idle       			= 0;  %temporary for sft
fc_displ_init      			= 0; 
fc_spd_opt        			= 0;
fc_co2_init 				= 0;

% Hot power
fc_pwr_hot_index    		= [2.3  5.1 11.3    23.7    34.4    43  50]*1000; % W
fc_pwr_hot_max 				= max(fc_pwr_hot_index);           % Max DC power of fuel cell, W
fc_h2_hot_map   			= [ 0.16  0.31  0.62  1.25 1.87  2.49  3.12 ]/1000;% kg/s from g/s
fc_h2_hot_max 				= max (fc_h2_hot_map);
           
% Cold power
fc_pwr_cold_index    		= [2.3  5.1 10.8    21.8    30.2    34.2    37.3]*1000;% W
fc_pwr_cold_max 			= max(fc_pwr_cold_index); % Max DC power of fuel cell, W
fc_h2_cold_map 				= [ 0.16  0.31  0.62  1.25  1.87  2.49  3.12 ]/1000;% kg/s from g/s

% Hot fuel cell stack emissions
fc_hot_flow_ratio        	= [ 3.00  6.00  11.80  23.8 36.4  49.5   62.8]/1000;       % kg/s

% Cold fuel cell stack emissions
fc_cold_flow_ratio   		= [ 3.00  6.00  11.80  23.8 36.4  49.5  62.8 ]/1000;       % kg/s

% calculate the maximum efficiency
eff_hot						= fc_pwr_hot_index/fc_fuel_heating_val./fc_h2_hot_map;
eff_cold					= fc_pwr_cold_index/fc_fuel_heating_val./fc_h2_cold_map;
fc_eff_max					= max(max(eff_hot));

fc_mass 					= 1.6*fc_pwr_hot_max/1000; %1.6 kg/kW
fc_pwr_max					= max(fc_pwr_hot_index);% maximum power calculation

% Hot accessory power
accmech_pwr_hot_pump  		= [0.133 0.265 0.511 1.014 1.531  2.052  2.629]*1000;   % W; pump/fan 
accmech_pwr_hot_compressor = [1.30  1.96  2.62  3.49  4.69   6.23   7.79 ]*1000;   % W; compressor
accmech_pwr_hot_expander   = [0.12  0.33  1.01  3.06  5.14   6.89   8.62 ]*1000;   % W; expander
accmech_pwr_hot_radiator   = [2.77  5.32 10.37 21.41 34.00  52.92  63.85 ]*1000;   % W; radiator duty

% Cold accesory power
accmech_pwr_cold_pump 		= [0.616 0.616 0.616 0.616 0.616 0.616 0.616 ]*1000; % W; pump/fan
accmech_pwr_cold_compressor= [1.30  1.96   2.62  3.49  4.69  6.23  7.79 ]*1000; % W; compressor
accmech_pwr_cold_expander  = [0.65  0.73   1.13  2.59  3.77  4.51  5.43 ]*1000; % W; expander
accmech_pwr_cold_radiator  = [0.00  0.00   0.00  0.00  0.00  0.00  0.00 ]*1000; % W; radiator by-passed

