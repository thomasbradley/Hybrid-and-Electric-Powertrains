%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		    : fc_54_hydrogen_v6.m		           	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: PEM FUEL CELL                 		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: S.Deshpande - UA						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

accmech_mass 			= 20;
fc_mass       			= 100.4 ; 
fc_mass_vol 			= 50.0;			% Capacity of tank in kg

% Fuel Parameters 
fc_fuel_density_val     = 18;            % kg/m3 or g/L
fc_fuel_heating_val   = 120000000;     % J/kg; specific LHV of Hydrogen
fc_fuel_carbon_ratio = 0.0;              % since fuel is H2, this for
fc_pwr_max			= 54000;           % maximum power calculation

Patm=1; %atmospheric pressure in (Atm)
Tatm=298.15; %atmospheric temperature in (K)
den_air=1.23; %density of air in (kg/m^3)
Dc=0.2286; %compressor diameter in (m)

%regression constants
a4=-0.00003699056149;
a3=0.00027039932787;
a2=-0.00053623540171;
a1=-0.00004636845793;
a0=0.00221194680963;
b2=1.76566519765589;
b1=-1.34836801554691;
b0=2.44418790092002;
c5=-0.00978754892186;
c4=0.10580782154809;
c3=-0.42936513568305;
c2=0.80120999043258;
c1=-0.68344136821569;
c0=0.43331043048640;

% Parameter for compressor efficiency lookup table
alliedsignaleff=[200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200	200
60	60	50	50	50	40	30	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	10	10	20
70	70	60	60	50	50	40	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	10	10	20
76	76	70	70	60	50	50	40	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	10	20
76	76	76	76	70	60	50	50	40	30	20	20	10	10	10	10	10	10	10	10	10	10	10	10	10	20
78	78	76	76	76	70	60	50	50	40	30	20	20	20	10	10	10	10	10	10	10	10	10	10	10	20
76	76	78	76	76	70	70	60	50	50	40	30	30	20	20	10	10	10	10	10	10	10	10	10	10	20
70	70	77	77	76	76	70	70	60	50	50	40	40	30	20	20	10	10	10	10	10	10	10	10	10	20
65	65	75.5	78	77	77	77	70	70	60	50	50	50	40	30	20	20	10	10	10	10	10	10	10	10	20
57	57	72	77	79	78	77.5	77	77	70	60	60	50	50	40	30	20	20	20	10	10	10	10	10	10	10
54	54	68.3	75	78.7	79	79	78.3	77	76.5	70	70	60	50	50	40	30	20	20	20	10	10	10	10	10	10
50	50	63	72.5	76.7	79	79	79	78.9	78.4	77.6	77	70	60	50	50	40	30	30	20	20	20	20	10	10	10
45	50	60	70	74.7	78	79	79	79	79	78.5	78	77	70	60	50	50	40	40	30	20	20	20	20	20	20
45	50	56	65	72	75.5	78.2	79	79	79	79	76	77.7	70	70	60	50	50	50	40	30	30	30	20	20	20
40	45	50	60.5	69.5	74	74.8	78.2	79	79	79	79	78	77	77	70	60	60	60	50	40	40	30	30	30	30
40	45	50	56.5	65	71	74.4	75.4	78.1	78.8	79	79	78.8	78.3	77.5	77.5	70	70	60	60	50	50	40	40	30	30
35	40	45	50	61.3	68	71	74.7	76.4	78.1	78.7	78.8	78.9	78.8	78.32	78	76.7	76.7	70	70	60	60	50	50	40	40
30	35	40	50	57	64.3	69.7	72.8	74.7	76	78	78.4	78.6	78.7	78.6	78.3	78	77	76	76	70	60	60	60	50	50
25	30	35	45	50	60	66	70	72.5	74.6	75	77.4	78.2	78.5	78.6	78.4	78.3	78.1	77	76	75	70	70	60	60	60
25	30	35	40	50	56	62	67.2	70.2	72.8	74.6	75.5	77	78.2	78.4	78.3	78.3	78.2	77.9	76.7	75.9	75.3	74	70	70	70
20	25	30	35	45	50	58	64	67.8	70.2	72.2	74.3	75.2	76.4	78	78.1	78.2	78.2	78.1	77.4	76.6	75.8	75.2	74	73	73
20	20	25	30	40	50	55	60	65	68	70	71.8	74.2	75	75.9	77.3	78	78.1	78	77.6	76.9	76.3	75.6	74.4	73	73
15	20	20	30	35	45	50	56	61.5	60.8	63	69.5	70.8	73.5	74.6	75.3	76.3	77.1	77.5	77.4	77	76.5	76	74.7	73.3	73
10	15	20	25	30	40	45	50	56	62.5	66	68	69	70.5	72.2	74	74.8	75.6	76.3	76.8	76.7	76.4	76.1	75.1	73.7	73
5	10	15	25	30	35	40	45	50	57	63.5	66.3	68	69.2	70	70.8	72.2	73.4	74.3	75	75.4	75.5	75.3	74.8	74	73
20	10	15	20	25	30	35	40	45	50	60	65	66.4	67.7	69	69.5	70.2	70.8	71.75	72.8	73.4	74	74.2	74.2	73	73
20	5	10	20	25	30	35	40	45	45	50	50	65	66.5	67.5	68.2	69	69.5	69.7	69.8	70	70.5	70.7	73	73	73];

alliedsignalflow=[-0.5 0 0.5 1 1.5 2 2.5 3 3.5 4 4.5 5 5.5 6 6.5 7 7.5 8 8.5 9 9.5 10 10.5 11 11.5 12 12.5];

alliedsignalpr=[1 1.1 1.2 1.3 1.4 1.5 1.6	1.7 1.8 1.9	2 2.1	2.2 2.3 2.4	2.5 2.6 2.7	2.8 2.9 3 3.1 3.2	3.3 3.4 3.5];

gam=1.4; %specific heat ratio for air
Ra=286.9; %air gas constant in (J/kg-K)
Jcp=5*10^(-5); %combined inertia of compressor and motor in (kg-m^2)
eff_cm=0.98; %motor mechanical efficiency
Kt=0.0225; %(N-m/Amp)
Rcm=1.2; %(Ohm)
Kv=0.0153; %V/(rad/sec)
cm_maxtorque = 1.5; % N-m
eff_cp=0.8; %compressor efficiency
Cp=1004; %specific heat capacity of air in (J/kg-K)
Ksm_out=0.36293861487e-5; %supply manifold outlet orifice constant in kg/(s.Pa)
Ru=8.31451; %universal gas constant in (J/mol-K)
Vsm=0.02; %lumped supply manifold volume in (m^3)
Kca_out=0.21776316896166e-5; %cathode outlet orifice constant in kg/(s.Pa)
Vrm=0.005; %return manifold (lumped) volumed in (m^3)
Cd_rm=0.0124; %coefficient of discharge for return manifold nozzle 
At_rm=0.002; %throat area in (m^2) (Return manifold)
phi_atm=0.5; %atmospheric relative humidity
phi_des=0.8; %desired relative humidity
Mv=18.02/1000; %molar mass of vapor=water in (kg/mol)
Ma=28.97/1000; %molar mass of air in (kg/mol)
Tm=0.01275; %membrane thickness in (cm)
B11=0.005139; %constant used to calculate sig_m in fuel cell stack model
B12=0.00326; %constant used to calculate sig_m in fuel cell stack model
B2=350; %constant used to calculate sig_m in fuel cell stack model
%************
fc_tst_i_p=353.15; %fuel cell stack temperature in (K)
fc_excess_ratio_i_p=2; %reference oxygen excess ratio 
%************
C1=10; %constant used to calculate Va in fuel cell stack model
Afc=280; %area of fuel cell in (cm^2)
C3=2; %constant used to calculate Vcon in fuel cell stack model
Imax=2.2; %constant used to calculate Vcon in fuel cell stack model
n=381; %number of cells in fuel cell stack
F=96485; %faraday's constant in (C/mol)
Den_m_dry=0.002; %membrane dry density in (kg/cm^3)
M_m_dry=1.1; %membrane dry equivalent weight in (kg/mol)
Vca=0.01; %lumped cathode volume in (m^3)
Rv=461.5; %vepor gas constant in (J/kg-K)
Rn2=296.8; %nitrogen gas constant in (J/kg-K)
Ro2=259.8; %oxygen gas constant in (J/kg-K)
Y_O2_ca_in=0.21; %inlet oxygen mole fraction
M_O2=31.999/1000; %molar mass of O2 in (kg/mol)
M_N2=28.013/1000; %molar mass of O2 in (kg/mol)
Van=0.005; %lumped anode volume in (m^3)
Rh2=4124.3; %hydrogen gas constant in (J/kg.k)
M_H2=2.016/1000; %molar mass of H2 in (kg/mol)
W_H2_out=0; %assumed Wan,out=0 in kg/sec
Wv_an_out=0; %assumed Wan,out=0
fc_mass_vol=50.0; % Capacity of tank in kg

% Look up table data Feedforward map for fixed lam=2 and power
Pdes_fwd=[0 0.00539 0.0307 0.17469 0.352996 0.52943 0.704 0.87669 1.0475 1.2164 1.3834 1.5485...
        1.7119 3.25495 4.67954 6.00995 7.26907 8.47294 9.63323 10.76281 11.86831 12.95381...
        14.02377 15.08456 16.13339 17.17067 18.20165 19.22505 20.2404 21.24837 22.25252...
        23.25276 24.24201 25.22133 26.19543 27.16467 28.11784 29.05735 29.99293 30.91605...
        31.82969 32.73526 33.63159 34.51968 35.39991 36.27275 37.1387 37.99832 38.85221...
        39.69893 40.53645 41.44633 42.21442 42.96449 43.69721 44.41726 45.11698 45.79873...
        46.46129 47.11083 47.74316 48.35362 48.9477 49.51875 50.06553 50.57159 51.05337...
        51.50325 51.94155 52.34196 52.72694 53.08045 53.37892 53.64079 53.86746];

Vcm_fwd=[0 16 16 16 16 16 16 16 16 16 16 16 16.96 19.62379 26.16047 32.08524 37.48652...
        42.50518 47.26085 51.74926 56.04851 60.22791 64.30445 68.24446 72.14484...
        76.02667 79.83551 83.60603 87.35305 91.0737 94.73275 98.33795 101.9658...
        105.6017 109.19947 112.75822 116.37733 120.02884 123.62883 127.24737...
        130.85829 134.44993 138.03071 141.59314 145.13481 148.65351 152.14735...
        155.61491 159.05521 162.48001 165.90409 169.26449 172.61739 175.96216...
        179.29299 182.55907 185.79342 188.98602 192.14551 195.24475 198.30787...
        201.36007 204.3788 207.39842 210.42783 213.54279 216.67468 219.86275...
        223.03139 226.30482 229.61241 233.05617 236.79695 240.93458 246.52199];

% Define the following variable to satisfy the series power controller's dependency on an optimal point
fc_pwr_opt = 23700 ; 




