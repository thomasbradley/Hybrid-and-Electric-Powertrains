%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_58.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: Honda - 58-kW PM induction motor/inverter	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Marcus Menne, et al., "Energy-Efficiency Evaluation of Traction  	%
% Drives for Electric Vehicles", Proceedings 15th Electric Vehicle  %
% Symposium, Brussels 1998.											%
% Drive tested by Institute for Power Electronics and Electrical  	%
% Drives at Aachen University of Technology (Germany).				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation	    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% This is a prototype or small-production 58 kW, permanent magnet	%
% motor/controller.  Efficiency/loss data appropriate for a rated 	%
% voltage system.(Voltage was not given in the source paper.)		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.0235; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 120; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 70; % (kg), mass of motor and controller																		
mc_curr_max				= 480; % (A), maximum current allowed by the controller and motor
mc_spd_base				= 1000*c_rpm_radps;% rad/s

mc_spd_cont_index       = [0 250 500 750 1000 1250 1500 1750 2000 2250 2500 2750 3000 3250 3500 3750 4000]* c_rpm_radps;
mc_trq_cont_map 	    = [340 375 402 403 401 400 348 300 250 227 202 190 175 170 150 148 0]; % (N*m)

mc_spd_max_index 	    = [0 250 500 750 1000 1250 1500 1750 2000 2250 2500 2750 3000 3250 3500 3750 4000]* c_rpm_radps;
mc_trq_max_map      	= 1.*mc_trq_cont_map;

mc_spd_eff_index 		= [0 250 500 750 1000 1250 1500 1750 2000 2250 2500 2750 3000 3250 3500 3750 4000]* c_rpm_radps;
mc_trq_eff_index 	    = [0 25 50 75 100 125 150 175 200 225 250 275 300 325 350 375 400];
mc_eff_trq_map		= [...
      0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3	0.3
      0.3   0.7   0.75  0.75  0.75  0.73  0.71  0.7   0.7   0.68  0.65  0.63  0.62  0.61  0.6   0.59  0.58   
      0.3   0.75  0.8   0.82  0.824 0.823 0.82  0.815 0.81  0.8   0.78  0.77  0.76  0.755 0.745 0.73  0.72
      0.3   0.75  0.82  0.842 0.855 0.856 0.854 0.85  0.845 0.84  0.835 0.825 0.82  0.808 0.8   0.77  0.765
      0.3   0.75  0.83  0.86  0.871 0.875 0.877 0.873 0.871 0.869 0.862 0.859 0.85  0.842 0.836 0.825 0.82
      0.3   0.75  0.84  0.87  0.881 0.887 0.889 0.887 0.884 0.882 0.878 0.873 0.867 0.861 0.855 0.85  0.842
      0.3   0.75  0.84  0.873 0.89  0.895 0.897 0.896 0.894 0.893 0.89  0.887 0.881 0.876 0.876 0.876 0.876
      0.3   0.75  0.84  0.88  0.893 0.9   0.901 0.901 0.901 0.9   0.895 0.892 0.89  0.89  0.89  0.89  0.89
      0.3   0.75  0.84  0.88  0.895 0.901 0.904 0.905 0.904 0.903 0.902 0.902 0.902 0.902 0.902 0.902 0.902
      0.3   0.75  0.84  0.88  0.9   0.903 0.908 0.909 0.907 0.906 0.906 0.906 0.906 0.906 0.906 0.906 0.906
      0.3   0.75  0.85  0.88  0.9   0.905 0.91  0.915 0.91  0.91  0.91  0.91  0.91  0.91  0.91  0.91  0.91
      0.3   0.75  0.85  0.88  0.9   0.904 0.908 0.909 0.909 0.909 0.909 0.909 0.909 0.909 0.909 0.909 0.909
      0.3   0.75  0.84  0.875 0.89  0.9   0.904 0.904 0.904 0.904 0.904 0.904 0.904 0.904 0.904 0.904 0.904
      0.3   0.74  0.82  0.865 0.885 0.894 0.9   0.9   0.9   0.9   0.9   0.9   0.9   0.9   0.9   0.9   0.9
      0.3   0.7   0.82  0.86  0.88  0.89  0.895 0.895 0.895 0.895 0.895 0.895 0.895 0.895 0.895 0.895 0.895
      0.3   0.7   0.81  0.855 0.878 0.888 0.892 0.892 0.892 0.892 0.892 0.892 0.892 0.892 0.892 0.892 0.892
      0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3   0.3];

mc_pre_calculation  
  
%evaluatefile('mc1_pre_calculation','mc1_','mc_')