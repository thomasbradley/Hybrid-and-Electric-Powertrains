%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_id_30.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			:  data file for the Siemens AC 30 kW 	    %
% induction motor/controller										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency/loss data appropriate to a 216-V system.				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.24; 	% rotor's rotational inertia, kg-m^2
mc_coeff_regen_i_p 	    = 1.0;
mc_volt_min_i			= 140; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 41 + 17;% Weight of motor power/sum of motor and controller mass			
mc_curr_max				= 280; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= 2200 * c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 1500 2200 3000 4500 6000 7500 9000]* c_rpm_radps;
mc_trq_cont_map 	    = [124 124  124  92   62    45   35   28];

mc_spd_max_index 	    = [0 1500 2200 3000 4500 6000 7500 9000]* c_rpm_radps;
mc_trq_max_map 	        = 3*mc_trq_cont_map;

mc_spd_eff_index 		= [0 1500 2200 3000 4500 6000 7500 9000]* c_rpm_radps;
mc_trq_eff_index 	    = [0 5 15 30 45 55 65 75 85 95 105 125];
mc_eff_trq_map 		    = [...
   0.1	0.40	0.45	0.48	0.49	0.50	0.51	0.49	0.46	0.40	0.37	0.32    % 0
   0.1	0.62	0.72	0.75	0.755	0.76	0.754	0.75	0.74	0.74	0.71	0.707   % 1500
   0.1	0.62	0.72	0.75	0.755	0.76	0.754	0.75	0.74	0.74	0.71	0.707   % 2200
   0.1	0.70	0.785	0.83	0.843	0.842	0.842	0.844	0.834	0.83	0.822	0.707   % 3000
   0.1	0.71	0.817	0.855	0.847	0.84	0.803	0.844	0.834	0.83	0.822	0.707   % 4500
   0.1	0.74	0.84	0.84	0.741 0.84	0.803	0.844	0.834 0.83	0.822	0.707   % 6000
   0.1	0.76	0.825	0.825	0.741	0.84	0.803	0.844	0.834	0.83	0.822	0.707   % 7500
   0.1	0.76	0.825	0.825	0.741	0.84	0.803	0.844	0.834	0.83	0.822	0.707]; % 9000

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')