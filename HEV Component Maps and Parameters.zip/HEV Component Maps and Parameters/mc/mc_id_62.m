%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_id_62.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			:  62 kW (continuous), AC induction 	    %
% motor/controller													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 						    				%
% Marcus Menne, et al., "Energy-Efficiency Evaluation of Traction 	% 
% Drives for Electric Vehicles", Proceedings 15th Electric Vehicle  %
% Symposium, Brussels 1998.											%
% Drive tested by Institute for Power Electronics and Electrical  	%
% Drives at Aachen University of Technology (Germany).				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% This is a prototype or small-production 62 kW, AC induction  		%
% motor/controller. Efficiency/loss data appropriate for a rated 	%
% voltage system.  (Voltage was notgiven in the source paper.)		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.0235; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 120; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 70;% sum of motor and controller mass																		
mc_curr_max				= 480; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= 2000 * c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000 6500 7000 7500 8000]* c_rpm_radps;
mc_trq_cont_map 	    = [198 198 198 198 197 195 183 165 147 127 119 105 98 90 83 76 73];

mc_spd_max_index 	    = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000 6500 7000 7500 8000]* c_rpm_radps;
mc_trq_max_map 	        = 1.*mc_trq_cont_map;

mc_spd_eff_index 		= [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000 6500 7000 7500 8000]* c_rpm_radps;
mc_trq_eff_index 	        = [0 25 50 75 100 125 150 175 200];
mc_eff_trq_map 		    = [...
      0.2   0.2   0.2   0.2   0.2   0.2   0.2   0.2   0.2
      0.2   0.58  0.61  0.62  0.61  0.62  0.62  0.61  0.6
      0.2   0.71  0.76  0.77  0.765 0.77  0.76  0.755 0.75
      0.2   0.765 0.809 0.828 0.822 0.826 0.82  0.817 0.818
      0.2   0.79  0.836 0.855 0.853 0.856 0.85  0.848 0.846
      0.2   0.81  0.852 0.872 0.871 0.873 0.87  0.869 0.866
      0.2   0.822 0.87  0.885 0.885 0.885 0.883 0.882 0.881
      0.2   0.832 0.88  0.893 0.892 0.891 0.89  0.889 0.888
      0.2   0.84  0.888 0.9   0.897 0.894 0.894 0.894 0.894
      0.2   0.85  0.894 0.9   0.897 0.895 0.895 0.895 0.895
      0.2   0.86  0.9   0.9   0.898 0.898 0.898 0.898 0.898
      0.2   0.87  0.9   0.9   0.897 0.897 0.897 0.897 0.897
      0.2   0.879 0.9   0.899 0.89  0.89  0.89  0.89  0.89
      0.2   0.882 0.9   0.893 0.88  0.88  0.88  0.88  0.88
      0.2   0.885 0.896 0.882 0.86  0.86  0.86  0.86  0.86
      0.2   0.884 0.89  0.87  0.87  0.87  0.87  0.87  0.87
      0.2   0.88  0.878 0.86  0.86  0.86  0.86  0.86  0.86];

mc_pre_calculation
  
%evaluatefile('mc1_pre_calculation','mc1_','mc_')