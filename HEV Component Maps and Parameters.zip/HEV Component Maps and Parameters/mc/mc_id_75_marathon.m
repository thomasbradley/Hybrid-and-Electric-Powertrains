%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_id_75_marathon.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: Marathon/UW , 75 kW, AC Induction motor   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: J. Bayer (UW-Madison) - 04/30/01		    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency/loss data appropriate for a 312 V system.				%
% Driven by solectria DMOC DSP motor controller 78kw Peak 240 amp	%
% Efficiency is lower than expected but reasonable					%
% efficiency from Westinghouse, 75 kW, AC Induction motor			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = .0874; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 240; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 108.9;% kW/kg, rated continuous motor power/sum of motor and controller mass																		
mc_curr_max				= 240; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= 1376 * c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 500 1376 1500 1750 2000 2250 2500 2750 3000 3500]* c_rpm_radps;
mc_trq_cont_map 	    = [478 478 478 438.5 375.8 328.8 292.3 263.1 239.2 219.2 187.9]*4.448/3.281;

mc_spd_max_index 	    = [0 500 1376 1500 1750 2000 2250 2500 2750 3000 3500]* c_rpm_radps;
mc_trq_max_map 	        = 1.*mc_trq_cont_map;

mc_spd_eff_index 		= [0 500 1376 1500 1750 2000 2250 2500 2750 3000 3500]* c_rpm_radps;
mc_trq_eff_index 	    = [0 48 95 143 191 239 286 334 382 430 478]*4.448/3.281;
mc_eff_trq_map 		= [...
	0.7	0.7	0.7	0.7	0.7	0.7	0.7	0.7	0.7	0.7	0.7
	0.7	0.77	0.81	0.82	0.82	0.82	0.81	0.8	    0.79	0.78	0.78
	0.7	0.82	0.85	0.86	0.87	0.88	0.87	0.86	0.86	0.86	0.85
	0.7	0.87	0.89	0.9	    0.9	    0.9	    0.9	    0.89	0.88	0.87	0.86
	0.7	0.88	0.91	0.91	0.91	0.9	    0.88	0.87	0.85	0.82	0.81
	0.7	0.89	0.91	0.91	0.9	    0.87	0.85	0.82	0.82	0.82	0.82
	0.7	0.9	    0.91	0.9	    0.86	0.82	0.79	0.78	0.79	0.79	0.79
	0.7	0.91	0.91	0.88	0.8	    0.78	0.78	0.78	0.78	0.78	0.78
	0.7	0.92	0.9	    0.8	    0.78	0.78	0.78	0.78	0.78	0.78	0.78
	0.7	0.92	0.88	0.78	0.78	0.78	0.78	0.78	0.78	0.78	0.78
	0.7	0.92	0.8	    0.78	0.78	0.78	0.78	0.78	0.78	0.78	0.78];

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')