%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		:  mc_pm_32_sachs.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 	Sachs Daimler EPRI Project%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: Thomas Bradley - EPRI 12/5/03					    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: Heinz Joergenson 											%
						% DaimlerChrysler AG
						% 020/C28 - ET/KV - KEN
						% 68299 Mannheim/Germany
						% 
						% Phone        +49-(0) 621-393-37 40
						% Fax        +49-(0) 621-393-43 24
						% e-Fax        +49-(0) 711-3052-13 24 29
						% Mobil        +49-(0) 160-863-49 26
						% mailto:heinz.joergensen@daimlerchrysler.com			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('mc_pm_32_sachs.m')

mc_inertia_i_p 		    = 0.047; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 60; % (V), minimum voltage allowed by the controller and motor
mc_volt_max             = 250;
mc_tau_i_p				= .05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 60; % Time the motor can remain at max torque
mc_mass 				= 40; % (kg), mass of motor and controller																		
mc_curr_max				= 300; % (A), maximum current allowed by the controller and motor
mc_spd_base				= 3000*c_rpm_radps;% rad/s

max_power_factor=93/75;
cont_power_factor=72/52;


mc_spd_cont_index       = [0    1200    1500    2000    2500    3000    3500    4000    4500    5000 ]* c_rpm_radps;
mc_trq_cont_map 	    = [130  130     120     115     110     107     105     102     100      100]*cont_power_factor; % (N*m)
mc_spd_max_index 	    = [0   1200 1500 2000 2500 3000 3500 4000 4500 5000 ]* c_rpm_radps;
mc_trq_max_map 	        = [210 210  210  210  210  210  200  175  160  140]*max_power_factor;  




mc_spd_eff_index 		= [0	500	1000	1500	2000	2500	3000	3500	4000	4500	5000]* c_rpm_radps;
mc_trq_eff_index 	    = [0    25    50    75   100   125   150   175   200   225   250   275   300   325   350]*max_power_factor;

% Motoring Efficiency Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eff = 0.01*[50	50	50	50	50	50	70	91	92	93	93 ... 
50	50	50	50	50	53	90	92	93	93	93.5 ... 
50	50	50	50	50	53	91	92.5	93	94	94 ... 
50	50	50	50	50	89	91.5	92.5	93.5	94	94 ...
50	50	50	50	53	89.5	91.5	93	94	95	94 ...
50	50	50	50	87	90.5	92	93	94	95	94 ...
50	50	50	53.5	88	90.5	92.5	94	94	94	93.5 ...
50	50	50	81	88.5	91.5	92.5	94	94	93.5	93.5 ...
50	50	53.5	85	90	91.5	93	93.5	93.5	93	93 ...
50	50	75	86	90	91.5	93	93	93	92.5	92 ...
50	50	79.5	86.5	90.5	92	93	92.5	92	91.5	90 ...
50	53.5	82	88.5	91	92	92	92	91	90.5	90 ...
50	65	84	89.5	91	91	90.5	90	88.5	86.5	85 ...
50	74.5	86	89	88.5	88	85.5	83	81	78	75 ...
50	50	50	50	50	50	50	50	50	50	50 ...
3.27967E-06	0.246168297	0.394081489	0.492713983	0.563149944	0.61595451	0.657002739	0.689821321	0.716655075	0.739000747	0.757894605	0.77407685	0.788090281	0.80034198	0.811143222	0.820736088	0.829311677	0.837022851	0.84399334	0.850324365	0.85609953	...
0.861388497	0.866249772	0.870732852	0.874879894	0.878727027	0.882305391	0.885641968	0.888760256	0.89168081	0.89442169	0.896920244	0.89883978	0.900254323	0.90127229	...							
0.901938956	0.902341911	0.902477753	0.902425696	0.902192552	0.90300859	0.904850581	0.906479358	0.908022249	0.909374049	0.91060182	0.911777682	0.912790703	0.913765467	0.914585083	...
0.915326266	0.916037826	0.916622016	0.91719877	0.917647297	0.918098522	0.918430471	0.918774881	0.918987304	0.91921881	0.919345448	]; % from Sachs

rpm_buff = mc_spd_eff_index;
rpm_max_trq = [0	100	200	300	400	500	600	700	800	900	1000	1100	1200	1300	1400	1500	1600	1700	1800	1900	2000	2100	2200	2300	2400	2500	2600	2700	2800	2900	3000	3100	3200	3300	3400	3500	3600	3700	3800	3900	4000	4100	4200	4300	4400	4500	4600	4700	4800	4900	5000	5100	5200	5300	5400	5500	5600	5700	5800	5900	6000]*2*pi/60;

rpm = [rpm_buff rpm_buff rpm_buff rpm_buff  rpm_buff rpm_buff rpm_buff rpm_buff rpm_buff rpm_buff rpm_buff rpm_buff rpm_buff rpm_buff rpm_buff rpm_max_trq];

torque = [350	1336.901522	668.450761	445.6338407	334.2253805	267.3803044	222.8169203	190.9859317	167.1126902	148.5446136	133.6901522 ...
325	1241.408556	620.7042781	413.802852	310.352139	248.2817112	206.901426	177.3440794	155.1760695	137.934284	124.1408556 ...
300	1145.91559	572.9577951	381.9718634	286.4788976	229.1831181	190.9859317	163.7022272	143.2394488	127.3239545	114.591559 ...
275	1050.422624	525.2113122	350.1408748	262.6056561	210.0845249	175.0704374	150.0603749	131.3028281	116.7136249	105.0422624 ...
250	954.9296586	477.4648293	318.3098862	238.7324146	190.9859317	159.1549431	136.4185227	119.3662073	106.1032954	95.49296586 ...
225	859.4366927	429.7183463	286.4788976	214.8591732	171.8873385	143.2394488	122.7766704	107.4295866	95.49296586	85.94366927 ...
200	763.9437268	381.9718634	254.6479089	190.9859317	152.7887454	127.3239545	109.1348181	95.49296586	84.88263632	76.39437268 ...
175	668.450761	334.2253805	222.8169203	167.1126902	133.6901522	111.4084602	95.49296586	83.55634512	74.27230678	66.8450761 ...
150	572.9577951	286.4788976	190.9859317	143.2394488	114.591559	95.49296586	81.85111359	71.61972439	63.66197724	57.29577951 ...
125	477.4648293	238.7324146	159.1549431	119.3662073	95.49296586	79.57747155	68.20926133	59.68310366	53.0516477	47.74648293 ...
100	381.9718634	190.9859317	127.3239545	95.49296586	76.39437268	63.66197724	54.56740906	47.74648293	42.44131816	38.19718634 ...
75	286.4788976	143.2394488	95.49296586	71.61972439	57.29577951	47.74648293	40.9255568	35.8098622	31.83098862	28.64788976 ...
50	190.9859317	95.49296586	63.66197724	47.74648293	38.19718634	31.83098862	27.28370453	23.87324146	21.22065908	19.09859317 ...
25	95.49296586	47.74648293	31.83098862	23.87324146	19.09859317	15.91549431	13.64185227	11.93662073	10.61032954	9.549296586 ...
0	0	0	0	0	0	0	0	0	0	0 ...
209.90	209.78	209.69	209.62	209.55	209.48	209.42	209.36	209.30	209.24	209.19	209.13	209.08	209.03	208.98	208.93	208.88	208.83	208.78	208.74	208.69	208.64	208.60	208.55	208.51	208.47	208.42	208.38	208.34	208.29	208.25	208.05	206.79	204.65	201.84	198.47	194.74	190.64	186.38	181.96	177.42	173.15	168.96	165.04	161.30	157.64	154.17	150.88	147.68	144.57	141.65	138.72	135.99	133.34	130.80	128.34	125.98	123.72	121.45	119.28	117.21
];

mc_torque = mc_trq_eff_index;
mc_eff_trq_map_mot = griddata(rpm,torque,eff,rpm_buff,mc_torque');
mc_eff_trq_map_mot = ((mc_eff_trq_map_mot'));
[i,j] = find(isnan(mc_eff_trq_map_mot));
for index = 1:length(j)
    mc_eff_trq_map_mot(i,j) = 1;
end
mc_eff_trq_map = max(mc_eff_trq_map_mot, .8*ones(size(mc_eff_trq_map_mot)));

% Generating Efficiency Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eff = 0.01*[50	50	50	50	50	50	50	50	80	92	92 ...
50	50	50	50	50	50	53	90	92	93	93 ...
50	50	50	50	50	50	89	92	92.5	93	93 ...
50	50	50	50	50	53	90	92	94	95	94 ...
50	50	50	50	50	87.5	90.5	92	94	95	94 ...
50	50	50	50	53	89	91	92	94	95	93.5 ...
50	50	50	50	82	89	91.5	92.5	93.5	93.5	93 ...
50	50	50	50	86	89.5	92	93	93.5	93	93 ...
50	50	50	53	87	90.5	92.5	93.5	93	93	93 ...
50	50	50	82	88.5	91.5	93	93	92.5	92.5	92 ...
50	50	53	85	89	91.5	93	92.5	92	91.5	90 ...
50	50	74	87	89.5	91	92	91.5	91	90	89 ...
50	50	79	88.5	89.5	90	89.5	89	88.5	87	85 ...
50	54	85	88.5	88.5	88.5	86	84	81.5	78	74.5 ...
50	50	50	50	50	50	50	50	50	50	50 ...
3.27967E-06	0.246168297	0.394081489	0.492713983	0.563149944	0.61595451	0.657002739	0.689821321	0.716655075	0.739000747	0.757894605	0.77407685	0.788090281	0.80034198	0.811143222	0.820736088	0.829311677	0.837022851	0.84399334	0.850324365	0.85609953	...
0.861388497	0.866249772	0.870732852	0.874879894	0.878727027	0.882305391	0.885641968	0.888760256	0.89168081	0.89442169	0.896920244	0.89883978	0.900254323	0.90127229	...							
0.901938956	0.902341911	0.902477753	0.902425696	0.902192552	0.90300859	0.904850581	0.906479358	0.908022249	0.909374049	0.91060182	0.911777682	0.912790703	0.913765467	0.914585083	...
0.915326266	0.916037826	0.916622016	0.91719877	0.917647297	0.918098522	0.918430471	0.918774881	0.918987304	0.91921881	0.919345448	];

mc_eff_trq_map_gen = griddata(rpm,torque,eff,rpm_buff,mc_torque');
mc_eff_trq_map_gen = max((mc_eff_trq_map_gen'),.8*ones(size(mc_eff_trq_map_gen')));
[i,j] = find(isnan(mc_eff_trq_map_gen));
for index = 1:length(j)
    mc_eff_trq_map_gen(i,j) = 1;
end

% start of mc_pre_calculation
%Propelling Case Convert the above data to electrical power lost
mc_pwr_loss_prop_map = (mc_spd_eff_index' * mc_trq_eff_index).* (1-mc_eff_trq_map_mot) ./(mc_eff_trq_map_mot+(mc_eff_trq_map_mot==0)) .* (mc_eff_trq_map_mot~=0);
%populate the losses for zero spd and zero trq ; uses myinterp2 to extrapolate instead of saturating
mc_pwr_loss_prop_map = myint2 (mc_spd_eff_index(2:end),mc_trq_eff_index(2:end),mc_pwr_loss_prop_map(2:end,2:end), mc_spd_eff_index, mc_trq_eff_index,[1 1 1 1]);
mc_pwr_loss_prop_map = mc_pwr_loss_prop_map .* (mc_pwr_loss_prop_map>=0); % only nonnegative
mc_pwr_loss_prop_map(1,1) = 0; % zero speed, zero torque, zero losses

%Regenerative Case Convert the above data to mechanical power lost
mc_pwr_loss_regen_map = (mc_spd_eff_index' * mc_trq_eff_index).* (1-mc_eff_trq_map_gen);
%populate the losses for zero spd and zero trq ; uses myinterp2 to extrapolate instead of saturating
mc_pwr_loss_regen_map = myint2 (mc_spd_eff_index(2:end), mc_trq_eff_index(2:end),mc_pwr_loss_regen_map(2:end, 2:end), mc_spd_eff_index, mc_trq_eff_index,[1 1 1 1]); 
mc_pwr_loss_regen_map = mc_pwr_loss_regen_map .* (mc_pwr_loss_regen_map>=0);
mc_pwr_loss_regen_map = -fliplr(mc_pwr_loss_regen_map);
mc_pwr_loss_regen_map(1,:) = 0; 
mc_pwr_loss_regen_map(:,end)=0;
mc_pwr_loss_regen_map(1,1) = 0;

% While motoring, the electrical power must provide for mechanical power output and the losses.
mc_spd_prop_index = mc_spd_eff_index;
mc_trq_prop_index = mc_trq_eff_index;
mc_pwr_prop_map = mc_spd_prop_index' * mc_trq_prop_index + mc_pwr_loss_prop_map; % loss power
mc_pwr_prop_map(:,1)=0;

% While generating, the mechanical power must provide for electrical power supplied and the losses.
mc_spd_regen_index = mc_spd_eff_index;
mc_trq_regen_index = sort(-mc_trq_eff_index);
mc_pwr_regen_map = mc_spd_regen_index' * mc_trq_regen_index - (mc_pwr_loss_regen_map); % loss power
mc_pwr_regen_map(1,:) = 0; 
mc_pwr_regen_map(:,end)=0;


% Make sure that each row of the power tables is monotonically increasing.
for count = 1:size(mc_pwr_prop_map, 1), 
    for count2 = 2:size(mc_pwr_prop_map, 2),
        if mc_pwr_prop_map(count, count2) <= mc_pwr_prop_map(count, count2-1)  | isinf(mc_pwr_prop_map(count, count2)) | isnan(mc_pwr_prop_map(count, count2)),
            mc_pwr_prop_map(count, count2) = mc_pwr_prop_map(count, count2-1) + 0.1;
        end
        if mc_pwr_regen_map(count, count2) <= mc_pwr_regen_map(count, count2-1) | isinf(mc_pwr_regen_map(count, count2)) | isnan(mc_pwr_regen_map(count, count2)),
            mc_pwr_regen_map(count, count2) = mc_pwr_regen_map(count, count2-1) + 0.1;
        end
    end
end

% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mc_spd_cont_index_max 	= max(mc_spd_cont_index);
mc_trq_cont_map_max 	= max(mc_trq_cont_map);
mc_pwr_cont_map_max 	= max(mc_spd_cont_index .* mc_trq_cont_map);% Max motor power rating for road demand calculation

mc_spd_max_index_max 	= max(mc_spd_max_index);
mc_trq_max_map_max 	    = max(mc_trq_max_map);
mc_pwr_max_map_max 	    = max(mc_spd_max_index .* mc_trq_max_map);% Max motor power rating for road demand calculation

mc_pwr_max				= mc_pwr_max_map_max;% calculate maximum power (Watts)
mc_eff_max				= max(max(mc_eff_trq_map_mot));% calculate the maximum efficiency

% end of mc_pre_calculation


%%%% Added by THB %%%%%
%Voltage Effect on Maximum Torque Output
mc_rpm_T_max_270  = [
0	209.90
100	209.78
200	209.69
300	209.62
400	209.55
500	209.48
600	209.42
700	209.36
800	209.30
900	209.24
1000	209.19
1100	209.13
1200	209.08
1300	209.03
1400	208.98
1500	208.93
1600	208.88
1700	208.83
1800	208.78
1900	208.74
2000	208.69
2100	208.64
2200	208.60
2300	208.55
2400	208.47
2500	206.98
2600	204.02
2700	200.05
2800	195.35
2900	190.14
3000	184.58
3100	178.72
3200	173.23
3300	168.00
3400	163.03
3500	158.32
3600	153.89
3700	149.74
3800	145.76
3900	141.88
4000	138.28
4100	134.86
4200	131.54
4300	128.41
4400	125.37
4500	122.52
4600	119.76
4700	117.11
4800	114.55
4900	112.18
5000	109.81
5100	107.53
5200	105.36
5300	103.28
5400	101.29
5500	99.02
5600	97.13
5700	95.35
5800	93.56
5900	91.87
6000	90.27]; %data from Sachs
mc_torque_limit_270V_index=mc_rpm_T_max_270(:,1);
mc_torque_limit_270V_torque=max_power_factor*mc_rpm_T_max_270(:,2);
mc_rpm_T_max_270=[mc_torque_limit_270V_index,mc_torque_limit_270V_torque];

mc_rpm_T_max_345 = [0	209.90
100	209.78
200	209.69
300	209.62
400	209.55
500	209.48
600	209.42
700	209.36
800	209.30
900	209.24
1000	209.19
1100	209.13
1200	209.08
1300	209.03
1400	208.98
1500	208.93
1600	208.88
1700	208.83
1800	208.78
1900	208.74
2000	208.69
2100	208.64
2200	208.60
2300	208.55
2400	208.51
2500	208.47
2600	208.42
2700	208.38
2800	208.34
2900	208.29
3000	208.25
3100	208.05
3200	206.79
3300	204.65
3400	201.84
3500	198.47
3600	194.74
3700	190.64
3800	186.38
3900	181.96
4000	177.42
4100	173.15
4200	168.96
4300	165.04
4400	161.30
4500	157.64
4600	154.17
4700	150.88
4800	147.68
4900	144.57
5000	141.65
5100	138.72
5200	135.99
5300	133.34
5400	130.80
5500	128.34
5600	125.98
5700	123.72
5800	121.45
5900	119.28
6000	117.21];

mc_torque_limit_345V_index=mc_rpm_T_max_345(:,1);
mc_torque_limit_345V_torque=max_power_factor*mc_rpm_T_max_345(:,2);
mc_rpm_T_max_345=[mc_torque_limit_345V_index,mc_torque_limit_345V_torque];
