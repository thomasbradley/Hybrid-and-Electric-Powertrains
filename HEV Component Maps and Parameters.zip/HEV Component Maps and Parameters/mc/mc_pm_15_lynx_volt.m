%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_15_lynx_volt.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: 16-kW PM induction motor/inverter		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: A.Rousseau - ANL - 12/08/99			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 							    			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet for the DR156s/CR20-150		%
% motor/controller combination at 180 V, dated 10/1/94				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation	    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency/loss data appropriate to a 180-V system.				%
% Efficiency/loss grid is very coarse.								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 			    = 0.09; 
mc_coeff_regen_i_p 		    = 1;
mc_volt_min_i				= 150; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p					= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq                = 180; % Time the motor can remain at max torque
mc_mass 					= 22+10; % (kg), mass of motor and controller																		
mc_curr_max					= 225; % (A), maximum current allowed by the controller and motor
mc_spd_base 				= 1000*c_rpm_radps;% rad/s
mc_t_overtrq				= 30;%sec - time peak torque can be maintained

%%%%%%%%%%%%%%%%% PROPELLING DATA %%%%%%%%%%%%%%%%%%%%%%%
mc_volt_cont_prop_index = [150 200 250 300 350];
mc_spd_cont_prop_index 	= [0 500 1000 1500 2000 2500 3000 4000 4500 5000 5500]* c_rpm_radps;
mc_trq_cont_prop_map 	= [...
20 30 30 30 30 30 30 30 30 30 20;
20 30 30 30 30 30 30 30 30 30 20;
20 30 30 30 30 30 30 30 30 30 20;
20 30 30 30 30 30 30 30 30 30 20;
20 30 30 30 30 30 30 30 30 30 20];

mc_volt_max_prop_index  = mc_volt_cont_prop_index;
mc_spd_max_prop_index 	= mc_spd_cont_prop_index;
mc_trq_max_prop_map 		= 2.*mc_trq_cont_prop_map;

mc_spd_eff_prop_index 	= [0 500 1000 1500 2000 2500 3000 4000 4500 5000 5500]* c_rpm_radps;
mc_trq_eff_prop_index 	= [0 10 20 30 40 50 60 70 80 90];
mc_eff_trq_prop_map		= 0.01*0.95*[...
20.0	20.0	20.0	20.0	20.0	20.0	20.0	20.0	20.0	20.0;
20.0	94.2	90.2	86.3	82.7	79.3	76.2	73.3	70.7	68.2;
20.0	96.0	94.4	92.3	90.3	88.3	86.3	84.5	82.7	81.0;
20.0	96.4	95.7	94.4	93.1	91.7	90.3	89.0	87.7	86.4;
20.0	96.4	96.3	95.5	94.5	93.5	92.4	91.4	90.3	89.3;
20.0	96.2	96.6	96.1	95.3	94.5	93.7	92.9	92.0	91.2;
20.0	96.0	96.7	96.4	95.9	95.2	94.6	93.9	93.2	92.5;
20.0	95.8	96.8	96.6	96.2	95.7	95.2	94.6	94.0	93.4;
20.0	95.6	96.8	96.8	96.5	96.1	95.6	95.1	94.6	94.1;
20.0	95.3	96.8	96.9	96.7	96.4	96.0	95.5	95.1	94.6;
20.0	95.0	96.7	96.9	96.8	96.6	96.2	95.9	95.5	95.0];		

mc_trq_loss_prop_index = mc_trq_eff_prop_index;
mc_spd_loss_prop_index = mc_spd_eff_prop_index;
mc_pwr_prop_map 		  = mc_spd_eff_prop_index' * mc_trq_eff_prop_index;% motor power rating

%%%%%%%%%%%%%%%%% REGEN DATA %%%%%%%%%%%%%%%%%%%%%%%
mc_volt_cont_regen_index= [150 200 250 300 350];
mc_spd_cont_regen_index = mc_spd_cont_prop_index;
mc_trq_cont_regen_map 	= mc_trq_cont_prop_map;

mc_volt_max_regen_index = mc_volt_cont_regen_index;
mc_spd_max_regen_index 	= mc_spd_cont_regen_index;
mc_trq_max_regen_map 	= 2.*mc_trq_cont_regen_map;

mc_spd_eff_regen_index 	= [0 500 1000 1500 2000 2500 3000 4000 4500 5000 5500]* c_rpm_radps;
mc_trq_eff_regen_index 	= [-90 -80 -70 -60 -50 -40 -30 -20 -10 0];
mc_eff_trq_regen_map		= 0.01*0.95*[...
20.0	20.0	20.0	20.0	20.0	20.0	20.0	20.0	20.0	20.0;	
68.2	70.7	73.3	76.2	79.3	82.7	86.3	90.2	94.2	20.0;	
81.0	82.7	84.5	86.3	88.3	90.3	92.3	94.4	96.0	20.0;	
86.4	87.7	89.0	90.3	91.7	93.1	94.4	95.7	96.4	20.0;	
89.3	90.3	91.4	92.4	93.5	94.5	95.5	96.3	96.4	20.0;	
91.2	92.0	92.9	93.7	94.5	95.3	96.1	96.6	96.2	20.0;
92.5	93.2	93.9	94.6	95.2	95.9	96.4	96.7	96.0	20.0;
93.4	94.0	94.6	95.2	95.7	96.2	96.6	96.8	95.8	20.0;
94.1	94.6	95.1	95.6	96.1	96.5	96.8	96.8	95.6	20.0;
94.6	95.1	95.5	96.0	96.4	96.7	96.9	96.8	95.3	20.0;
95.0	95.5	95.9	96.2	96.6	96.8	96.9	96.7	95.0	20.0];		

mc_trq_loss_regen_index = mc_trq_eff_regen_index;
mc_spd_loss_regen_index = mc_spd_eff_regen_index;
mc_pwr_regen_map 			= mc_spd_eff_regen_index' * mc_trq_eff_regen_index;% motor power rating

%%%%%%%%%%%%%%%%% FURTHER CALCULATIONS %%%%%%%%%%%%%%%%%%%%%%%

% create torque loss tables using the efficiencyies tables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:size(mc_spd_loss_prop_index,2)
   for j=1:size(mc_trq_loss_prop_index,2)
      mc_trq_loss_prop_map(i,j) = -(1-mc_eff_trq_prop_map(i,j))*mc_trq_loss_prop_index(j);	
   end
end
for i=1:size(mc_spd_loss_regen_index,2)
   for j=1:size(mc_trq_loss_regen_index,2)
      mc_trq_loss_regen_map(i,j) = (1-mc_eff_trq_regen_map(i,j))*mc_trq_loss_regen_index(j);	
   end
end
clear i j

% calculate the max characteristics of the motor
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mc_spd_cont_prop_index_max 	= max(mc_spd_cont_prop_index);% rad/s
mc_trq_cont_prop_map_max 		= max(mc_trq_cont_prop_map);% N-m
mc_pwr_cont_prop_map_max 		= max(mc_spd_cont_prop_index * mc_trq_cont_prop_map');% Max motor power rating for road demand calculation
mc_spd_max_prop_index_max 		= max(mc_spd_max_prop_index);% rad/s
mc_trq_max_prop_map_max 		= max(mc_trq_max_prop_map);% N-m
mc_pwr_max_prop_map_max 		= max(mc_spd_max_prop_index * mc_trq_max_prop_map');% Max motor power rating for road demand calculation

mc_spd_cont_regen_index_max 	= max(mc_spd_cont_regen_index);% rad/s
mc_trq_cont_regen_map_max 		= max(mc_trq_cont_regen_map);% N-m
mc_pwr_cont_regen_map_max 		= max(mc_spd_cont_regen_index * mc_trq_cont_regen_map');% Max motor power rating for road demand calculation
mc_spd_max_regen_index_max 	= max(mc_spd_max_regen_index);% rad/s
mc_trq_max_regen_map_max 		= max(mc_trq_max_regen_map);% N-m
mc_pwr_max_regen_map_max 		= max(mc_spd_max_regen_index * mc_trq_max_regen_map');% Max motor power rating for road demand calculation

mc_pwr_max				        = mc_pwr_max_map_max;% calculate maximum power (Watts)
mc_eff_max							= max(max(mc_eff_trq_prop_map));% calculate the maximum efficiency


% motor characteristics used in the ptc and scaling files
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%calculate the maximum torque curve at the average voltage
mc_trq_max_prop_map_avg			= interp2(mc_volt_cont_prop_index,mc_spd_cont_prop_index,mc_trq_max_prop_map',...
   (max(mc_volt_cont_prop_index)-min(mc_volt_cont_prop_index))/2 + min(mc_volt_cont_prop_index),mc_spd_cont_prop_index)';
