%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		:  mc_pm_32_uqm_low_peak.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 	Unique Mobility 32-kW continuous	    %
% 53-kW peak PM motor/controller									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: UCDavis - 05/01/01					    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet for the SR218N/CA40-300L		%
% motor/controller combination (from www.uqm.com) 10/5/98			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.047; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 60; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= .05; % from 0 to 100 % of the torque in 50 ms
mc_mass 				= 61.15; % (kg), mass of motor and controller																		
mc_curr_max				= 300; % (A), maximum current allowed by the controller and motor
mc_spd_base				= 3000*c_rpm_radps;% rad/s
mc_t_max_trq            = 120; % Time the motor can remain at max torque

mc_spd_cont_index       = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_cont_map 	    = [150 150 150 150 137 112 90 76 65 60 46 42 42 ]; % (N*m)

mc_spd_max_index 	    = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_max_map 	        = [153.6000  153.6000  153.6000  153.6000  153.6000  152.7887  130.9618  114.5916  101.8592 91.6732   76.3944   65.4809   61.1155];  

mc_spd_eff_index 		= [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_eff_index 	    = [0    5.3333   26.6667   53.3333   80.0000  106.6667  133.3333  160.0000  186.6667 213.3333  240.0000];
mc_eff_trq_map		=  0.01*[...
60 80.5 85   88   88   86   85   86   80   79   79     
60 80.5 85   88   88   86   85   86   80   79   79
60 81   85   89   89   88   87   86   82   80   79.5
60 80   87   90   90.5 90   89   88   86   85   83
60 78   88   91.5 91.5 91   91   90   89   86   85
60 79   91   92.5 93   92.5 92   91   90   87   87
60 79   93   94   93.5 93   93   92   90   90   90    
60 86   93   94   94   93   92.5 92   92   92   92
60 79   90   92   93   92   91   91   91   91   91
60 79   86   91   92   92   92   92   92   92   92
60 77.5 86   91   92   92   92   92   92   92   92
60 77.5 83   90   90.5 90.5 90.5 90.5 90.5 90.5 90.5
60 77.5 81   90   90   90   90   90   90   90   90];   

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')