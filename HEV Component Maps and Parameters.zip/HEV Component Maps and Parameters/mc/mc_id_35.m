%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_id_35.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% AC motor model													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)						    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 									        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%     			Mutasim Salman										%
%     			General Motors										%
%     			(810)986-1238										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% A.Rousseau (ANL) - 11/19/99 - add the variable ptc_mc_volt_min	%
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% rotational inertia value based on estimate from the motor length  %
% of 5", rotor diameter of 6.614" and a rotor mass of 39kg			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i		 	= 70;
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_inertia_i_p 		    = 0.5 * 39 * (6.164 .* 2.54 ./ 100 ./ 2)^2;% kg-m^2
mc_mass 				= 115;% ass of the motor and controller in Kg
mc_spd_base 			= 3200 * c_rpm_radps;% rad/s
mc_curr_max				= 280; % (A), maximum current allowed by the controller and motor

mc_spd_cont_index       = [ .00,.07,.21,.36,.50,.64,.78,.83,1.00] .* 13000 * c_rpm_radps;% rad/s
mc_trq_cont_map         = [123.6,123.6,123.6,72.1,51.9,40.6,33.3,31.3,25.9];% N-m

mc_spd_max_index        = mc_spd_cont_index;% rad/s
mc_trq_max_map          = 2.* mc_trq_cont_map;

mc_spd_eff_index        = mc_spd_cont_index;% rad/s
mc_trq_eff_index        = [ .00,.03,.06,.09,.12,.15,.18,.27,.36,.45,.55,.64,.73,.82,.91,1.00] .* 330;% N-m
mc_eff_trq_map          = ...    
[0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00; ...
 0.00, 0.87, 0.88, 0.88, 0.87, 0.87, 0.86, 0.85, 0.83, 0.82, 0.81, 0.80, 0.79, 0.78, 0.77, 0.77; ...
 0.00, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.91, 0.91, 0.91, 0.90, 0.90, 0.90, 0.89, 0.89; ...
 0.00, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.92, 0.92, 0.92, 0.92, 0.91, 0.91, 0.91; ...
 0.00, 0.93, 0.94, 0.94, 0.94, 0.94, 0.93, 0.93, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.91, 0.91, 0.91, 0.91, 0.91, 0.91; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92];

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')