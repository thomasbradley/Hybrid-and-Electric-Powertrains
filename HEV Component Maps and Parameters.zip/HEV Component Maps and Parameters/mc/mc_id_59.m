%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_id_59.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			:  59 kW (continuous), AC induction  	    %
% motor/controller													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Marcus Menne, et al., "Energy-Efficiency Evaluation of Traction 	% 
% Drives for Electric Vehicles", Proceedings 15th Electric Vehicle 	%
% Symposium, Brussels 1998.											%
% Drive tested by Institute for Power Electronics and Electrical  	%
% Drives at Aachen University of Technology (Germany).				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% This is a prototype or small-production 59 kW, AC induction  		%
% motor/controller. Efficiency/loss data appropriate for a rated 	%
% voltage system.  (Voltage was notgiven in the source paper.)		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.0235; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 120; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 70;% sum of motor and controller mass																		
mc_curr_max				= 480; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= 3000 * c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000 6500 7000 7500 8000]* c_rpm_radps;
mc_trq_cont_map 	    = [190 190 190 190 190 190 180 160 128 118 99 80 70 60 50 42 0];

mc_spd_max_index 	    = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000 6500 7000 7500 8000]* c_rpm_radps;
mc_trq_max_map 	        = 1.*mc_trq_cont_map;

mc_spd_eff_index 		= [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000 6500 7000 7500 8000]* c_rpm_radps;
mc_trq_eff_index 	    = [0 25 50 75 100 125 150 175 200];
mc_eff_trq_map 		    = [...
      0.2   0.2   0.2   0.2   0.2   0.2   0.2   0.2   0.2
      0.2   0.7   0.69  0.67  0.64  0.62  0.59  0.55  0.55
      0.2   0.78  0.79  0.78  0.77  0.76  0.73  0.72  0.7
      0.2   0.82  0.837 0.835 0.83  0.82  0.79  0.78  0.77
      0.2   0.852 0.868 0.868 0.867 0.853 0.835 0.825 0.82
      0.2   0.874 0.89  0.889 0.885 0.87  0.857 0.848 0.836
      0.2   0.89  0.903 0.903 0.896 0.88  0.868 0.851 0.84
      0.2   0.9   0.91  0.908 0.897 0.88  0.86  0.84  0.84
      0.2   0.894 0.91  0.904 0.88  0.86  0.84  0.84  0.84
      0.2   0.893 0.904 0.89  0.86  0.84  0.84  0.84  0.84
      0.2   0.901 0.9   0.87  0.84  0.84  0.84  0.84  0.84
      0.2   0.902 0.887 0.85  0.84  0.84  0.84  0.84  0.84
      0.2   0.891 0.87  0.84  0.84  0.84  0.84  0.84  0.84
      0.2   0.883 0.86  0.84  0.84  0.84  0.84  0.84  0.84
      0.2   0.881 0.84  0.84  0.84  0.84  0.84  0.84  0.84
      0.2   0.878 0.84  0.84  0.84  0.84  0.84  0.84  0.84
      0.2   0.2   0.2   0.2   0.2   0.2   0.2   0.2   0.2];

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')