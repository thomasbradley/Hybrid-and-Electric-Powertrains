%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_prius.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 						    				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)			    			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%  The following data was provided for USCAR from:					%
%     Unique Mobility, Inc.											%
%		425 Corporate Circle										%
%		Golden, CO  80401											%
%		(303)278-2002												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:											%
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mot_tau	%
% P. Sharer (ANL) - 03/24/00 - variable names changed				%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_inertia_i_p			= 0.0226;% kg-m^2 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 120; % (V), minimum voltage allowed by the controller and motor
mc_mass 				= 38.1;% Mass of the motor and controller in Kg
mc_spd_base 			= 1000 *c_rpm_radps;% rad/s
mc_curr_max             = 70; %Added later.

mc_spd_cont_index       = [0 235 470 705 940 1175 1410 1645 1880 2115 2350 2585 2820 3055 3290 3525 3760 3995 4230 6000]*c_rpm_radps;% rad/s
mc_trq_cont_map         = [305.0 305.0 305.0 305.0 305.0 244.0 203.3 174.3 152.5 135.6 122.0 110.9 101.7 93.8 87.1 81.3 76.3 71.8 67.8 47.7];% N-m

mc_spd_max_index        = mc_spd_cont_index;% rad/s
mc_trq_max_map          = mc_trq_cont_map.*3;  %  

mc_spd_eff_index        = [0 500 1000 1500 2000 2500 3000 3500 4000 4500  6000]*c_rpm_radps;% rad/s
mc_trq_eff_index        = [0 5 35 65 95 125 155 185 215 245 275 305];% N-m

mc_eff_trq_map = 0.95*[...
	.905	.905   .905     .905    .905    .905    .905    .905    .905    .905    .905    .905; ...
	.905	0.87	0.9	    0.85	0.8	    0.76	0.72	0.68	0.65	0.62	0.59	0.56; ... 
	.905	0.85	0.94	0.91	0.89	0.86	0.83	0.81	0.78	0.76	0.74	0.72; ...
	.905	0.83	0.94	0.93	0.92	0.9	    0.88	0.86	0.78	0.76	0.74	0.72; ...
	.905	0.82	0.95	0.95	0.93	0.92	0.88	0.86	0.78	0.76	0.74	0.72; ...
	.905	0.81	0.95	0.95	0.94	0.92	0.88	0.86	0.78	0.76	0.74	0.72; ...
	.905	0.81	0.95	0.96	0.95	0.92	0.88	0.86	0.78	0.76	0.74	0.72; ...
	.905	0.8	    0.95	0.96	0.95	0.92	0.88	0.86	0.78	0.76	0.74	0.72; ...
	.905	0.8	    0.95	0.95	0.95	0.92	0.88	0.86	0.78	0.76	0.74	0.72; ...
	.905	0.79	0.95	0.95	0.95	0.92	0.88	0.86	0.78	0.76	0.74	0.72; ...	
	.905	0.79	0.95	0.95	0.95	0.92	0.88	0.86	0.78	0.76	0.74	0.72];

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')