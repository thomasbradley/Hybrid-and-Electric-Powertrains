%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_id_25.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			:  data file for the Solectria ACgtx20/AC300%
% AC induction motor/controller. P max = 25KW						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 									    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency/loss data appropriate to a 144-V system.				%
% Efficiency/loss grid is very coarse.								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.24; %unknown
mc_coeff_regen_i_p 	    = 1.0;
mc_volt_min_i			= 70; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 66+20/2.205;% sum of motor and controller mass																		
mc_curr_max				= 210; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= 3000 * c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 1500 3000 4500 6000 7500]* c_rpm_radps;
mc_trq_cont_map 	    = [55 55 55 39.5 35.9 32.3];

mc_spd_max_index 	    = [0 1500 3000 4500 6000 7500]* c_rpm_radps;
mc_trq_max_map 	        = 1.5.*mc_trq_cont_map;

mc_spd_eff_index 	    = [0 1500 3000 4500 6000 7500]* c_rpm_radps;
mc_trq_eff_index 	    = [0 5 10 15 20 25 30 35 40 45 50 55];
mc_eff_trq_map 		    = [...
	0.1	0.66	0.737	0.742	0.732	0.722	0.716	0.705	0.691	0.674	0.65	0.72
	0.1	0.74	0.8	    0.807	0.802	0.796	0.79	0.78	0.768	0.755	0.738	0.72
	0.1	0.82	0.863	0.872	0.872	0.87	0.864	0.855	0.845	0.836	0.826	0.72
	0.1	0.85	0.89	0.898	0.9	    0.899	0.886	0.855	0.845	0.836	0.826	0.72
	0.1	0.88	0.899	0.9	    0.885	0.899	0.886	0.855	0.845	0.836	0.826	0.72
	0.1	0.89	0.897	0.9	    0.885	0.899	0.886	0.855	0.845	0.836	0.826	0.72];

mc_pre_calculation

%Convert the above data to electrical power lost

%evaluatefile('mc1_pre_calculation','mc1_','mc_')