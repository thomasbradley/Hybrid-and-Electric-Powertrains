%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_32.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 32-kW PM induction motor/inverter		    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet for the SR180p/CR20-300	    %
% motor/controller combination at 195 V, dated 10/28/94				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency/loss data appropriate to a 195-V system.				%
% Efficiency/loss grid is very coarse.								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.0226; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 60; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 23.6+14.5; % (kg), mass of motor and controller																		
mc_curr_max				= 300; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= 1500*c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 500 1000 1500 2000 2500 3000 4000 5000 6000 7000]* c_rpm_radps;
mc_trq_cont_map 	    = [512 508.1 504.2 500.3 496.3	492.4 488.5 480.7 472.8 465 0]*4.448/3.281/12; % (N*m)

mc_spd_max_index 	    = [0 500 1000 1500 2000 2500 3000 4000 5000 6000 7000]* c_rpm_radps;
mc_trq_max_map 	        = 1.5.*mc_trq_cont_map;

mc_spd_eff_index 		= [0 500 1000 1500 2000 2500 3000 4000 5000 6000 7000]* c_rpm_radps;
mc_trq_eff_index 	    = [0 40 80 120 160 200 240 320 400 480 520]*4.448/3.281/12;
mc_eff_trq_map		    = 0.01*[...
	20		20		20		20		20		20		20		20		20		20		20
	20		38		49		52		57		60		60		52		45		43		43
	20		50		62		67		71.5	72.5	73		72		71		70		70
	20		52		65		71		74		76.5	77		77.5	77.5	76.7	76.7
	20		54		67		73		77		78.5	78		80		80.5	80.8	80.8
	20		58		70		76		78.5	81		82		83		83.5	83		83
	20		59		72		77		80		82.5	83.5	84.5	84.7	84.6	84.6
	20		60		75.5	80.5	83		84.5	85.4	86.5	86.6	86.8	86.8
	20		60		77		81.5	84		86		86.7	88.3	88.8	88.7	88.7
	20		55		77.5	83		86		87		88.4	89.7	90.5	91		91
	20		50		76		84		87		88.5	89.3	90.5	91.5	92		92];		

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')