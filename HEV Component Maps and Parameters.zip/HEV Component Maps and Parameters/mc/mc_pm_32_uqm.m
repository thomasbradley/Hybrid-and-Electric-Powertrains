%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		:  mc_pm_32_uqm.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 	Unique Mobility 32-kW continuous	    %
% 53-kW peak PM motor/controller									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: UCDavis - 05/01/01					    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet for the SR218N/CA40-300L		%
% motor/controller combination (from www.uqm.com) 10/5/98			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.047; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 60; % (V), minimum voltage allowed by the controller and motor
mc_volt_max             = 250;
mc_tau_i_p				= .05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= (105 + 28.8)/2.2; % (kg), mass of motor and controller																		
mc_curr_max				= 300; % (A), maximum current allowed by the controller and motor
mc_spd_base				= 3000*c_rpm_radps;% rad/s

mc_spd_cont_index       = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_cont_map 	    = [150 150 150 150 137 112 90 76 65 60 46 42 42 ]; % (N*m)

mc_spd_max_index 	    = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_max_map 	        = [240 240 240	240	240	238.7324146	204.627784	179.049311	159.1549431	143.2394488	119.3662073	102.313892	95.49296586];  

mc_spd_eff_index 		= [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_eff_index 	    = [0 5 25 50 75 100 125 150 175 200 225];
mc_eff_trq_map		=  0.01*[...
60 80.5 85   88   88   86   85   86   80   79   79     
60 80.5 85   88   88   86   85   86   80   79   79
60 81   85   89   89   88   87   86   82   80   79.5
60 80   87   90   90.5 90   89   88   86   85   83
60 78   88   91.5 91.5 91   91   90   89   86   85
60 79   91   92.5 93   92.5 92   91   90   87   87
60 79   93   94   93.5 93   93   92   90   90   90    
60 86   93   94   94   93   92.5 92   92   92   92
60 79   90   92   93   92   91   91   91   91   91
60 79   86   91   92   92   92   92   92   92   92
60 77.5 86   91   92   92   92   92   92   92   92
60 77.5 83   90   90.5 90.5 90.5 90.5 90.5 90.5 90.5
60 77.5 81   90   90   90   90   90   90   90   90];   
	
mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')

% %Convert the above data to electrical power lost
% mc_pwr_loss_map = mc_spd_eff_index(:) * mc_trq_eff_index(:)'./(mc_eff_trq_map+(mc_eff_trq_map==0)) .* (mc_eff_trq_map~=0) .* (1-mc_eff_trq_map);
% mc_pwr_loss_map = myint2 ( mc_spd_eff_index(2:length(mc_spd_eff_index)), mc_trq_eff_index(2:length(mc_trq_eff_index)), ...
% 	 mc_pwr_loss_map(2:length(mc_spd_eff_index), 2:length(mc_trq_eff_index)), mc_spd_eff_index, mc_trq_eff_index, ...
% 	 [1 1 1 1]); % %populate the losses for zero spd and zero trq ; uses myinterp2 to extrapolate instead of saturating
% mc_pwr_loss_map = mc_pwr_loss_map .* (mc_pwr_loss_map>=0); % only nonnegative
% mc_pwr_loss_map(1, 1) = 0; % zero speed, zero torque, zero losses
% 
% % While motoring, the electrical power must provide for mechanical power output and the losses.
% mc_pwr_prop_map = mc_spd_eff_index(:) * mc_trq_eff_index(:)' + mc_pwr_loss_map; % loss power
% mc_pwr_prop_map(:,1)=0;
% % While generating, the mechanical power must provide for electrical power supplied and the losses.
% mc_pwr_regen_map = mc_spd_eff_index(:) * mc_trq_eff_index(:)' - mc_pwr_loss_map; % loss power
% mc_pwr_regen_map(:,1)=0;
% 
% % Make sure that each row of the power tables is monotonically increasing.
% for i = 1:size(mc_pwr_prop_map, 1), 
%   for j = 2:size(mc_pwr_prop_map, 2),
% 	 if mc_pwr_prop_map(i, j) <= mc_pwr_prop_map(i, j-1),
% 		mc_pwr_prop_map(i, j) = mc_pwr_prop_map(i, j-1) + 0.1;
% 	 end
% 	 if mc_pwr_regen_map(i, j) <= mc_pwr_regen_map(i, j-1),
% 		mc_pwr_regen_map(i, j) = mc_pwr_regen_map(i, j-1) + 0.1;
% 	 end
%   end
% end
% clear i j
% 
% % maximum and minimum calculations
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% mc_spd_cont_index_max 	= max(mc_spd_cont_index);% rad/s
% mc_trq_cont_map_max 	= max(mc_trq_cont_map);% N-m
% mc_pwr_cont_map_max 	= max(mc_spd_cont_index .* mc_trq_cont_map);% Max motor power rating for road demand calculation
% 
% mc_spd_max_index_max 	= max(mc_spd_max_index);% rad/s
% mc_trq_max_map_max 		= max(mc_trq_max_map);% N-m
% mc_pwr_max_map_max 		= max(mc_spd_max_index .* mc_trq_max_map);% Max motor power rating for road demand calculation
% 
% mc_pwr_max				= mc_pwr_max_map_max;% calculate maximum power (Watts)
% mc_eff_max				= max(max(mc_eff_trq_map));% calculate the maximum efficiency

