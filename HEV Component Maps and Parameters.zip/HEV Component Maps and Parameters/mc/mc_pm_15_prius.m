%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_prius.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: P. Sharer ANL						    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%  The following data was provided for USCAR from:					%
%     Unique Mobility, Inc.											%
%		425 Corporate Circle										%
%		Golden, CO  80401											%
%		(303)278-2002												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:P. Sharer ANL 03/24/00 changed var names   %
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.0226;% kg-m^2 
mc_tau_i_p 				= 0.05; 							%0 to 100% of the max torque in 50ms
mc_coeff_regen_i_p 	    = 1;
mc_str_trq_i_p 		    = 200;% Torque provided by the generator required to start the engine (when the generator is used as a engine starter device)
mc_spd_opt_i_p 		    = 3600 .* c_rpm_radps;
mc_mass 				= 38.1;% Mass of the motor and controller in Kg
mc_spd_base 			= 2200* c_rpm_radps;% rad/s
mc_curr_max             = 70; %Added later.
mc_t_max_trq            = 180; % Time the motor can remain at max torque

mc_spd_cont_index =   [0 1500 2000 2500 3000 3500 4000 4500 5000 7267 ]*c_rpm_radps; % rad/s%<---corrected torque curve 01/22/01 Phil
mc_trq_cont_map = [55 55 55 55 55 55 48 41 36 26]+20;% N-m	<---corrected torque curve 01/22/01 Phil


mc_spd_max_index = mc_spd_cont_index; % rad/s
mc_trq_max_map = mc_trq_cont_map.*3;   %% N-m from INEL Prius generator file

mc_trq_eff_index =  [0 5 15 25 35 45 55];% N-m
mc_spd_eff_index  =  [0 500 1000 1500 2000 2500 3000 3500 4000 7267]*c_rpm_radps;

mc_eff_trq_map = ...
               0.95* [ 0.8	0.8	0.77	0.69	0.63	0.57	0.52;     ...
                       0.8	0.8	0.77	0.69	0.63	0.57	0.52;     ...
                       0.8	0.81 0.84	0.8	0.76	0.72	0.68;     ...
                       0.82	0.82	0.87	0.85	0.82	0.79	0.76;     ...
                       0.82	0.82	0.89	0.87	0.85	0.83	0.8 ;     ...
                       0.82	0.82	0.89	0.89	0.87	0.85	0.83;     ...
                       0.81	0.81	0.9	0.9	0.89	0.87	0.85;     ...
                       0.8	0.8	0.9	0.9	0.9	0.88	0.87;     ...
                       0.79	0.79	0.9	0.91	0.9	0.89	0.88;     ...
                       0.79	0.79	0.9	0.91	0.9	0.89	0.88 ];
               

mc_pre_calculation               
               
%evaluatefile('mc1_pre_calculation','mc1_','mc_')