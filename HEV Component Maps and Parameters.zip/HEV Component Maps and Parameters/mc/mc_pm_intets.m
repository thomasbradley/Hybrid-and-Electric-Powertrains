%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		:  mc_pm_intets.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			:  Unique Mobility INTETS          	    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			:  Gmonnet - 10/09/02					    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet for the INTETS        		%
% motor/controller combination (from www.uqm.com)       			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 	    									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 	Efficiency is not accurate							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.047; 
mc_coeff_regen_i_p 	    = 0.94;
mc_volt_min_i			= 250; % (V), minimum voltage allowed by the controller and motor
mc_volt_max             = 400;
mc_tau_i_p				= .05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 60; % Time the motor can remain at max torque
mc_mass 				= (74+16); % (kg), mass of motor and controller																		
mc_curr_max				= 400; % (A), maximum current allowed by the controller and motor
mc_spd_base				= 3000*c_rpm_radps;% rad/s

mc_spd_cont_index       = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000]* c_rpm_radps;
mc_trq_cont_map 	    = [120 120 120 120 120 112 92 78 66 56 49 41 39]; % (N*m)

mc_spd_max_index 	    = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000]* c_rpm_radps;
mc_trq_max_map 	        = [382 373 367 361 353 277 224 187 158 139 124 114 102];  

mc_spd_eff_index 		= [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000]* c_rpm_radps;
mc_trq_eff_index 	    = [0 5 25 50 75 100 125 150 175 200 225];
mc_eff_trq_map		=  0.01*[...
60 80.5 85   88   88   86   85   86   80   79   79     
60 80.5 85   88   88   86   85   86   80   79   79
60 81   85   89   89   88   87   86   82   80   79.5
60 80   87   90   90.5 90   89   88   86   85   83
60 78   88   91.5 91.5 91   91   90   89   86   85
60 79   91   92.5 93   92.5 92   91   90   87   87
60 79   93   94   93.5 93   93   92   90   90   90    
60 86   93   94   94   93   92.5 92   92   92   92
60 79   90   92   93   92   91   91   91   91   91
60 79   86   91   92   92   92   92   92   92   92
60 77.5 86   91   92   92   92   92   92   92   92
60 77.5 83   90   90.5 90.5 90.5 90.5 90.5 90.5 90.5
60 77.5 81   90   90   90   90   90   90   90   90];   
	
mc_pre_calculation


