%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_85_premag.m					  		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: PreMag Palmverter 85 kw Motor			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: UCDavis - VF RS - April 26 2001	    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency Map is not correct.  Used scaled UNIQ map.        		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		= 0.047; 
mc_coeff_regen_i_p 	= 1;
mc_volt_min_i		= 60; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p			= .05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq        = 180; % Time the motor can remain at max torque
mc_mass 			= (38+10+5)/2.2; % (kg), mass of motor and controller																		
mc_curr_max			= 300; % (A), maximum current allowed by the controller and motor
mc_spd_base			= 3000*c_rpm_radps;% rad/s

mc_spd_cont_index   = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_cont_map 	= [150 150 150 150 150 150 136.4185 119.3662  106.1033   95.4930   79.5775   68.2093   63.6620 ]; % (N*m)

mc_spd_max_index 	= [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_max_map 	    = [300 300 300	300 300 238.7324  204.6278 179.0493 159.1549  143.2394  119.3662  102.3139   95.4930];
mc_spd_eff_index 	= [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_eff_index 	= [0 5 25 50 75 100 125 150 175 200 225]./225*300;
mc_eff_trq_map		=  0.01*[...
60 80.5 85   88   88   86   85   86   80   79   79     
60 80.5 85   88   88   86   85   86   80   79   79
60 81   85   89   89   88   87   86   82   80   79.5
60 80   87   90   90.5 90   89   88   86   85   83
60 78   88   91.5 91.5 91   91   90   89   86   85
60 79   91   92.5 93   92.5 92   91   90   87   87
60 79   93   94   93.5 93   93   92   90   90   90    
60 86   93   94   94   93   92.5 92   92   92   92
60 79   90   92   93   92   91   91   91   91   91
60 79   86   91   92   92   92   92   92   92   92
60 77.5 86   91   92   92   92   92   92   92   92
60 77.5 83   90   90.5 90.5 90.5 90.5 90.5 90.5 90.5
60 77.5 81   90   90   90   90   90   90   90   90];

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')