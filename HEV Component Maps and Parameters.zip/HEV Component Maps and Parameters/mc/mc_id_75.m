%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mot_id_75.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			:  Westinghouse, 75 kW, AC Induction motor  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Lester, L.E., et al., "An Induction Motor Power Train for EVs--The%
% Right Power at the Right Price,"reprinted in Proceedings: Advanced% 
% Components for Electric and Hybrid Electric Vehicles, 10/27-28/93,%  
% Gaithersburg, MD. Mr. Lester was employed with Westinghouse in 	%
% Maryland at that time, and may be still.							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency/loss data appropriate for a 320 V system.				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.24; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 120; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 91;% sum of motor and controller mass																		
mc_curr_max				= 480; % (A), maximum current allowed by the controller and motor
mc_spd_base 			=  2000 * c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 1000 2000 3000 4000 5000 6000 7000 8000 9000 10000]* c_rpm_radps;
mc_trq_cont_map 	    = [200 200 200 175.2 131.4 105.1 87.6 75.1 65.7 58.4 52.5]*4.448/3.281;

mc_spd_max_index 	    = [0 1000 2000 3000 4000 5000 6000 7000 8000 9000 10000]* c_rpm_radps;
mc_trq_max_map 	        = 1.*mc_trq_cont_map;

mc_spd_eff_index 		= [0 1000 2000 3000 4000 5000 6000 7000 8000 9000 10000]* c_rpm_radps;
mc_trq_eff_index 	    = [0 20 40 60 80 100 120 140 160 180 200]*4.448/3.281;
mc_eff_trq_map 		    = [...
	0.7	0.7	    0.7	    0.7	    0.7 	0.7 	0.7 	0.7 	0.7 	0.7 	0.7
	0.7	0.77	0.81	0.82	0.82	0.82	0.81	0.8	    0.79	0.78	0.78
	0.7	0.82	0.85	0.86	0.87	0.88	0.87	0.86	0.86	0.86	0.85
	0.7	0.87	0.89	0.9	    0.9	    0.9	    0.9	    0.89	0.88	0.87	0.86
	0.7	0.88	0.91	0.91	0.91	0.9	    0.88	0.87	0.85	0.82	0.81
	0.7	0.89	0.91	0.91	0.9	    0.87	0.85	0.82	0.82	0.82	0.82
	0.7	0.9	    0.91	0.9	    0.86	0.82	0.79	0.78	0.79	0.79	0.79
	0.7	0.91	0.91	0.88	0.8	    0.78	0.78	0.78	0.78	0.78	0.78
	0.7	0.92	0.9	    0.8	    0.78	0.78	0.78	0.78	0.78	0.78	0.78
	0.7	0.92	0.88	0.78	0.78	0.78	0.78	0.78	0.78	0.78	0.78
	0.7	0.92	0.8	    0.78	0.78	0.78	0.78	0.78	0.78	0.78	0.78];

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')