%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		:  mc_pm_85_uqm.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 	85-kW continuous 170-kW peak            %
% PM motor/controller scaled from 32-kW continuous Unique Mobility 	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: UCDavis - 05/01/01					    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet for the SR218N/CA40-300L		%
% motor/controller combination (from www.uqm.com) 10/5/98			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = 0.1248; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 60; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= .05; % from 0 to 100 % of the torque in 50 ms
mc_mass 				= 163; % (kg), mass of motor and controller																		
mc_curr_max				= 300; % (A), maximum current allowed by the controller and motor
mc_spd_base				= 3000*c_rpm_radps;% rad/s
mc_t_max_trq                = 180; % Time the motor can remain at max torque

mc_spd_cont_index       = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_cont_map 	    = [399.9204  399.9204  399.9204  399.9204  365.2606  298.6072  239.9522  202.6263  173.2988  159.9681  122.6422 111.9777  111.9777]; % (N*m)

mc_spd_max_index 	    = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_max_map 	        = [464.0000  464.0000  464.0000  464.0000  464.0000  461.5493  395.6137  346.1620  307.6996 276.9296  230.7747  197.8069  184.6197];  

mc_spd_eff_index 		= [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
mc_trq_eff_index 	    = [0    9.6666   48.3334   96.6666  145.0000  193.3334  241.6666  290.0000  338.3334 386.6666  464.0000];
mc_eff_trq_map		=  0.01*[...
60 80.5 85   88   88   86   85   86   80   79   79     
60 80.5 85   88   88   86   85   86   80   79   79
60 81   85   89   89   88   87   86   82   80   79.5
60 80   87   90   90.5 90   89   88   86   85   83
60 78   88   91.5 91.5 91   91   90   89   86   85
60 79   91   92.5 93   92.5 92   91   90   87   87
60 79   93   94   93.5 93   93   92   90   90   90    
60 86   93   94   94   93   92.5 92   92   92   92
60 79   90   92   93   92   91   91   91   91   91
60 79   86   91   92   92   92   92   92   92   92
60 77.5 86   91   92   92   92   92   92   92   92
60 77.5 83   90   90.5 90.5 90.5 90.5 90.5 90.5 90.5
60 77.5 81   90   90   90   90   90   90   90   90];   

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')