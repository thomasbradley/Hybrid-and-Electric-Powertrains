%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_08.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: Unique Mobility 08-kW PM induction mot/inv%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99	    	    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet 								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
mc_inertia_i_p 		    = 0.014; 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 30; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= 0.05; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = 180; % Time the motor can remain at max torque
mc_mass 				= 14.1; % (kg), mass of motor and controller																		
mc_curr_max				= 300; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= 1000*c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000]* c_rpm_radps;
mc_trq_cont_map 	    = [18.36 18.36 18.15 18.04 17.94 17.83 17.73 17.62 17.57 17.17 0]*50/20.3353; % (N*m)

mc_spd_max_index 	    = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000]* c_rpm_radps;
mc_trq_max_map 	        = 1.*mc_trq_cont_map;

mc_spd_eff_index 		= [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000]* c_rpm_radps;
mc_trq_eff_index 	    = [0 20 40 60 80 100 120 140 160 180]*4.448/3.281/12*50/20.3353;
mc_eff_trq_map		    = [...
	0.1	0.1	    0.1	    0.1	    0.1	    0.1	    0.1	    0.1	    0.1	    0.1
	0.1	0.2	    0.3	    0.38	0.36	0.42	0.52	0.41	0.28	0.18
	0.1	0.34	0.6	    0.71	0.69	0.7	    0.71	0.63	0.57	0.46
	0.1	0.48	0.76	0.85	0.82	0.8	    0.79	0.74	0.71	0.63
	0.1	0.61	0.855	0.865	0.855	0.85	0.835	0.82	0.8	    0.74
	0.1	0.72	0.86	0.875	0.87	0.865	0.855	0.85	0.835	0.81
	0.1	0.8	    0.87	0.885	0.89	0.885	0.875	0.87	0.855	0.84
	0.1	0.85	0.88	0.9	    0.905	0.9	    0.89	0.88	0.87	0.86
	0.1	0.85	0.885	0.91	0.92	0.915	0.91	0.9	    0.885	0.88
	0.1	0.86	0.9	    0.92	0.925	0.925	0.92	0.91	0.9	    0.895
	0.1	0.875	0.905	0.92	0.93	0.93	0.93	0.925	0.92	0.91];		

mc_pre_calculation

%evaluatefile('mc1_pre_calculation','mc1_','mc_')