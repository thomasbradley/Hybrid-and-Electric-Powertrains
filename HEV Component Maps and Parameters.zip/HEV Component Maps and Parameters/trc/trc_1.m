%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file : trc_1.m   (For limited slip differential)       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description : Initialize the parameters used in the transfer case  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by: Robert Lawrie (CCI) - 7/1/2000                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files :                                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by : Robert Lawrie (CCI)                             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by : G.Monnet (ANL)- 10/02/2000                           % 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks :                                                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

trc_ratio_i_p		= 1;            % ratio of transfer case: 4x4 high = 1, low range typically 2.5-3.0
trc_inertia_i_p	    = 0;
trc_mass			= 20;
trc_spd_thresh_i	= 10;

%dimensionless - rear spd ratio index =.5+(rear axle spd-front axle spd)/(rear axle spd + front axle spd)/2
%determines the relative speed ratio between the front and rear axles
trc_rear_spd_ratio_index=[.470 .495 .505 .530];

% dimensionless - rear torque ratio map =.5+(rear axle spd-front axle spd)/(rear axle spd + front axle spd)/2
% determines the torque split (or ratio) between the front and rear axles
% data extrapolated from 'Car Suspension and Handling, third edition' D Bastow, G Howard
trc_rear_trq_ratio_map=[.9 .54 .54 .1];  % for limted slip differential

trc_trq_eff_index=[0 1e5];
trc_spd_eff_index=[0 1e5];
trc_trq_loss_index = trc_trq_eff_index;
trc_spd_loss_index = trc_spd_eff_index;
trc_eff_trq_map = ones(size(trc_trq_loss_index,2),size(trc_spd_loss_index,2))*.96;

% create final drive loss tables
for i=1:size(trc_trq_loss_index,2)
   for j=1:size(trc_spd_loss_index,2)
      trc_trq_loss_map(i,j) = (1-trc_eff_trq_map(i,j))*trc_trq_loss_index(i);	
   end
end
% calculate the maximum efficiency 
trc_eff_max=max(max(trc_eff_trq_map));

clear i j 