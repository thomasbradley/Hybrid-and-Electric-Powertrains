%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: eng_si_1000_30_M85_HOT					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% Univ. of Maryland 30kW M85 Engine									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: D. Yorke (ANL) - 02/20/01				    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 										    				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_vol_mass 						= 50;						% Capacity of tank in kg - approximate value
eng_mass 							= 131;							%eng_mass_block + eng_mass_radiator + eng_mass_vol + eng_tank_mass;
eng_tau_i_p							= 0.2; 						% 0 to 100% of max torque in 200ms - approximate value
eng_dn_i_p                          = 0.05;                     % 100% of max to 0 torque in 50ms
eng_spd_idle		 				= 650*c_rpm_radps;
eng_warmup_init_i_p				    = 0;							% This should normally by 0
eng_pwr_max							= 29820.0;					% Watts
eng_ex_gas_heat_cap = 1089;            % J/kgK  ave sens heat cap of exh gas (SAE #890798)

% Fuel Parameters for Diesel
eng_fuel_density_val                = 796.75;        % kg/m3 or g/L
eng_fuel_heating_val      			= 23150000;       % (J/kg)Specific LHV
eng_fuel_carbon_ratio  			    = 12/13.8;        % (kg/kg) ref:Dr. Rob Thring

% Baseline engine parameters
eng_displ_init						=	1000;		% cc
eng_inertia_i_p						=	0.3500;		% kg-m^2 - approximate value

eng_spd_opt							= 4500 * c_rpm_radps; % Optimal speed and power for operation in series configuration.  
eng_pwr_opt_i_p						= eng_pwr_max;
eng_spd_str_i_p						= 10; % speed level (Rd/s) the engine crank has to reach in order to start 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% maximum curves at each speed (closed and wide open throttle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hot max wide open throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_max_hot_index= [0 1000:500:5500]*c_rpm_radps;
eng_trq_max_hot_map= [0 40.7800   67.8000   67.8000   74.5800   74.5800   81.3600   61.0200 54.2400 0   0];        

% Mid speed is used in logic to limit closed and wide open torque curves
eng_spd_avg	= 0.5 * (eng_spd_max_hot_index(1) + eng_spd_max_hot_index(length(eng_spd_max_hot_index)));
      
% hot max closed throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_min_hot_index 	= eng_spd_max_hot_index;
eng_trq_min_hot_map= eng_trq_max_hot_map*-0.1;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% consumption table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_fuel_hot_index	= [1000:500:5500]*c_rpm_radps;
eng_trq_fuel_hot_index = [6.7800   13.5600   20.3400   27.1200   33.9000   40.6800   47.4600 54.2400   61.0200   67.8000   74.5800   81.3600]; % (Eqn B)

% Fuel rate tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table is fuel rate (kg/hr)
eng_fuel_hot_map = 1e-3*[...
    0.2599    0.3718    0.4624    0.5357    0.6061    0.6944    0.7807    0.8639    0.9518    1.0432    1.1475    1.2518;...
    0.4108    0.5576    0.6935    0.8036    0.9092    1.0416    1.1710    1.2959    1.4277    1.5648    1.7212    1.8777;...
    0.5733    0.7346    0.8933    1.0309    1.2219    1.3836    1.5390    1.6921    1.8777    2.0311    2.2342    2.4373;...
    0.6498    0.9128    1.0901    1.2832    1.5335    1.7166    1.9033    2.0935    2.3157    2.4975    2.7032    2.9490;...
    0.8142    1.0953    1.2959    1.5595    1.8256    2.0676    2.3420    2.5647    2.7881    3.0167    3.2543    3.5502;...
    1.0524    1.3588    1.6182    1.8832    2.1997    2.4677    2.7524    3.0452    3.3429    3.6511    3.8587    4.1419;...
    1.2913    1.6249    1.9269    2.3257    2.7141    2.9800    3.3285    3.8188    4.3129    4.7921    5.2713    5.7505;...
    1.6430    1.8650    2.3131    2.9055    3.3017    3.6319    4.1642    4.9290    5.5452    6.1613    6.7774    7.3936;...
    1.6430    1.8650    2.3131    2.9055    3.3017    3.6319    4.1642    4.9290    5.5452    6.1613    6.7774    7.3936;...
    1.6430    1.8650    2.3131    2.9055    3.3017    3.6319    4.1642    4.9290    5.5452    6.1613    6.7774    7.3936;];


eng_fmep_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

% engine torque (hot and cold) for fuel rate = 0g/s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_zero_fuel_hot_index = eng_spd_min_hot_index;
eng_trq_zero_fuel_hot_index = eng_trq_min_hot_map;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% emission table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Emission index tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table
% is fuel emission index (g/s). 
% Multiplication by 0.01 because original data is in %.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - HC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_hc_hot_index = eng_spd_fuel_hot_index;
eng_trq_hc_hot_index = eng_trq_fuel_hot_index;
eng_hc_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - CO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_co_hot_index = eng_spd_fuel_hot_index;
eng_trq_co_hot_index = eng_trq_fuel_hot_index;
eng_co_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - Nox
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_nox_hot_index = eng_spd_fuel_hot_index;
eng_trq_nox_hot_index = eng_trq_fuel_hot_index;
eng_nox_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - PM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_pm_hot_index = eng_spd_fuel_hot_index;
eng_trq_pm_hot_index = eng_trq_fuel_hot_index;
eng_pm_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% O2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_o2_hot_index = eng_spd_fuel_hot_index;
eng_trq_o2_hot_index = eng_trq_fuel_hot_index;
eng_o2_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exhaust table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_equiv_hot_index =     eng_spd_fuel_hot_index;
eng_trq_equiv_hot_index =     eng_trq_fuel_hot_index;
eng_equiv_hot_map       =     ones(length(eng_spd_equiv_hot_index),length(eng_trq_equiv_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Thermal Calculations table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Heat rejection variable Presid data table
eng_spd_htrej_hot_index = eng_spd_fuel_hot_index;
eng_trq_htrej_hot_index = eng_trq_fuel_hot_index;
eng_htrej_hot_map       = zeros(length(eng_spd_htrej_hot_index),length(eng_trq_htrej_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Heat Transfer
%the following is a new thermal model of the engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

env_air_temp_amb = 20;            % C environmental variable ambient air temperature         

eng_spd_ex_gas_flow_hot_index =   eng_spd_fuel_hot_index;
eng_trq_ex_gas_flow_hot_index =   eng_trq_fuel_hot_index;
eng_ex_gas_flow_hot_map       =   eng_fuel_hot_map *(1+20);                  % g/s  ex gas flow map:  for CI engines, exflow=(fuel use)*[1 + (ave A/F ratio)]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eng_v0x\fuel use, thermal and emissions\thermal\fc heat net calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_ex_pwr_map = eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index;
eng_ex_temp_map = eng_ex_pwr_map./(eng_ex_gas_flow_hot_map *1089/1000) + 20;  % W   EO ex gas temp = Q/(MF*cp) + Tamb (assumes engine tested ~20 C)
eng_spd_ex_temp_index = eng_spd_fuel_hot_index; 
eng_trq_ex_temp_index = eng_trq_fuel_hot_index;

eng_temp_operating = 90;
eng_ex_temp_operating = mean(mean(eng_ex_temp_map));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Find appropriate fuel rate to normalize with respect to.
% Tom Kenney has approved this approach.
% when the simulation is started, the engine is typically assumed to be at ambient temperature
% The normalizing fuel rate mdotf_base is chosen so as to replicate the warmup trend for the engine
% subjected to a certain drive cycle. In most cases, the normalizing fuel rate will not equal the max fuel rate

eng_temp1 = max(eng_spd_fuel_hot_index)/(1.4*eng_spd_idle);
if min(eng_trq_fuel_hot_index)<=eng_temp1 & eng_temp1<=max(eng_trq_fuel_hot_index),
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map, eng_temp1, 1.4*eng_spd_idle); % Kg/s
elseif eng_temp1<min(eng_trq_fuel_hot_index),
  eng_temp2 = min(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
else
  eng_temp2 = max(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
end

clear eng_temp1 eng_temp2 eng_temp3


% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_trq_hot_max	= max(eng_trq_max_hot_map); % N-m
eng_spd_hot_max	= max(eng_spd_max_hot_index(max(find(eng_trq_max_hot_map>0)))); % rad/s
eng_pwr_hot_max = max(eng_spd_max_hot_index.* eng_trq_max_hot_map); % W
eng_pwr_max_hot_map = eng_spd_max_hot_index.* eng_trq_max_hot_map; % W

%calculate the maximum efficiency
eng_eff_hot_map=eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index/eng_fuel_heating_val./(eng_fuel_hot_map);
eng_eff_hot_map_lim=eng_eff_hot_map;

[Q,lih_max]=max(eng_spd_fuel_hot_index);
[R,colh_max]=max(eng_trq_fuel_hot_index);
for lih=1:lih_max,
   for colh=1:colh_max,
      trq_val_hot=interp1(eng_spd_max_hot_index,eng_trq_max_hot_map,eng_spd_fuel_hot_index(lih));
      if eng_trq_fuel_hot_index(colh)>trq_val_hot,
         eng_eff_hot_map_lim(lih,colh)=0;
      end 
   end
end 

eng_eff_max=max(max(eng_eff_hot_map_lim));
eng_eff_hot_map=eng_eff_hot_map_lim;
[lin,col]=find(eng_eff_hot_map_lim==eng_eff_max);
eng_spd_max_hot_eff = eng_spd_fuel_hot_index(lin);
eng_trq_max_hot_eff = eng_trq_fuel_hot_index(col);
eng_pwr_max_hot_eff = eng_spd_fuel_hot_index(lin)*eng_trq_fuel_hot_index(col);
eng_pwr_max_eff = eng_pwr_max_hot_eff;
clear lih colh  Q R  colh_max lih_max  eng_eff_hot_map_lim trq_val_hot 
