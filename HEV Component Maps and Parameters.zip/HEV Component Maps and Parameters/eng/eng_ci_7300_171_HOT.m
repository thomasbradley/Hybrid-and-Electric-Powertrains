%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: eng_ci_7300_171.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: Detroit Diesel Corp. Series 30            %
%                         7.3L (171kW) CI Engine 	            	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 20/09/01				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_vol_mass 						= 100;						% Capacity of tank in kg - approximate value
eng_mass 							= 720;					    % eng_mass_block + eng_mass_radiator + eng_mass_vol + eng_tank_mass;
eng_tau_i_p							= 0.2; 						% 0 to 100% of max torque in 200ms - approximate value
eng_dn_i_p                          = 0.05;                     % 100% of max to 0 torque in 50ms
eng_spd_idle		 			    = 650*c_rpm_radps;
eng_warmup_init_i_p 			    = 0;					    % This should normally by 0
eng_pwr_max							= 171000;					% Watts
eng_ex_gas_heat_cap = 1089;            % J/kgK  ave sens heat cap of exh gas (SAE #890798)

% Fuel Parameters for Diesel
eng_fuel_density_val                = 835;        % kg/m3 or g/L
eng_fuel_heating_val      			= 42500000;       % (J/kg)Specific LHV
eng_fuel_carbon_ratio  			    = 12/13.8;        % (kg/kg) ref:Dr. Rob Thring

% Baseline engine parameters
eng_displ_init						= 7300;		% cc
eng_inertia_i_p						= 0.13;		% kg-m^2 - approximate value

eng_spd_opt							= 4500 * c_rpm_radps; % Optimal speed and power for operation in series configuration.  
eng_pwr_opt_i_p						= eng_pwr_max;
eng_spd_str_i_p						= 10;                 % speed level (Rd/s) the engine crank has to reach in order to start 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% maximum curves at each speed (closed and wide open throttle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hot max wide open throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_max_hot_index= [0 800 1200 1300 1320 1340 1360 1380 1400 1420 1440 1460 1480 1500 1520 1540 1560 1580 1600 1620 1640 1660 1680 1700 1800 1900 2000 2100 2200 2300   2400    2500]*c_rpm_radps;
eng_trq_max_hot_map= [0 432  614  637  644  655  661  672  677  702  727  750  774  796 799  803 806  809  812  811  809  808  807  806  800  806  790  763  734  702   0   0];        

% Mid speed is used in logic to limit closed and wide open torque curves
eng_spd_avg	= 0.5 * (eng_spd_max_hot_index(1)+ eng_spd_max_hot_index(length(eng_spd_max_hot_index)));
      
% hot max closed throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_min_hot_index 	= eng_spd_max_hot_index;
eng_trq_min_hot_map= -0.1*eng_trq_max_hot_map;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% consumption table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_fuel_hot_index = [800 1200 1300 1320 1340 1360 1380 1400 1420 1440 1460 1480 1500 1520 1540 1560 1580 1600 1620 1640 1660 1680 1700 1800 1900 2000 2100 2200 2300]*c_rpm_radps;
eng_trq_fuel_hot_index = [84  168  252  336  420  504  588  672  756];

% Fuel rate tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table is fuel rate (kg/hr)

eng_fuel_hot_map =1e-3*[    
    0.4037    0.7340    1.0359    1.3445    1.6556    1.9717    2.2828    2.5956    2.9050
    0.7098    1.2905    1.8214    2.3639    2.9109    3.4667    4.0137    4.5637    5.1077
    0.7991    1.3980    1.9731    2.5514    3.1257    3.7127    4.2926    4.8804    5.4762
    0.8175    1.4195    2.0035    2.5887    3.1682    3.7611    4.3473    4.9426    5.5488
    0.8361    1.4410    2.0338    2.6260    3.2104    3.8093    4.4018    5.0044    5.6211
    0.8549    1.4626    2.0642    2.6632    3.2525    3.8572    4.4558    5.0658    5.6930
    0.8739    1.4841    2.0946    2.7003    3.2945    3.9048    4.5095    5.1268    5.7646
    0.8931    1.5056    2.1249    2.7374    3.3362    3.9521    4.5629    5.1874    5.8358
    0.9100    1.5299    2.1553    2.7737    3.3830    4.0076    4.6281    5.2615    5.9192
    0.9270    1.5542    2.1856    2.8100    3.4298    4.0629    4.6933    5.3356    6.0025
    0.9442    1.5787    2.2160    2.8462    3.4765    4.1183    4.7585    5.4097    6.0859
    0.9615    1.6032    2.2463    2.8823    3.5232    4.1736    4.8237    5.4838    6.1693
    0.9789    1.6278    2.2767    2.9183    3.5699    4.2289    4.8888    5.5579    6.2527
    0.9964    1.6525    2.3070    2.9542    3.6166    4.2842    4.9540    5.6320    6.3360
    1.0140    1.6772    2.3374    2.9901    3.6633    4.3394    5.0192    5.7061    6.4194
    1.0317    1.7020    2.3678    3.0259    3.7099    4.3947    5.0844    5.7802    6.5028
    1.0496    1.7270    2.3981    3.0616    3.7565    4.4498    5.1496    5.8543    6.5861
    1.0676    1.7519    2.4285    3.0972    3.8030    4.5050    5.2148    5.9284    6.6695
    1.0869    1.7770    2.4612    3.1399    3.8535    4.5649    5.2827    6.0089    6.7600
    1.1063    1.8022    2.4940    3.1826    3.9041    4.6248    5.3507    6.0895    6.8507
    1.1259    1.8274    2.5268    3.2255    3.9548    4.6849    5.4188    6.1702    6.9415
    1.1456    1.8527    2.5598    3.2685    4.0055    4.7450    5.4870    6.2511    7.0325
    1.1655    1.8781    2.5927    3.3115    4.0563    4.8053    5.5552    6.3322    7.1237
    1.2670    2.0061    2.7584    3.5283    4.3114    5.1077    5.8974    6.7399    7.5824
    1.3374    2.1640    2.9674    3.7894    4.6322    5.4751    6.3226    7.2258    8.1290
    1.4078    2.3268    3.1822    4.0572    4.9616    5.8512    6.7580    7.7234    8.6888
    1.4885    2.5047    3.4183    4.3217    5.2481    6.2362    7.1677    8.1917    9.2157
    1.5983    2.6896    3.6706    4.6407    5.6355    6.6964    7.6968    8.7963    9.8959
    1.7128    2.8822    3.9334    4.9729    6.0389    7.1759    8.2478    9.4261   10.6043]*1.0195;

eng_fmep_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

% engine torque (hot and cold) for fuel rate = 0g/s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_zero_fuel_hot_index = eng_spd_min_hot_index;
eng_trq_zero_fuel_hot_index = eng_trq_min_hot_map;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% emission table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Emission index tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table
% is fuel emission index (g/s). 
% Multiplication by 0.01 because original data is in %.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - HC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_hc_hot_index = eng_spd_fuel_hot_index;
eng_trq_hc_hot_index = eng_trq_fuel_hot_index;
eng_hc_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - CO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_co_hot_index = eng_spd_fuel_hot_index;
eng_trq_co_hot_index = eng_trq_fuel_hot_index;
eng_co_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - Nox
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_nox_hot_index = eng_spd_fuel_hot_index;
eng_trq_nox_hot_index = eng_trq_fuel_hot_index;
eng_nox_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - PM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_pm_hot_index = eng_spd_fuel_hot_index;
eng_trq_pm_hot_index = eng_trq_fuel_hot_index;
eng_pm_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% O2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_o2_hot_index = eng_spd_fuel_hot_index;
eng_trq_o2_hot_index = eng_trq_fuel_hot_index;
eng_o2_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exhaust table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HOT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_equiv_hot_index =     eng_spd_fuel_hot_index;
eng_trq_equiv_hot_index =     eng_trq_fuel_hot_index;
eng_equiv_hot_map       =     ones(length(eng_spd_equiv_hot_index),length(eng_trq_equiv_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Thermal Calculations table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Heat rejection variable Presid data table

eng_spd_htrej_hot_index = eng_spd_fuel_hot_index;
eng_trq_htrej_hot_index = eng_trq_fuel_hot_index;
eng_htrej_hot_map       = zeros(length(eng_spd_htrej_hot_index),length(eng_trq_htrej_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Heat Transfer
%the following is a new thermal model of the engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

env_air_temp_amb = 20;            % C environmental variable ambient air temperature         


eng_spd_ex_gas_flow_hot_index =   eng_spd_fuel_hot_index;
eng_trq_ex_gas_flow_hot_index =   eng_trq_fuel_hot_index;
eng_ex_gas_flow_hot_map       =   eng_fuel_hot_map *(1+20);                  % g/s  ex gas flow map:  for CI engines, exflow=(fuel use)*[1 + (ave A/F ratio)]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eng_v0x\fuel use, thermal and emissions\thermal\fc heat net calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_ex_pwr_map = eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index;
eng_ex_temp_map = eng_ex_pwr_map./(eng_ex_gas_flow_hot_map *1089/1000) + 20;  % W   EO ex gas temp = Q/(MF*cp) + Tamb (assumes engine tested ~20 C)
eng_spd_ex_temp_index = eng_spd_fuel_hot_index; 
eng_trq_ex_temp_index = eng_trq_fuel_hot_index;

eng_temp_operating = 90;
eng_ex_temp_operating = mean(mean(eng_ex_temp_map));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Find appropriate fuel rate to normalize with respect to.
% Tom Kenney has approved this approach.
% when the simulation is started, the engine is typically assumed to be at ambient temperature
% The normalizing fuel rate mdotf_base is chosen so as to replicate the warmup trend for the engine
% subjected to a certain drive cycle. In most cases, the normalizing fuel rate will not equal the max fuel rate

eng_temp1 = max(eng_spd_fuel_hot_index)/(1.4*eng_spd_idle);
if min(eng_trq_fuel_hot_index)<=eng_temp1 & eng_temp1<=max(eng_trq_fuel_hot_index),
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map, eng_temp1, 1.4*eng_spd_idle); % Kg/s
elseif eng_temp1<min(eng_trq_fuel_hot_index),
  eng_temp2 = min(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
else
  eng_temp2 = max(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
end

clear eng_temp1 eng_temp2 eng_temp3


% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_trq_hot_max	= max(eng_trq_max_hot_map); % N-m
eng_spd_hot_max	= max(eng_spd_max_hot_index(max(find(eng_trq_max_hot_map>0)))); % rad/s
eng_pwr_hot_max = max(eng_spd_max_hot_index.* eng_trq_max_hot_map); % W
eng_pwr_max_hot_map = eng_spd_max_hot_index.* eng_trq_max_hot_map; % W

%calculate the maximum efficiency
eff_hot=eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index/eng_fuel_heating_val./(eng_fuel_hot_map);

eff_hot_lim=eff_hot;

[Q,lih_max]=max(eng_spd_fuel_hot_index);
[R,colh_max]=max(eng_trq_fuel_hot_index);
for lih=1:lih_max,
   for colh=1:colh_max,
      trq_val_hot=interp1(eng_spd_max_hot_index,eng_trq_max_hot_map,eng_spd_fuel_hot_index(lih));
      if eng_trq_fuel_hot_index(colh)>trq_val_hot,
         eff_hot_lim(lih,colh)=0;
      end 
   end
end 

eng_eff_max=max(max(eff_hot_lim));
eff_hot=eff_hot_lim;
[lin,col]=find(eff_hot_lim==eng_eff_max);
eng_spd_max_hot_eff = eng_spd_fuel_hot_index(lin);
eng_trq_max_hot_eff = eng_trq_fuel_hot_index(col);
eng_pwr_max_hot_eff = eng_spd_fuel_hot_index(lin)*eng_trq_fuel_hot_index(col);
eng_pwr_max_eff = eng_pwr_max_hot_eff;
clear lih colh  Q R  colh_max lih_max  eff_hot_lim trq_val_hot 
