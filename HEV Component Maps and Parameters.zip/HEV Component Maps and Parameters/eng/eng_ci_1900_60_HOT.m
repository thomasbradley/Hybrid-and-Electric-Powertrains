
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: 	 eng_ci_1900_60							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 1.9L (60kW) CI Engine	    				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: D. Yorke (ANL) - 02/20/01					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_vol_mass 						= 50;						% Capacity of tank in kg - approximate value
eng_mass 							= 200;							%eng_mass_block + eng_mass_radiator + eng_mass_vol + eng_tank_mass;
eng_tau_i_p							= 0.2; 						% 0 to 100% of max torque in 200ms - approximate value
eng_dn_i_p                          = 0.05;                     % 100% of max to 0 torque in 50ms
eng_spd_idle		 				= 650*c_rpm_radps;
eng_warmup_init_i_p 				= 0;							% This should normally by 0
eng_pwr_max							= 66811.2;					% Watts

% Fuel Parameters for Diesel
eng_fuel_density_val                = 835;        % kg/m3 or g/L
eng_fuel_heating_val      			= 42500000;       % (J/kg)Specific LHV
eng_fuel_carbon_ratio  			    = 12/13.8;        % (kg/kg) ref:Dr. Rob Thring

% Baseline engine parameters
eng_displ_init						=	1700;		% cc
eng_inertia_i_p						=	0.07;		% kg-m^2 - approximate value

eng_spd_opt							= 4500 * c_rpm_radps; % Optimal speed and power for operation in series configuration.  
eng_pwr_opt_i_p						= eng_pwr_max;
eng_spd_str_i_p						= 10; % speed level (Rd/s) the engine crank has to reach in order to start 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% maximum curves at each speed (closed and wide open throttle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hot max wide open throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_max_hot_index= [0 750:250:5000]*c_rpm_radps;
eng_trq_max_hot_map= [0 89.61 119.48 131.81 148.48 167.77 177.48 180.090 178.35...
	177.48 177.48 175.74 174.00 168.20 159.50 145.00 123.98 0   0];        

% Mid speed is used in logic to limit closed and wide open torque curves
eng_spd_avg	= 0.5 * (eng_spd_max_hot_index(1) + eng_spd_max_hot_index(length(eng_spd_max_hot_index)));
      
% hot max closed throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_min_hot_index 	= eng_spd_max_hot_index;
eng_trq_min_hot_map= eng_trq_max_hot_map*-0.2;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% consumption table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_fuel_hot_index	= [750:250:4500]*c_rpm_radps;
eng_trq_fuel_hot_index  = [1:12 12.4]*14.5; % (Eqn B)

% Fuel rate tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table is fuel rate (kg/hr)

eng_fuel_hot_map =1e-3*[...
  0.2297    0.2961    0.2932    0.3543    0.4097    0.4916    0.5558    0.6327    0.7118    0.8067    0.9291    1.0174    1.0473;...
  0.2586    0.3121    0.3657    0.4471    0.5251    0.6099    0.6968    0.7930    0.8921    0.9996    1.1089    1.2147    1.2552;...
  0.2873    0.3279    0.4381    0.5399    0.6406    0.7276    0.8378    0.9532    1.0724    1.1916    1.2875    1.4109    1.4644;...
  0.3163    0.3859    0.5296    0.6403    0.7624    0.8731    0.9965    1.1236    1.2470    1.3792    1.5172    1.6475    1.6867;...
  0.3691    0.4857    0.6200    0.7499    0.8968    1.0319    1.1677    1.2991    1.4349    1.5722    1.7051    1.8512    1.9038;...
  0.4176    0.5584    0.7238    0.8739    1.0334    1.1844    1.3404    1.4914    1.6323    1.7715    1.9208    2.0651    2.1234;...
  0.4745    0.6377    0.8285    0.9908    1.1768    1.3438    1.5146    1.6855    1.8364    1.9835    2.1609    2.3460    2.4242;...
  0.5272    0.7149    0.9395    1.1135    1.3075    1.5058    1.6977    1.8896    2.0689    2.2671    2.4242    2.6320    2.7197;...
  0.5730    0.8119    1.0509    1.2388    1.4441    1.6703    1.8918    2.0971    2.2862    2.5170    2.7177    2.9369    3.0348;...
  0.6757    0.9338    1.1920    1.3818    1.5817    1.8449    2.0992    2.3283    2.5737    2.7965    3.0204    3.2950    3.4048;...
  0.8609    1.0966    1.3324    1.5353    1.7889    2.0398    2.3126    2.5662    2.8129    3.0706    3.3475    3.6518    3.7736;...
  1.2282    1.3582    1.4881    1.7302    1.9929    2.2144    2.5318    2.7990    3.0559    3.3511    3.6862    4.0213    4.1554;...
  1.3128    1.4868    1.6608    1.9297    2.1748    2.4580    2.7569    3.0622    3.3738    3.6854    4.0017    4.3275    4.4718;...
  1.5269    1.6872    1.8474    2.1393    2.3620    2.6927    2.9998    3.3338    3.6746    4.0154    4.3427    4.7375    4.8954;...
  1.4126    1.7926    2.1726    2.3591    2.6620    2.9255    3.2625    3.5852    3.9849    4.3381    4.7127    5.1197    5.2903;...
  2.2871    2.4105    2.5339    2.6573    2.9799    3.1887    3.5474    3.9024    4.2535    4.6692    5.0108    5.4208    5.6015]*1.0195;

eng_fmep_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

% engine torque (hot and cold) for fuel rate = 0g/s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_zero_fuel_hot_index = eng_spd_min_hot_index;
eng_trq_zero_fuel_hot_index = eng_trq_min_hot_map;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% emission table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Emission index tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table
% is fuel emission index (g/s). 
% Multiplication by 0.01 because original data is in %.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - HC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_hc_hot_index = eng_spd_fuel_hot_index;
eng_trq_hc_hot_index = eng_trq_fuel_hot_index;
eng_hc_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - CO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_co_hot_index = eng_spd_fuel_hot_index;
eng_trq_co_hot_index = eng_trq_fuel_hot_index;
eng_co_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - Nox
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_nox_hot_index = eng_spd_fuel_hot_index;
eng_trq_nox_hot_index = eng_trq_fuel_hot_index;
eng_nox_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - PM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_pm_hot_index = eng_spd_fuel_hot_index;
eng_trq_pm_hot_index = eng_trq_fuel_hot_index;
eng_pm_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% O2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_o2_hot_index = eng_spd_fuel_hot_index;
eng_trq_o2_hot_index = eng_trq_fuel_hot_index;
eng_o2_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exhaust table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HOT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_equiv_hot_index =     eng_spd_fuel_hot_index;
eng_trq_equiv_hot_index =     eng_trq_fuel_hot_index;
eng_equiv_hot_map       =     ones(length(eng_spd_equiv_hot_index),length(eng_trq_equiv_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Thermal Calculations table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Heat rejection variable Presid data table

eng_spd_htrej_hot_index = eng_spd_fuel_hot_index;
eng_trq_htrej_hot_index = eng_trq_fuel_hot_index;
eng_htrej_hot_map       = zeros(length(eng_spd_htrej_hot_index),length(eng_trq_htrej_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Heat Transfer
%the following is a new thermal model of the engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

env_air_temp_amb = 20;            % C environmental variable ambient air temperature         

eng_spd_ex_gas_flow_hot_index =   eng_spd_fuel_hot_index;
eng_trq_ex_gas_flow_hot_index =   eng_trq_fuel_hot_index;
eng_ex_gas_flow_hot_map       =   eng_fuel_hot_map *(1+20);                  % g/s  ex gas flow map:  for CI engines, exflow=(fuel use)*[1 + (ave A/F ratio)]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eng_v0x\fuel use, thermal and emissions\thermal\fc heat net calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_ex_pwr_map = eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index;
eng_ex_temp_map = eng_ex_pwr_map./(eng_ex_gas_flow_hot_map *1089/1000) + 20;  % W   EO ex gas temp = Q/(MF*cp) + Tamb (assumes engine tested ~20 C)
eng_spd_ex_temp_index = eng_spd_fuel_hot_index; 
eng_trq_ex_temp_index = eng_trq_fuel_hot_index;

eng_temp_operating = 90;
eng_ex_temp_operating = mean(mean(eng_ex_temp_map));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Find appropriate fuel rate to normalize with respect to.
% Tom Kenney has approved this approach.
% when the simulation is started, the engine is typically assumed to be at ambient temperature
% The normalizing fuel rate mdotf_base is chosen so as to replicate the warmup trend for the engine
% subjected to a certain drive cycle. In most cases, the normalizing fuel rate will not equal the max fuel rate

eng_temp1 = max(eng_spd_fuel_hot_index)/(1.4*eng_spd_idle);
if min(eng_trq_fuel_hot_index)<=eng_temp1 & eng_temp1<=max(eng_trq_fuel_hot_index),
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map, eng_temp1, 1.4*eng_spd_idle); % Kg/s
elseif eng_temp1<min(eng_trq_fuel_hot_index),
  eng_temp2 = min(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
else
  eng_temp2 = max(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
end

clear eng_temp1 eng_temp2 eng_temp3


% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_trq_hot_max	= max(eng_trq_max_hot_map); % N-m
eng_spd_hot_max	= max(eng_spd_max_hot_index(max(find(eng_trq_max_hot_map>0)))); % rad/s
eng_pwr_hot_max = max(eng_spd_max_hot_index.* eng_trq_max_hot_map); % W
eng_pwr_max_hot_map = eng_spd_max_hot_index.* eng_trq_max_hot_map; % W

%calculate the maximum efficiency
eng_eff_hot_map=eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index/eng_fuel_heating_val./(eng_fuel_hot_map);
eng_eff_hot_map_lim=eng_eff_hot_map;

[Q,lih_max]=max(eng_spd_fuel_hot_index);
[R,colh_max]=max(eng_trq_fuel_hot_index);
for lih=1:lih_max,
   for colh=1:colh_max,
      trq_val_hot=interp1(eng_spd_max_hot_index,eng_trq_max_hot_map,eng_spd_fuel_hot_index(lih));
      if eng_trq_fuel_hot_index(colh)>trq_val_hot,
         eng_eff_hot_map_lim(lih,colh)=0;
      end 
   end
end 

eng_eff_max=max(max(eng_eff_hot_map_lim));
eng_eff_hot_map=eng_eff_hot_map_lim;
[lin,col]=find(eng_eff_hot_map_lim==eng_eff_max);
eng_spd_max_hot_eff = eng_spd_fuel_hot_index(lin);
eng_trq_max_hot_eff = eng_trq_fuel_hot_index(col);
eng_pwr_max_hot_eff = eng_spd_fuel_hot_index(lin)*eng_trq_fuel_hot_index(col);
eng_pwr_max_eff = eng_pwr_max_hot_eff;
clear lih colh  Q R  colh_max lih_max  eng_eff_hot_map_lim trq_val_hot 
