
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: eng_ci_1987_54								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 2.0L (54kW) CI Engine					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: D. Yorke (ANL) - 02/20/01					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 				    						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_vol_mass 						= 50;						% Capacity of tank in kg - approximate value
eng_mass 							= 226.1359;							%eng_mass_block + eng_mass_radiator + eng_mass_vol + eng_tank_mass;
eng_tau_i_p							= 0.2; 						% 0 to 100% of max torque in 200ms - approximate value
eng_dn_i_p                          = 0.05;                     % 100% of max to 0 torque in 50ms
eng_spd_idle		 				= 650*c_rpm_radps;
eng_warmup_init_i_p 				= 0;							% This should normally by 0
eng_pwr_max							= 53841.9;					% Watts

% Fuel Parameters for Diesel
eng_fuel_density_val                = 835;        % kg/m3 or g/L
eng_fuel_heating_val      			= 42500000;       % (J/kg)Specific LHV
eng_fuel_carbon_ratio  			    = 12/13.8;        % (kg/kg) ref:Dr. Rob Thring

% Baseline engine parameters
eng_displ_init						=	1987;		% cc
eng_inertia_i_p						=	0.08;		% kg-m^2 - approximate value


eng_spd_opt							= 4500 * c_rpm_radps; % Optimal speed and power for operation in series configuration.  
eng_pwr_opt_i_p						= eng_pwr_max;
eng_spd_str_i_p						= 10; % speed level (Rd/s) the engine crank has to reach in order to start 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% maximum curves at each speed (closed and wide open throttle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hot max wide open throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_max_hot_index= [0 1000:500:6000]*c_rpm_radps;
eng_trq_max_hot_map= [0 605 750 750 800 850 815 750 690 650 0   0]*1.987/6.28/2; 
        

% Mid speed is used in logic to limit closed and wide open torque curves
eng_spd_avg	= 0.5 * (eng_spd_max_hot_index(1)+ eng_spd_max_hot_index(length(eng_spd_max_hot_index)));
      
% hot max closed throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_min_hot_index 	= eng_spd_max_hot_index;
eng_trq_min_hot_map= [0 -21.6424  -34.3127  -48.2159  -63.3518  -79.7206  -97.3221 -116.1564 -136.2235 -157.5234 0 0];
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% consumption table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_fuel_hot_index	= [1000:500:5000]*c_rpm_radps;
eng_trq_fuel_hot_index = [100:100:800]*1.987/6.28/2; % (Eqn B)

% Fuel rate tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table is fuel rate (kg/hr)
eng_fuel_hot_map = 1e-3*[...
        0.3681    0.3866    0.4970    0.5890    0.6788    0.8007    0.9342     1.0676;...
	 	0.5522    0.5798    0.7041    0.8421    0.9836    1.1265    1.3046    1.5462;...
    	0.7363    0.7731    0.9112    1.1008    1.2793    1.4358    1.6751    1.9880;...
    	0.9204    0.9664    1.1390    1.3714    1.5819    1.7947    2.0939    2.4850;...
    	1.2425    1.1597    1.4082    1.6567    1.9328    2.1537    2.5126    2.9820;...
    	1.4496    1.3529    1.7153    2.0101    2.3354    2.6383    2.9539     3.5821;...
    	1.8407    1.7303    2.0432    2.4298    2.7611    3.2029    3.6723    4.2705;...
    	2.0708    2.0708    2.4229    2.8992    3.3341    3.8518    4.4212    5.0529;...
    	2.3009    2.3930    2.8992    3.3594    3.9691    4.6939    5.4762    6.2585]*1.0195;

eng_fmep_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

% engine torque (hot and cold) for fuel rate = 0g/s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_zero_fuel_hot_index = eng_spd_min_hot_index;
eng_trq_zero_fuel_hot_index = eng_trq_min_hot_map;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% emission table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Emission index tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table
% is fuel emission index (g/s). 
% Multiplication by 0.01 because original data is in %.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - HC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_hc_hot_index = eng_spd_fuel_hot_index;
eng_trq_hc_hot_index = eng_trq_fuel_hot_index;
eng_hc_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - CO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_co_hot_index = eng_spd_fuel_hot_index;
eng_trq_co_hot_index = eng_trq_fuel_hot_index;
eng_co_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - Nox
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_nox_hot_index = eng_spd_fuel_hot_index;
eng_trq_nox_hot_index = eng_trq_fuel_hot_index;
eng_nox_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - PM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_pm_hot_index = eng_spd_fuel_hot_index;
eng_trq_pm_hot_index = eng_trq_fuel_hot_index;
eng_pm_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% O2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_o2_hot_index = eng_spd_fuel_hot_index;
eng_trq_o2_hot_index = eng_trq_fuel_hot_index;
eng_o2_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exhaust table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HOT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_equiv_hot_index =     eng_spd_fuel_hot_index;
eng_trq_equiv_hot_index =     eng_trq_fuel_hot_index;
eng_equiv_hot_map       =     ones(length(eng_spd_equiv_hot_index),length(eng_trq_equiv_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Thermal Calculations table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Heat rejection variable Presid data table

eng_spd_htrej_hot_index = eng_spd_fuel_hot_index;
eng_trq_htrej_hot_index = eng_trq_fuel_hot_index;
eng_htrej_hot_map       = zeros(length(eng_spd_htrej_hot_index),length(eng_trq_htrej_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Heat Transfer
%the following is a new thermal model of the engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

env_air_temp_amb = 20;            % C environmental variable ambient air temperature         

eng_spd_ex_gas_flow_hot_index =   eng_spd_fuel_hot_index;
eng_trq_ex_gas_flow_hot_index =   eng_trq_fuel_hot_index;
eng_ex_gas_flow_hot_map       =   eng_fuel_hot_map *(1+20);                  % g/s  ex gas flow map:  for CI engines, exflow=(fuel use)*[1 + (ave A/F ratio)]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eng_v0x\fuel use, thermal and emissions\thermal\fc heat net calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_ex_pwr_map = eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index;
eng_ex_temp_map = eng_ex_pwr_map./(eng_ex_gas_flow_hot_map *1089/1000) + 20;  % W   EO ex gas temp = Q/(MF*cp) + Tamb (assumes engine tested ~20 C)
eng_spd_ex_temp_index = eng_spd_fuel_hot_index; 
eng_trq_ex_temp_index = eng_trq_fuel_hot_index;

eng_temp_operating = 90;
eng_ex_temp_operating = mean(mean(eng_ex_temp_map));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Find appropriate fuel rate to normalize with respect to.
% Tom Kenney has approved this approach.
% when the simulation is started, the engine is typically assumed to be at ambient temperature
% The normalizing fuel rate mdotf_base is chosen so as to replicate the warmup trend for the engine
% subjected to a certain drive cycle. In most cases, the normalizing fuel rate will not equal the max fuel rate

eng_temp1 = max(eng_spd_fuel_hot_index)/(1.4*eng_spd_idle);
if min(eng_trq_fuel_hot_index)<=eng_temp1 & eng_temp1<=max(eng_trq_fuel_hot_index),
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map, eng_temp1, 1.4*eng_spd_idle); % Kg/s
elseif eng_temp1<min(eng_trq_fuel_hot_index),
  eng_temp2 = min(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
else
  eng_temp2 = max(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
end

clear eng_temp1 eng_temp2 eng_temp3


% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_trq_hot_max	= max(eng_trq_max_hot_map); % N-m
eng_spd_hot_max	= max(eng_spd_max_hot_index(max(find(eng_trq_max_hot_map>0)))); % rad/s
eng_pwr_hot_max = max(eng_spd_max_hot_index.* eng_trq_max_hot_map); % W
eng_pwr_max_hot_map = eng_spd_max_hot_index.* eng_trq_max_hot_map; % W

%calculate the maximum efficiency
eng_eff_hot_map=eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index/eng_fuel_heating_val./(eng_fuel_hot_map);
eng_eff_hot_map_lim=eng_eff_hot_map;

[Q,lih_max]=max(eng_spd_fuel_hot_index);
[R,colh_max]=max(eng_trq_fuel_hot_index);
for lih=1:lih_max,
   for colh=1:colh_max,
      trq_val_hot=interp1(eng_spd_max_hot_index,eng_trq_max_hot_map,eng_spd_fuel_hot_index(lih));
      if eng_trq_fuel_hot_index(colh)>trq_val_hot,
         eng_eff_hot_map_lim(lih,colh)=0;
      end 
   end
end 

eng_eff_max=max(max(eng_eff_hot_map_lim));
eng_eff_hot_map=eng_eff_hot_map_lim;
[lin,col]=find(eng_eff_hot_map_lim==eng_eff_max);
eng_spd_max_hot_eff = eng_spd_fuel_hot_index(lin);
eng_trq_max_hot_eff = eng_trq_fuel_hot_index(col);
eng_pwr_max_hot_eff = eng_spd_fuel_hot_index(lin)*eng_trq_fuel_hot_index(col);
eng_pwr_max_eff = eng_pwr_max_hot_eff;
clear lih colh  Q R  colh_max lih_max  eng_eff_hot_map_lim trq_val_hot 
