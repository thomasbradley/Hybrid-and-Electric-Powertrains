
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file      : eng_si_1500_43_prius.m                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description           : Toyota Prius 1.5L SI Engine                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by            : P.Sharer - ANL - 12/10/00                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : CON_INIT                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by :                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by :                                                      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : The engine start speed is not compatible with 
%         other control strategies.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_vol_mass         = 50.0;   % Capacity of tank in kg
eng_mass             = 108+6+10;%block + radiator + tank
eng_inertia_i_p      = 0.1598; 
eng_tau_i_p          = 0.2;    % 0 to 100% of max torque in 200ms
eng_dn_i_p           = 0.05;                     % 100% of max to 0 torque in 50ms

eng_spd_idle          = 970*c_rpm_radps;   % rad/s (default)
eng_spd_str_i_p       = 800*c_rpm_radps;			
eng_warmup_init_i_p   = 0;      % This should normally by 0
eng_pwr_max           = 43000;  % Watts
eng_pwr_max_eff       = 40000;  % Watts

%Fuel parameters for premium gasoline
eng_fuel_density_val                = 749;            % kg/m3 or g/L
eng_fuel_heating_val      			= 43000000;             % (J/kg)Specific LHV
eng_fuel_carbon_ratio = 0.86;       % (% Carbon by weight)
eng_co2_init          = 0;

% Baseline engine parameters
eng_displ_init      = 1500.0;   % cc
eng_num_cyl_init    = 4;
eng_bore_init       = 8.3;   % mm
eng_stroke_init      = 8.32;   % mm
eng_comp_ratio_init = 11.5;		


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% maximum curves at each speed (closed and wide open throttle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hot max wide open throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_max_hot_index = [0 37.3599   68.7758  110.6637  115.8997  142.0796  168.2596  194.4395...
        220.6194  246.7994  272.9793  299.1593  325.3392  351.5191  377.6991...
        403.8790  435.0017  456.2389  505.8761  520 530];
eng_trq_max_hot_map = [0 40.0000   55.0000   75.0000   78.7559   86.1444   92.1880   97.0396...
        100.8521  103.7786  105.9719  107.5850  108.7708  109.6825  110.4728...
        111.0000  109.0000  108.0000   50.0000  0   0]; % hot wide open throttle torque

% hot max closed throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_min_hot_index = eng_spd_max_hot_index;% hot closed throttle speed index
eng_trq_min_hot_map = [0  -3      -5      -7      -8      -10   ...
        -10      -10     -10     -10     -10     -10     -10     -10 ...
        -10      -10     -10  -10 -10 0 0];


% Mid speed is used in logic to limit closed and wide open torque curves
eng_spd_avg = 0.5 * (eng_spd_max_hot_index(1)+ eng_spd_max_hot_index(length(eng_spd_max_hot_index)));

eng_spd_fuel_hot_index = [1000 1250 1500 1750 2000 2250 2500 2750 3000 3250 3500 4316]*c_rpm_radps;
eng_trq_fuel_hot_index = [6.3 12.5 18.8 25.1 31.3 37.6 43.9 50.1 56.4 62.7 68.9 70]*1.35582;

eng_fuel_hot_map = [...
    0.1513  0.1984  0.2455  0.2925  0.3396  0.3867  0.4338  0.4808  0.5279  0.5279  0.5279  0.5279;
    0.1834  0.2423  0.3011  0.3599  0.4188  0.4776  0.5365  0.5953  0.6541  0.6689  0.6689  0.6689;
    0.2145  0.2851  0.3557  0.4263  0.4969  0.5675  0.6381  0.7087  0.7793  0.8146  0.8146  0.8146;
    0.2451  0.3274  0.4098  0.4922  0.5746  0.6570  0.7393  0.8217  0.9041  0.9659  0.9659  0.9659;
    0.2759  0.3700  0.4642  0.5583  0.6525  0.7466  0.8408  0.9349  1.0291  1.1232  1.1232  1.1232;
    0.3076  0.4135  0.5194  0.6253  0.7312  0.8371  0.9430  1.0490  1.1549  1.2608  1.2873  1.2873;
    0.3407  0.4584  0.5761  0.6937  0.8114  0.9291  1.0468  1.1645  1.2822  1.3998  1.4587  1.4587;
    0.3773  0.5068  0.6362  0.7657  0.8951  1.0246  1.1540  1.2835  1.4129  1.5424  1.6395  1.6395;
    0.4200  0.5612  0.7024  0.8436  0.9849  1.1261  1.2673  1.4085  1.5497  1.6910  1.8322  1.8322;
    0.4701  0.6231  0.7761  0.9290  1.0820  1.2350  1.3880  1.5410  1.6940  1.8470  1.9999  2.0382;
    0.5290  0.6938  0.8585  1.0233  1.1880  1.3528  1.5175  1.6823  1.8470  2.0118  2.1766  2.2589;
    0.6789  0.8672  1.0555  1.2438  1.4321  1.6204  1.8087  1.9970  2.1852  2.3735  2.5618  2.7501]/1000; %now in kg/s

% engine torque (hot and cold) for fuel rate = 0g/s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_zero_fuel_hot_index = eng_spd_min_hot_index;
eng_trq_zero_fuel_hot_index = eng_trq_min_hot_map;

%Emissions in percentage of fuel rate (g/s)

eng_spd_co_hot_index = eng_spd_fuel_hot_index;
eng_trq_co_hot_index = eng_trq_fuel_hot_index;

eng_co_hot_map = [...
    0.0099  0.0129  0.0160  0.0190  0.0221  0.0252  0.0282  0.0313  0.0344  0.0344  0.0344  0.0344; 
    0.0119  0.0158  0.0196  0.0234  0.0273  0.0311  0.0349  0.0388  0.0426  0.0435  0.0435  0.0435; 
    0.0140  0.0186  0.0232  0.0278  0.0323  0.0369  0.0415  0.0461  0.0507  0.0530  0.0530  0.0530; 
    0.0160  0.0213  0.0267  0.0320  0.0374  0.0428  0.0481  0.0535  0.0589  0.0629  0.0629  0.0629; 
    0.0180  0.0241  0.0302  0.0363  0.0425  0.0486  0.0547  0.0609  0.0670  0.0731  0.0731  0.0731; 
    0.0200  0.0269  0.0338  0.0407  0.0476  0.0545  0.0614  0.0683  0.0752  0.0821  0.0838  0.0838; 
    0.0222  0.0298  0.0375  0.0452  0.0528  0.0605  0.0681  0.0758  0.0835  0.0911  0.0950  0.0950; 
    0.0246  0.0330  0.0414  0.0498  0.0583  0.0667  0.0751  0.0836  0.0920  0.1004  0.1067  0.1067; 
    0.0273  0.0365  0.0457  0.0549  0.0641  0.0733  0.0825  0.0917  0.1009  0.1101  0.1193  0.1193; 
    0.0306  0.0406  0.0505  0.0605  0.0704  0.0804  0.0904  0.1003  0.1103  0.1202  0.1302  0.1327; 
    0.0344  0.0452  0.0559  0.0666  0.0773  0.0881  0.0988  0.1095  0.1202  0.1310  0.1417  0.1471; 
    0.0442  0.0565  0.0687  0.0810  0.0932  0.1055  0.1177  0.1300  0.1423  0.1545  0.1668  0.1790]/1000; 


eng_spd_hc_hot_index = eng_spd_fuel_hot_index;
eng_trq_hc_hot_index = eng_trq_fuel_hot_index;

eng_hc_hot_map = [...
        0.0079  0.0085  0.0091  0.0097  0.0103  0.0109  0.0115  0.0121  0.0127  0.0127  0.0127  0.0127; 
    0.0083  0.0091  0.0098  0.0105  0.0113  0.0120  0.0128  0.0135  0.0142  0.0144  0.0144  0.0144; 
    0.0087  0.0096  0.0105  0.0114  0.0123  0.0132  0.0140  0.0149  0.0158  0.0163  0.0163  0.0163; 
    0.0091  0.0101  0.0112  0.0122  0.0132  0.0143  0.0153  0.0164  0.0174  0.0182  0.0182  0.0182;
    0.0095  0.0107  0.0118  0.0130  0.0142  0.0154  0.0166  0.0178  0.0190  0.0202  0.0202  0.0202; 
    0.0099  0.0112  0.0125  0.0139  0.0152  0.0165  0.0179  0.0192  0.0206  0.0219  0.0222  0.0222; 
    0.0103  0.0118  0.0133  0.0147  0.0162  0.0177  0.0192  0.0207  0.0222  0.0236  0.0244  0.0244; 
    0.0108  0.0124  0.0140  0.0156  0.0173  0.0189  0.0205  0.0222  0.0238  0.0254  0.0267  0.0267; 
    0.0113  0.0131  0.0149  0.0166  0.0184  0.0202  0.0220  0.0237  0.0255  0.0273  0.0291  0.0291; 
    0.0119  0.0139  0.0158  0.0177  0.0196  0.0216  0.0235  0.0254  0.0273  0.0293  0.0312  0.0317;
    0.0127  0.0147  0.0168  0.0189  0.0210  0.0230  0.0251  0.0272  0.0293  0.0313  0.0334  0.0345; 
    0.0146  0.0169  0.0193  0.0217  0.0240  0.0264  0.0288  0.0312  0.0335  0.0359  0.0383  0.0407]/1000; 


eng_spd_nox_hot_index = eng_spd_fuel_hot_index;
eng_trq_nox_hot_index = eng_trq_fuel_hot_index;

eng_nox_hot_map = [...
    0.0000  0.0000  0.0014  0.0031  0.0047  0.0064  0.0080  0.0096  0.0113  0.0113  0.0113  0.0113;  
    0.0000  0.0013  0.0034  0.0054  0.0075  0.0095  0.0116  0.0136  0.0157  0.0162  0.0162  0.0162;  
    0.0003  0.0028  0.0053  0.0077  0.0102  0.0127  0.0151  0.0176  0.0201  0.0213  0.0213  0.0213;  
    0.0014  0.0043  0.0072  0.0100  0.0129  0.0158  0.0187  0.0215  0.0244  0.0266  0.0266  0.0266;  
    0.0025  0.0058  0.0091  0.0123  0.0156  0.0189  0.0222  0.0255  0.0288  0.0321  0.0321  0.0321;  
    0.0036  0.0073  0.0110  0.0147  0.0184  0.0221  0.0258  0.0295  0.0332  0.0369  0.0378  0.0378;  
    0.0047  0.0089  0.0130  0.0171  0.0212  0.0253  0.0294  0.0335  0.0376  0.0417  0.0438  0.0438;  
    0.0060  0.0105  0.0151  0.0196  0.0241  0.0286  0.0331  0.0377  0.0422  0.0467  0.0501  0.0501;  
    0.0075  0.0124  0.0174  0.0223  0.0272  0.0322  0.0371  0.0420  0.0469  0.0519  0.0568  0.0568;  
    0.0093  0.0146  0.0199  0.0253  0.0306  0.0360  0.0413  0.0466  0.0520  0.0573  0.0627  0.0640;  
    0.0113  0.0171  0.0228  0.0286  0.0343  0.0401  0.0458  0.0516  0.0573  0.0631  0.0688  0.0717;  
    0.0166  0.0231  0.0297  0.0363  0.0428  0.0494  0.0560  0.0626  0.0691  0.0757  0.0823  0.0888]/1000;


eng_spd_pm_hot_index = eng_spd_fuel_hot_index;
eng_trq_pm_hot_index = eng_trq_fuel_hot_index;
eng_pm_hot_map  = zeros(length(eng_spd_hc_hot_index), length(eng_trq_nox_hot_index));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% O2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_o2_hot_index = eng_spd_fuel_hot_index;
eng_trq_o2_hot_index = eng_trq_fuel_hot_index;
eng_o2_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exhaust table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HOT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_equiv_hot_index = eng_spd_fuel_hot_index;
eng_trq_equiv_hot_index = eng_trq_fuel_hot_index;

eng_equiv_hot_map =  [0.9691    0.9709    0.9724    0.9737    0.9749    0.9759    0.9767    0.9775    0.9781    0.9787    0.9792    0.9804;...
    0.9820    0.9821    0.9821    0.9822    0.9822    0.9823    0.9823    0.9823    0.9824    0.9824    0.9824    0.9825;...
    0.9827    0.9827    0.9827    0.9827    0.9827    0.9827    0.9827    0.9827    0.9827    0.9827    0.9827    0.9827;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828;...
    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828    0.9828].^-1;


% Heat rejection variable Presid data table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_htrej_hot_index = eng_spd_fuel_hot_index;
eng_trq_htrej_hot_index = eng_trq_fuel_hot_index;
eng_htrej_hot_map  = zeros(12,12);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Heat Transfer
%the following is a new thermal model of the engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

env_air_temp_amb = 20;            % C environmental variable ambient air temperature         

eng_spd_ex_gas_flow_hot_index =   eng_spd_fuel_hot_index;
eng_trq_ex_gas_flow_hot_index =   eng_trq_fuel_hot_index;
eng_ex_gas_flow_hot_map       =   eng_fuel_hot_map *(1+20);                  % g/s  ex gas flow map:  for CI engines, exflow=(fuel use)*[1 + (ave A/F ratio)]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eng_v0x\fuel use, thermal and emissions\thermal\fc heat net calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_ex_pwr_map = eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index;
eng_ex_temp_map = eng_ex_pwr_map./(eng_ex_gas_flow_hot_map *1089/1000) + 20;  % W   EO ex gas temp = Q/(MF*cp) + Tamb (assumes engine tested ~20 C)
eng_spd_ex_temp_index = eng_spd_fuel_hot_index; 
eng_trq_ex_temp_index = eng_trq_fuel_hot_index;

eng_temp_operating = 90;
eng_ex_temp_operating = mean(mean(eng_ex_temp_map));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Find appropriate fuel rate to normalize with respect to.
% Tom Kenney has approved this approach.
% when the simulation is started, the engine is typically assumed to be at ambient temperature
% The normalizing fuel rate mdotf_base is chosen so as to replicate the warmup trend for the engine
% subjected to a certain drive cycle. In most cases, the normalizing fuel rate will not equal the max fuel rate

eng_temp1 = max(eng_spd_fuel_hot_index)/(1.4*eng_spd_idle);
if min(eng_trq_fuel_hot_index)<=eng_temp1 & eng_temp1<=max(eng_trq_fuel_hot_index),
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map, eng_temp1, 1.4*eng_spd_idle); % Kg/s
elseif eng_temp1<min(eng_trq_fuel_hot_index),
  eng_temp2 = min(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
else
  eng_temp2 = max(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
end

clear eng_temp1 eng_temp2 eng_temp3


% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_trq_hot_max	= max(eng_trq_max_hot_map); % N-m
eng_spd_hot_max	= max(eng_spd_max_hot_index(max(find(eng_trq_max_hot_map>0)))); % rad/s
eng_pwr_hot_max = max(eng_spd_max_hot_index.* eng_trq_max_hot_map); % W
eng_pwr_max_hot_map = eng_spd_max_hot_index.* eng_trq_max_hot_map; % W

%calculate the maximum efficiency
eng_eff_hot_map=eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index/eng_fuel_heating_val./(eng_fuel_hot_map);
eng_eff_hot_map_lim=eng_eff_hot_map;

[Q,lih_max]=max(eng_spd_fuel_hot_index);
[R,colh_max]=max(eng_trq_fuel_hot_index);
for lih=1:lih_max,
   for colh=1:colh_max,
      trq_val_hot=interp1(eng_spd_max_hot_index,eng_trq_max_hot_map,eng_spd_fuel_hot_index(lih));
      if eng_trq_fuel_hot_index(colh)>trq_val_hot,
         eng_eff_hot_map_lim(lih,colh)=0;
      end 
   end
end 

eng_eff_max=max(max(eng_eff_hot_map_lim));
eng_eff_hot_map=eng_eff_hot_map_lim;
[lin,col]=find(eng_eff_hot_map_lim==eng_eff_max);
eng_spd_max_hot_eff = eng_spd_fuel_hot_index(lin);
eng_trq_max_hot_eff = eng_trq_fuel_hot_index(col);
eng_pwr_max_hot_eff = eng_spd_fuel_hot_index(lin)*eng_trq_fuel_hot_index(col);
eng_pwr_max_eff = eng_pwr_max_hot_eff;
clear lih colh  Q R  colh_max lih_max  eng_eff_hot_map_lim trq_val_hot 
