%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: eng_ci_10800_246_cummins.m				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 1.8L (75KW) CI Engine                     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 12/01/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% A.Rousseau (ANL) - 03/02/00 - integration of the eng_tau			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_warmup_init_i_p                 = 1;
eng_vol_mass 						= 100;						% Capacity of tank in kg - approximate value
eng_mass 							= 1030;                     %kg, estimated
eng_tau_i_p							= 0.2; 						% 0 to 100% of max torque in 200ms - approximate value
eng_dn_i_p                          = 0.05;                     % 100% of max to 0 torque in 50ms
eng_spd_idle		 				= 650*c_rpm_radps;
eng_pwr_max							= 246206.6;					% Watts

% Fuel Parameters for Diesel
eng_fuel_density_val                = 835;        % kg/m3 or g/L
eng_fuel_heating_val      			= 42500000;       % (MJ/kg)Specific LHV
eng_fuel_carbon_ratio  			    = 12/13.8;    % (kg/kg) ref:Dr. Rob Thring

% Baseline engine parameters
eng_displ_init						=	10800.0;		% cc
eng_inertia_i_p						=	0.26;		% kg-m^2 - approximate value

eng_spd_opt							= 4500 * c_rpm_radps; % Optimal speed and power for operation in series configuration.  
eng_pwr_opt_i_p						= eng_pwr_max;
eng_spd_str_i_p						= 10; % speed level (Rd/s) the engine crank has to reach in order to start 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% maximum curves at each speed (closed and wide open throttle)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% hot max wide open throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_max_hot_index= [0    650 1100 1200 1300 1500 1600 1700 1800 1900 2000 2100 2200]*pi/30;
eng_trq_max_hot_map= [0  1695*0.95 1695 1695 1695 1566 1469 1383 1306 1195 1096 0 0]* 1.0195;        

% Mid speed is used in logic to limit closed and wide open torque curves
eng_spd_avg	= 0.5 * (eng_spd_max_hot_index(1)+ eng_spd_max_hot_index(length(eng_spd_max_hot_index)));
      
% hot max closed throttle curves
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_min_hot_index 	= eng_spd_max_hot_index;
eng_trq_min_hot_map= [0 -88.5 -120 -127 -134 -148 -155 -164 -173 -182 -191 0 0]*1.0195;
 

% calculation of the engine off torque
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_coeff_fric_index = find(eng_trq_min_hot_map< 0);
eng_trq_coeff_fric =  mean (eng_trq_min_hot_map(eng_coeff_fric_index) ./ eng_spd_min_hot_index(eng_coeff_fric_index) ); % N-m/rpm

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% consumption table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_fuel_hot_index	= [650 1100 1200 1300 1500 1600 1700 1800 1900 2000]*pi/30;
eng_trq_fuel_hot_index = [100 200 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500 1600 1700]*1.0195; % (Eqn B)

% Fuel rate tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table is fuel rate (kg/s)

eng_fuel_hot_map =1e-3*[...
    0.7145    1.4041    1.9924    2.5434    3.0690    3.6126    4.1551    4.7043    5.2561    5.8130    6.3661    6.9152    7.4670    8.0177    8.5648    9.1085    9.6585
    0.8217    1.6147    2.2913    2.9249    3.5293    4.1545    4.7784    5.4100    6.0445    6.6849    7.3210    7.9525    8.5871    9.2203    9.8495   10.4748   11.1073
    0.8682    1.6922    2.4014    3.0653    3.6988    4.3540    5.0078    5.6698    6.3348    7.0059    7.6726    8.3344    8.9995    9.6631   10.3225   10.9779   11.6407
    0.9725    1.8825    2.6169    3.3085    3.9904    4.6830    5.3743    6.0649    6.7573    7.4590    8.1597    8.8569    9.5583   10.2656   10.9786   11.6936   12.3996
    1.1994	  2.2627	3.0435	 3.8037	    4.5760	  5.3435	6.1087	  6.8920	7.6756    8.4642	9.2569   10.0493   10.8515	 11.6684   12.5009   13.3077   14.1112
    1.3109    2.4309    3.2392    4.0423    4.8394    5.6425    6.4613    7.3038    8.1490    8.9930    9.8430   10.6981   11.5609   12.4454   13.3077   14.1665   15.0219
    1.4364    2.6075    3.4461    4.2856    5.1291    5.9892    6.8758    7.7681    8.6647    9.5646   10.4698   11.4009   12.3430   13.2659   14.1851   15.1006   16.0123
    1.5788    2.7987    3.6624    4.5513    5.4572    6.3780    7.3237    8.2751    9.2323   10.1864   11.1736   12.1894   13.2052   14.1926   15.1760   16.1554   17.1308
    1.6798    2.9564    3.8890    4.8687    5.8526    6.8441    7.8618    8.8833    9.9033   10.9321   11.9968   13.0613   14.1215   15.1774   16.2290   17.2764   18.3195
    1.7906    3.1484    4.2029    5.2504    6.3087    7.3879    8.4880    9.5770   10.6792   11.7933   12.9468   14.0956   15.2397   16.3793   17.5142   18.6445   19.7702]*1.0195;

eng_fmep_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

% engine torque for fuel rate = 0g/s
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_zero_fuel_hot_index = eng_spd_min_hot_index;
eng_trq_zero_fuel_hot_index = eng_trq_min_hot_map;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% emission table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Emission index tables.
% Rows are x input (speed, rpm).  Columns are y input (torque, N-m).  Table
% is fuel emission index (g/s). 
% Multiplication by 0.01 because original data is in %.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - HC
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

eng_spd_hc_hot_index = eng_spd_fuel_hot_index;
eng_trq_hc_hot_index = eng_trq_fuel_hot_index;
eng_hc_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - CO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_co_hot_index = eng_spd_fuel_hot_index;
eng_trq_co_hot_index = eng_trq_fuel_hot_index;
eng_co_hot_map    = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - Nox
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_nox_hot_index = eng_spd_fuel_hot_index;
eng_trq_nox_hot_index = eng_trq_fuel_hot_index;
eng_nox_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% HOT - PM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_pm_hot_index = eng_spd_fuel_hot_index;
eng_trq_pm_hot_index = eng_trq_fuel_hot_index;
eng_pm_hot_map   = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% O2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_o2_hot_index = eng_spd_fuel_hot_index;
eng_trq_o2_hot_index = eng_trq_fuel_hot_index;
eng_o2_hot_map = zeros(length(eng_spd_fuel_hot_index),length(eng_trq_fuel_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% exhaust table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% HOT
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_spd_equiv_hot_index =     eng_spd_fuel_hot_index;
eng_trq_equiv_hot_index =     eng_trq_fuel_hot_index;
eng_equiv_hot_map       =     ones(length(eng_spd_equiv_hot_index),length(eng_trq_equiv_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Thermal Calculations table
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Heat rejection variable Presid data table

eng_spd_htrej_hot_index = eng_spd_fuel_hot_index;
eng_trq_htrej_hot_index = eng_trq_fuel_hot_index;
eng_htrej_hot_map       = zeros(length(eng_spd_htrej_hot_index),length(eng_trq_htrej_hot_index));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
% Heat Transfer
%the following is a new thermal model of the engine
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5

env_air_temp_amb = 20;            % C environmental variable ambient air temperature         

eng_spd_ex_gas_flow_hot_index =   eng_spd_fuel_hot_index;
eng_trq_ex_gas_flow_hot_index =   eng_trq_fuel_hot_index;
eng_ex_gas_flow_hot_map       =   eng_fuel_hot_map *(1+20);                  % g/s  ex gas flow map:  for CI engines, exflow=(fuel use)*[1 + (ave A/F ratio)]


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%eng_v0x\fuel use, thermal and emissions\thermal\fc heat net calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_ex_pwr_map = eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index;
eng_ex_temp_map = eng_ex_pwr_map./(eng_ex_gas_flow_hot_map *1089/1000) + 20;  % W   EO ex gas temp = Q/(MF*cp) + Tamb (assumes engine tested ~20 C)
eng_spd_ex_temp_index = eng_spd_fuel_hot_index; 
eng_trq_ex_temp_index = eng_trq_fuel_hot_index;

eng_temp_operating = 90;
eng_ex_temp_operating = mean(mean(eng_ex_temp_map));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Find appropriate fuel rate to normalize with respect to.
% Tom Kenney has approved this approach.
% when the simulation is started, the engine is typically assumed to be at ambient temperature
% The normalizing fuel rate mdotf_base is chosen so as to replicate the warmup trend for the engine
% subjected to a certain drive cycle. In most cases, the normalizing fuel rate will not equal the max fuel rate

eng_temp1 = max(eng_spd_fuel_hot_index)/(1.4*eng_spd_idle);
if min(eng_trq_fuel_hot_index)<=eng_temp1 & eng_temp1<=max(eng_trq_fuel_hot_index),
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map, eng_temp1, 1.4*eng_spd_idle); % Kg/s
elseif eng_temp1<min(eng_trq_fuel_hot_index),
  eng_temp2 = min(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
else
  eng_temp2 = max(eng_trq_fuel_hot_index);
  eng_temp3 = max(eng_spd_fuel_hot_index)/eng_temp2;
  if eng_temp3<min(eng_spd_fuel_hot_index), eng_temp3 = min(eng_spd_fuel_hot_index);end
  eng_fuel_max = interp2( eng_trq_fuel_hot_index, eng_spd_fuel_hot_index', eng_fuel_hot_map,eng_temp2,eng_temp3); % Kg/s
end

clear eng_temp1 eng_temp2 eng_temp3


% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eng_trq_hot_max	= max(eng_trq_max_hot_map); % N-m
eng_spd_hot_max	= max(eng_spd_max_hot_index(max(find(eng_trq_max_hot_map>0)))); % rad/s
eng_pwr_hot_max = max(eng_spd_max_hot_index.* eng_trq_max_hot_map); % W
eng_pwr_max_hot_map = eng_spd_max_hot_index.* eng_trq_max_hot_map; % W

%calculate the maximum efficiency
eng_eff_hot_map=eng_spd_fuel_hot_index'*eng_trq_fuel_hot_index/eng_fuel_heating_val./(eng_fuel_hot_map);
eng_eff_hot_map_lim=eng_eff_hot_map;

[Q,lih_max]=max(eng_spd_fuel_hot_index);
[R,colh_max]=max(eng_trq_fuel_hot_index);
for lih=1:lih_max,
   for colh=1:colh_max,
      trq_val_hot=interp1(eng_spd_max_hot_index,eng_trq_max_hot_map,eng_spd_fuel_hot_index(lih));
      if eng_trq_fuel_hot_index(colh)>trq_val_hot,
         eng_eff_hot_map_lim(lih,colh)=0;
      end 
   end
end 

eng_eff_max=max(max(eng_eff_hot_map_lim));
eng_eff_hot_map=eng_eff_hot_map_lim;
[lin,col]=find(eng_eff_hot_map_lim==eng_eff_max);
eng_spd_max_hot_eff = eng_spd_fuel_hot_index(lin);
eng_trq_max_hot_eff = eng_trq_fuel_hot_index(col);
eng_pwr_max_hot_eff = eng_spd_fuel_hot_index(lin)*eng_trq_fuel_hot_index(col);
eng_pwr_max_eff = eng_pwr_max_hot_eff;
clear lih colh  Q R  colh_max lih_max  eng_eff_hot_map_lim trq_val_hot 
