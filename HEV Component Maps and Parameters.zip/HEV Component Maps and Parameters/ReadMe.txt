These initialization files contain information on the characteristics of various vehicle components.  They were distributed as part of Argonne National Lab's PSAT version 5.1.  You can use them for your vehicle modeling projects, but make sure that you use them correctly. 


eng-engine
acc-accessories
cpl-clutches 
drv-drivers
env-environmental variables
ess-energy storagy system including batteries
ex - exhaust
fc-fuel cell
fd-final drive 
gc-gear couplings
mc-motor controllers
pc-power conditioner
ptc-powertrain controller
sch-driving schedules
str-starter motors
tc-torque converter
trc-transfer case
tx-transmissions
veh-vehicle models
wh-wheel models