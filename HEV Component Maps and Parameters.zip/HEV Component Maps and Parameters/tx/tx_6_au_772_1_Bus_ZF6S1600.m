%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_6_au_675_083_Bus_ZF6S85.m			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% ZF-6S 85 Transmission - Used for intercity and transit Bus	    %
% Average efficiency                                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 09/29/01			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files :                       					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear tx_trq_loss_map

tx_inertia_in_i_p 	    = 0.003;			% kg m^2
tx_inertia_out_i_p 	    = 0;				% kg m^2
tx_mass  				= 170;		%kg
tx_spd_thr_i 			= 10;
tx_nb_ratio             = 6;
tx_gear_index           = [0,1,2,3,4,5,6];
tx_ratio_map            = [0,7.72, 4.42, 2.66, 1.79, 1.28, 1];  

tx_trq_eff_index = [0:100:1700];% input trq in Nm
tx_spd_eff_index = [0:100:400];% input speeds in rd/s

tx_eff_trq_ratio1_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio2_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92; 
tx_eff_trq_ratio3_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio4_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio5_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio6_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;

% calculate the torque losses
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_trq_loss_index = tx_trq_eff_index;
tx_spd_loss_index = tx_spd_eff_index;
tx_coeff = tx_trq_eff_index(:)*ones(1,length(tx_spd_eff_index));
for cpt=1:tx_nb_ratio,
    eval(['tx_trq_loss_ratio',num2str(cpt),'_map = (1 - tx_eff_trq_ratio',num2str(cpt),'_map) .* tx_coeff;']);%calculate trq loss per ratio
    tx_trq_loss_map(:,:,cpt) = eval(['tx_trq_loss_ratio',num2str(cpt),'_map']);%create the 3 dimensions (trq, spd, ratio) map for trq loss
end

% calculate the maximum efficiency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for cpt=1:tx_nb_ratio,
   tx_eff(cpt)=max(max(eval(['tx_eff_trq_ratio',num2str(cpt),'_map'])));
end
tx_eff_max=max(tx_eff);
clear cpt