function delta = angle_pulley(x,tx_length_belt,tx_length_between_pulley_axle,cpt)

delta = tx_length_belt*(1-1/cpt)/(2*tx_length_between_pulley_axle)-(1-1/cpt)*cos(x)-((x-pi/2)-(x+pi/2)/cpt)*sin(x);
