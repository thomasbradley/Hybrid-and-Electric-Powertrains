%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_6_au_35_064_Bus_AlissonB500.m			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% Alisson B500 Transmission - Used for intercity and transit Bus	%
% Efficiency taken from another file                                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 10/06/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files :                       					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL)- 10/06/99 - simplification of the variable names	%
% A.Rousseau (ANL)- 10/13/99 - creation of a special file for the   %
% torque converter.													%
% A.Rousseau (ANL)- 10/20/99 - delete the variables dtr_eff2_torque	%
% and dtr_eff2_speed because they were only renamed variables		%
% A.Rousseau (ANL) - 11/05/99 - modifed variable dtr_config_switch	%
% (0/1 initialy) .This parameter has now 4 values					%
% A.Rousseau (ANL) - 11/15/99 - del dtr_config_switch3 not use 		%
% anymore															%
% A.Rousseau (ANL) - 11/16/99 - move all the shift laws in dedicated%
% files and create specific files for each gearbox speed number		%
% A.Rousseau (ANL) - 11/17/99 -add the torque loss table calculation%
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear tx_trq_loss_map

tx_inertia_in_i_p 	    = 0.003;			% kg m^2
tx_inertia_out_i_p 	    = 0;				% kg m^2
tx_mass  				= 200;		%kg
tx_spd_thr_i 			= 10;
tx_nb_ratio             = 6;
tx_gear_index           = [0,1,2,3,4,5,6];
tx_ratio_map            = [0,3.51, 1.91, 1.43, 1, 0.74, 0.64];  

tx_trq_eff_index = [51.40,52.40,104.7,157.1,209.4,261.8,314.2,366.5,418.9,471.2,523.6];% input trq in Nm
tx_spd_eff_index = [	0.500,6.000,33.90,67.80,101.7,135.6,169.5,203.4,237.3,271.2,305.1,339];% input speeds in rd/s

tx_eff_trq_ratio1_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio2_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92; 
tx_eff_trq_ratio3_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio4_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio5_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;
tx_eff_trq_ratio6_map = ones(size(tx_trq_eff_index,2),size(tx_spd_eff_index,2)).*0.92;

% calculate the torque losses
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_trq_loss_index = tx_trq_eff_index;
tx_spd_loss_index = tx_spd_eff_index;
tx_coeff = tx_trq_eff_index(:)*ones(1,length(tx_spd_eff_index));
for cpt=1:tx_nb_ratio,
    eval(['tx_trq_loss_ratio',num2str(cpt),'_map = (1 - tx_eff_trq_ratio',num2str(cpt),'_map) .* tx_coeff;']);%calculate trq loss per ratio
    tx_trq_loss_map(:,:,cpt) = eval(['tx_trq_loss_ratio',num2str(cpt),'_map']);%create the 3 dimensions (trq, spd, ratio) map for trq loss
end

% calculate the maximum efficiency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for cpt=1:tx_nb_ratio,
   tx_eff(cpt)=max(max(eval(['tx_eff_trq_ratio',num2str(cpt),'_map'])));
end
tx_eff_max=max(tx_eff);
clear cpt