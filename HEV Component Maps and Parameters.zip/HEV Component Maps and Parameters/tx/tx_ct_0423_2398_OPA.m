%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_ct_0423_2396_39.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% continuous variable transmission									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)						    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files :                       					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% University of Maryland - 1995 - Fred Householder under the 		%
% supervision of Dr. David Holloway									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL)- 09/13/99 - creation of a special file for the   %
% clutch															%
% A.Rousseau (ANL)- 10/06/99 - simplification of the variable names	%
% A.Rousseau (ANL) - 11/05/99 - modifed variable dtr_config_switch	%
% (0/1 initialy) .This parameter has now 4 values					%
% A.Rousseau (ANL) - 11/17/99 -add the torque loss table calculation%
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
% Byungsoon Min - 07/02/02 - OPA data input                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Data were collected at two clamping pressures,one which is usually% 
% used at input torques above 40 ft-lb, and one which is used below %
% 40 ft-lb.  The two clamping conditions have been combined into a  %
% single set of maps. All data corresponding to input torques of    %
% 39.99 ft-lb and below are taken from the low-clamping-pressure    %
% data, where other data are taken from thehigh-clamping-pressure   %
% data set.															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear tx_trq_loss_map

tx_mass 				= 80.0;
tx_inertia_in_i_p 	    = 0.003;				% kg m^2
tx_inertia_out_i_p 	    = 0;					% kg m^2
tx_in_ratio_i_p 		= 1;					% Reduction ratio before the pulleys
tx_spd_thr_i 		    = 10;
tx_nb_ratio             = 5;
tx_ratio_map            = [0.428:0.492:2.396];	% total gear ratios (pulley+final gearbox)
tx_spd_eff_index        = [5 1500:500:4500]*pi/30;	% input speeds in rad/s
tx_trq_eff_index        = [1 10 20 30 39.99 40:10:70]*2*4.448/3.281;	% input torques in N-m

% map corresponding to first element in tx_ratio_index is tx_eff_trq_ratio1_map
tx_eff_trq_ratio1_map=[	0.9097	0.9097	0.9097	0.9471	0.9496	0.9262	0.9156	0.9230	0.9230
0.9097	0.9097	0.9097	0.9471	0.9496	0.9262	0.9156	0.9230	0.9230
0.9097	0.9097	0.9097	0.9471	0.9496	0.9262	0.9156	0.9230	0.9230
0.8908	0.8908	0.8908	0.9099	0.9337	0.9090	0.8912	0.9230	0.9230
0.7952	0.7952	0.7952	0.8529	0.8667	0.8479	0.8757	0.8907	0.8907
0.7952	0.7952	0.7952	0.8529	0.8667	0.8479	0.8757	0.8907	0.8907
0.7952	0.7952	0.7952	0.8529	0.8667	0.8479	0.8757	0.8907	0.8907
0.7952	0.7952	0.7952	0.8529	0.8667	0.8479	0.8757	0.8907	0.8907]';

tx_eff_trq_ratio2_map=[	0.9169	0.9169	0.9169	0.9227	0.9081	0.9307	0.9177	0.9241	0.9227
0.9169	0.9169	0.9169	0.9227	0.9081	0.9307	0.9177	0.9241	0.9227
0.9169	0.9169	0.9169	0.9227	0.9081	0.9307	0.9177	0.9241	0.9227
0.8907	0.8907	0.8907	0.9103	0.9101	0.9054	0.9002	0.9241	0.9227
0.8707	0.8786	0.8786	0.8896	0.9051	0.8844	0.9050	0.9033	0.9059
0.8619	0.8619	0.8619	0.8702	0.8957	0.8787	0.8699	0.8840	0.8891
0.8619	0.8619	0.8619	0.8539	0.8669	0.8423	0.8677	0.8840	0.8724
0.8619	0.8619	0.8619	0.7123	0.8669	0.7961	0.8344	0.8882	0.8768]';

tx_eff_trq_ratio3_map=[	0.8774	0.8774	0.8774	0.8906	0.9004	0.8784	0.9208	0.9026	0.9013
0.8774	0.8774	0.8774	0.8906	0.9004	0.8784	0.9208	0.9026	0.9013
0.8774	0.8774	0.8774	0.8906	0.9004	0.8784	0.9208	0.9026	0.9013
0.8326	0.8326	0.8326	0.8720	0.8955	0.8639	0.8786	0.9026	0.9013
0.8558	0.8558	0.8558	0.8789	0.8877	0.8628	0.8886	0.8943	0.8931
0.8236	0.8236	0.8236	0.8586	0.8640	0.8343	0.8464	0.8533	0.8850
0.8236	0.8236	0.8236	0.8200	0.8567	0.8309	0.8415	0.8747	0.8768
0.8236	0.8236	0.8236	0.6940	0.8567	0.7849	0.8151	0.8635	0.8768]';

tx_eff_trq_ratio4_map=[	0.7464	0.7464	0.8248	0.8655	0.8714	0.8670	0.8889	0.8781	0.8781
0.7464	0.7464	0.8248	0.8655	0.8714	0.8670	0.8889	0.8781	0.8781
0.7464	0.7464	0.8451	0.8694	0.8714	0.8498	0.9078	0.8781	0.8781
0.7464	0.7464	0.8066	0.8448	0.8789	0.8546	0.8563	0.8781	0.8781
0.7464	0.7464	0.8425	0.8655	0.8764	0.8544	0.9003	0.8844	0.8844
0.7464	0.7464	0.8051	0.8337	0.8414	0.8159	0.8329	0.8300	0.8300
0.7464	0.7464	0.8051	0.8002	0.8420	0.8282	0.8717	0.8300	0.8300
0.7464	0.7464	0.8051	0.8079	0.8420	0.8247	0.8317	0.8300	0.8300]';

tx_eff_trq_ratio5_map=[	0.7525	0.7525	0.8085	0.8440	0.8538	0.8377	0.8228	0.8228	0.8228
0.7525	0.7525	0.8085	0.8440	0.8538	0.8377	0.8228	0.8228	0.8228
0.7525	0.7525	0.8177	0.8509	0.8538	0.8377	0.8228	0.8228	0.8228
0.7525	0.7525	0.7823	0.8114	0.8538	0.8377	0.8228	0.8228	0.8228
0.7525	0.7525	0.8248	0.8465	0.8618	0.8397	0.8228	0.8228	0.8228
0.7525	0.7525	0.7747	0.8244	0.8211	0.7948	0.8228	0.8228	0.8228
0.7525	0.7525	0.7747	0.7807	0.8634	0.8017	0.8243	0.8243	0.8243
0.7525	0.7525	0.7747	0.7807	0.8634	0.8017	0.8243	0.8243	0.8243]';

% data for the CVT pump
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_pump_displacement            = 9e-6;%m3/tr
tx_length_belt                  = 0.65;%m
tx_length_between_pulley_axle   = 0.15;%m
tx_k_safety                     = 1.3;
tx_angle_flasque                = 11*pi/180;%11 degres
tx_coeff_friction_belt_pulley   = 0.09;
tx_section_secondary_pulley     = 99e-4;%m2
tx_visquous_coef                = 2.35e-3;%Nm/rad/s
tx_residual_trq_loss            = 0.4;

tx_primary_pulley_radius_map = [];
total_pwt_ratio = 1./(fliplr([min(tx_ratio_map):0.1:max(tx_ratio_map)])*tx_in_ratio_i_p*4);%4 default fd ratio
for cpt=total_pwt_ratio
    delta = fzero('angle_pulley',0,optimset('fzero'),tx_length_belt,tx_length_between_pulley_axle,cpt);
    tx_primary_pulley_radius_map(end+1) = (tx_length_belt-2*tx_length_between_pulley_axle*cos(delta))/((pi-2*delta)+(pi+2*delta)/cpt);
end

% calculate the torque losses
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_trq_loss_index = tx_trq_eff_index;
tx_spd_loss_index = tx_spd_eff_index;
tx_coeff = tx_trq_eff_index(:)*ones(1,length(tx_spd_eff_index));
for cpt=1:tx_nb_ratio,
    eval(['tx_trq_loss_ratio',num2str(cpt),'_map = (1 - tx_eff_trq_ratio',num2str(cpt),'_map) .* tx_coeff;']);%calculate trq loss per ratio
    tx_trq_loss_map(:,:,cpt) = eval(['tx_trq_loss_ratio',num2str(cpt),'_map']);%create the 3 dimensions (trq, spd, ratio) map for trq loss
end

% calculate the maximum efficiency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for cpt=1:tx_nb_ratio,
   tx_eff(cpt)=max(max(eval(['tx_eff_trq_ratio',num2str(cpt),'_map'])));
end
tx_eff_max=max(tx_eff);
clear cpt