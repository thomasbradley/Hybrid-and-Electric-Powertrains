%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: planetary_30_78.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: 										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: 	P.Sharer							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:									        %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialization of Planetary
tx_inertia_sun     	= .0000001;    % kgm^2
tx_inertia_carrier 	= .0000001;    % kgm^2
tx_inertia_ring    	= .000001;    % kgm^2
tx_sun_nb_teeth		= 30;   
tx_ring_nb_teeth	= 78;  
tx_ratio_i_p     	= tx_sun_nb_teeth/tx_ring_nb_teeth; % sun radius to ring radius
tx_spd_ring_init 	= 0;
tx_spd_sun_init    	= 0; % init sun speed (rad/sec)
tx_spd_planet_init  = 0;  % init planet speed  (rad/sec)
tx_mass             = 40;

Jp  = 0.0000001;
mp  = 0.0000001;      %mass of planets
Np  = 4;        % number of planets
   
   
   

   