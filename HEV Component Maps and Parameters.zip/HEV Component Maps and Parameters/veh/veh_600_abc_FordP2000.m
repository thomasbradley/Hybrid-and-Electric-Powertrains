%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: veh_600_abc_FordP2000.m     				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: Gerald ZINI - ANL 04/19/01				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
veh_mass_body 						= 600;%estimated
veh_spd_thresh_i 					= 1;		% Parameter for the blending block used in rolling resistance calculation (?)
veh_axle_base   					= 2.4;	% Vehicle wheel base, (m)
veh_cg_height_i_p    			    = 0.5;	% Vehicle CG height, (m) unknown
veh_ratio_weight_front_i_p 	        = 0.6;	% Ratio of the weight to the front wheels
veh_ratio_weight_rear_i_p 		    = (1 - veh_ratio_weight_front_i_p);
cargo_mass 							= 136;
env_gravity 						= 9.81;	% kg/m-s^2
env_dens_air 						= 1.23;

%ABC from the Ford road load match (05/30/2001)
%C = 0.30433%0.2852;
%B = 0.046096%1.4396;
%A = 201.4681%204.03;
%coef from file '1_05_24_01_rlm' with 180N @ 0mph, but A changed to 110
%C = 0.2629;
%B = 1.0573;
%A = 110;

%coef from file '1_05_24_01_rlm' with 150N @ 0mph, but A changed to 100
%F = 0.1833v^2 + 3.5871v + 161.3956
%C = 0.1833;
%B = 3.5871;
%A = 100;

%coef from file '1_06-27-01 #1 P2000 hs MD JAA Road Load Match_dgey.txt' with 150N @ 0mph
%F = 0.24834v^2 + 1.8583v + 158.932
C = 0.24834;
B = 1.8583;
A = 158.932;
