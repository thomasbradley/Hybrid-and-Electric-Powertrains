%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: veh_2873_316_044_SUV_utk.m				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model Future Truck competition 2001						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: Chad Lela- University of Tennessee 3/27/01%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks 				: Jan.31,2001							    %
% Requires the use of Model #2 (lib_veh_v02.mdl) in PSAT			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

veh_body_mass 			= 2873.96;	%kg
cargo_mass 				= 136;
veh_coeff_drag 			= 0.446;	%estimation
veh_frontal_area 	    = 3.169;
env_gravity 			= 9.81;% kg/m-s^2
veh_spd_thresh 			= 1;% Parameter for the blending block used in rolling resistance calculation.
veh_wheel_base   		= 3.302;% Vehicle wheel base, (m) As taken from GM website
veh_cg_height    		= 0.82804; % Vehicle CG height, (m) 
veh_ratio_weight_front  = 0.51;%ratio of the weight to the front wheels

%Dyno Constants based on Coastdown from 2000 Competition & Dyno testing of UT Truck
A = 58.96; 		%N
B = -.967643;	%N/(m/s) 
C = .05404;		%N/(m/s)^2 

