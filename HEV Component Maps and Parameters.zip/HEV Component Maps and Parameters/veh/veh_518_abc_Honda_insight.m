%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: veh_518_abc_insight.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: Ben Deville - ANL 8/11/00					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

veh_body_mass 					= 518; %vehicle mass without powertrain
veh_frontal_area_i_p 			= 1.9;
veh_coeff_drag_i_p 				= 0.25;
veh_spd_thresh_i 				= 1;% Parameter for the blending block used in rolling resistance calculation.
veh_axle_base   				= 2.4;% Vehicle wheel base, (m) 
veh_cg_height_i_p    			= 0.5; % Vehicle CG height, (m) unknown
veh_ratio_weight_front_i_p 	    = 0.6;%ratio of the weight to the front wheels
veh_ratio_weight_rear_i_p 		= (1-veh_ratio_weight_front_i_p );
veh_cargo_mass 					= 136;

%ABC FROM ANL test lab
A = 146;
B = -0.1841;
C = 0.275;
