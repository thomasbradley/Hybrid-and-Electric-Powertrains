%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: veh_2270_317_036_UCDavis_SUV.m			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model of a UCDavis FutureTruck 2001 SUV('SEQUOIA')		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: UCDavis - 01/05/01						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

veh_body_mass 					= ((7200+6015)/2-1613)/2.2 + 447; %vehicle mass without powertrain 
% test mass is "adjusted loaded vehicle weight" = (gross vehicle weight rating + vehicle loaded weight) / 2
% subtract 2212 lb of other vehicle components to get the glider weight
veh_frontal_area_i_p 			= 3.17;			% updated with Stock Suburban info
veh_coeff_drag_i_p 				= 0.515;    %Based on GM quoted Cd of 0.47 minus UCD drag improvements
veh_spd_thresh_i 				= 1;% Parameter for the blending block used in rolling resistance calculation.
veh_axle_base   				= 3.3;% Vehicle wheel base, (m) %From GM Website
veh_cg_height_i_p    			= 0.7; % Vehicle CG height, (m) %Results for Sequoia at FT competition
veh_ratio_weight_front_i_p 	    = 0.48;%ratio of the weight to the front wheels % from FT results
veh_ratio_weight_rear_i_p 		= (1-veh_ratio_weight_front_i_p );
veh_cargo_mass 					= 136; %Car

% Rolling Resistance Coefficient as a polynomial function of speed.
%   The coefficient will be evaluated using the expression:
%       veh_coeff_roll1 + veh_coeff_roll2*w + veh_coeff_roll3*w^2 + veh_coeff_roll4*w^3    
veh_coeff_roll1_i_p = .0045;			% updated with Goodyear tire data
veh_coeff_roll2_i_p = 0;
veh_coeff_roll3_i_p = 0;
veh_coeff_roll4_i_p = 0;


