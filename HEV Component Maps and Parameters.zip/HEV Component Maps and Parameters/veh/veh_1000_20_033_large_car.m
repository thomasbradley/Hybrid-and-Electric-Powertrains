%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: veh_1000_20_033_large_car.m				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model of a normal large car (e.g. Chevy Lumina)			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 02/19/01				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

veh_body_mass 					= 1000;         %vehicle mass without powertrain 
veh_frontal_area_i_p 			= 2.04;
veh_coeff_drag_i_p 				= 0.33;
veh_spd_thresh_i 				= 1;           % Parameter for the blending block used in rolling resistance calculation.
veh_axle_base   				= 2.6;          % Vehicle wheel base, (m) 
veh_cg_height_i_p    			= 0.5;          % Vehicle CG height, (m) 
veh_ratio_weight_front_i_p 	    = 0.6;          %ratio of the weight to the front wheels
veh_ratio_weight_rear_i_p 		= (1-veh_ratio_weight_front_i_p );
veh_cargo_mass 						= 136;

% Rolling Resistance Coefficient as a polynomial function of speed.
%   The coefficient will be evaluated using the expression:
%       veh_coeff_roll1 + veh_coeff_roll2*w + veh_coeff_roll3*w^2 + veh_coeff_roll4*w^3    
veh_coeff_roll1_i_p = .009;
veh_coeff_roll2_i_p = 0;
veh_coeff_roll3_i_p = 0;
veh_coeff_roll4_i_p = 0;



