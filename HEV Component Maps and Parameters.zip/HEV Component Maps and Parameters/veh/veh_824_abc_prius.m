%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: veh_824_abc_prius.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: Phil Sharer - ANL 8/11/00					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

veh_body_mass 						= 824;
veh_axle_base   					= 2.7432;% Vehicle wheel base, (m) from PNGV Reference supplied by Richard Swiatek, Chrysler
veh_cg_height_i_p    			    = 0.508; % Vehicle CG height, (m) 20inches as supplied by R. Swiatek, Chrysler
veh_ratio_weight_front_i_p 	        = 0.65;%ratio of the weight to the front wheels
veh_ratio_weight_rear_i_p 		    = (1-veh_ratio_weight_front_i_p );
veh_spd_thresh_i 					= 1;% Parameter for the blending block used in rolling resistance calculation.
veh_cargo_mass 						= 136;

A = 190;
B = 6; 
C = 0.1;

