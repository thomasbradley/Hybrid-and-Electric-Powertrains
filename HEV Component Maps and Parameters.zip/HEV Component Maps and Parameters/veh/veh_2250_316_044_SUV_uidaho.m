%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: 	veh_2250_316_044_SUV_Idaho.m			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model for FutureTruck 2001 Idaho University				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: DAVID ALEXANDER	-Idaho - 01/05/01		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

veh_body_mass 					= 2250;
veh_frontal_area_i_p 			= 3.169;
veh_coeff_drag_i_p 				= 0.446;
veh_axle_base   				= 2.7432;% Vehicle wheel base, (m) from PNGV Reference supplied by Richard Swiatek, Chrysler
veh_cg_height_i_p    			= 0.508;% Vehicle CG height, (m) 20inches as supplied by R. Swiatek, Chrysler
veh_ratio_weight_front_i_p 	    = 0.60;%ratio of the weight to the front wheels
veh_ratio_weight_rear_i_p 		= (1-veh_ratio_weight_front_i_p );
veh_spd_thresh_i 				= 1;% Parameter for the blending block used in rolling resistance calculation.
veh_cargo_mass 					= 136;

% Rolling Resistance Coefficient as a polynomial function of speed.
%   The coefficient will be evaluated using the expression:
%       veh_coeff_roll1 + veh_coeff_roll2*w + veh_coeff_roll3*w^2 + veh_coeff_roll4*w^3    
veh_coeff_roll1_i_p = .0055;
veh_coeff_roll2_i_p = 0;
veh_coeff_roll3_i_p = 0;
veh_coeff_roll4_i_p = 0;



