%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: veh_2249_316_044_SUV_pennstate.m			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% vehicle model 2000 GM Suburban PowerLion - FutureTruck 2001		%																	
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: Sara Inman & Brian Kleback - 1/30/01		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 									    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

veh_body_mass 			= 2249;%veh_mass_body = 2550-41(stocktranny)-260(stock engine);
veh_cargo_mass 		    = 180;
veh_frontal_area 		= 3.169;
veh_coeff_drag 			= 0.446;
veh_spd_thresh 			= 1;% Parameter for the blending block used in rolling resistance calculation.
veh_wheel_base   		= 3.302;
veh_cg_height    		= 0.6731; % Vehicle CG height, (m) 20inches as supplied by R. Swiatek, Chrysler
veh_ratio_weight_front 	= 0.55;%ratio of the weight to the front wheels

% Rolling Resistance Coefficient as a polynomial function of speed.
%   The coefficient will be evaluated using the expression:
%       veh_coeff_roll1 + veh_coeff_roll2*w + veh_coeff_roll3*w^2 + veh_coeff_roll4*w^3    
%veh_coeff_roll1 = .006;
veh_coeff_roll1 = .009;
veh_coeff_roll2 = 0;
veh_coeff_roll3 = 0;
veh_coeff_roll4 = 0;








