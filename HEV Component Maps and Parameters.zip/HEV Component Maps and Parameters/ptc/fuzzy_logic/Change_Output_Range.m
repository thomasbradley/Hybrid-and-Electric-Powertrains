function out = Change_Output_Range(fis, output, NewRange)
% Change range of one of the fuzzy logic control outputs
% fis = name of fismatrix to modify
% output = number of output to modify
% NewRange = desired range for ouput: [lower bound, upper bound]
% out = modified fis matrix

OldRange = fis.output(output).range;
NumMFs = length(fis.output(output).mf);
DiffOldRange=diff(OldRange);
DiffNewRange=diff(NewRange);
fis.output(output).range = NewRange;


for i = 1:NumMFs
   
   MFType = fis.output(output).mf(i).type;
   OldParams = fis.output(output).mf(i).params;
   
   if strcmp(MFType,'trimf') | strcmp(MFType,'trapmf') | strcmp(MFType,'pimf') | ...
         strcmp(MFType,'smf'),
      NewParams=(OldParams-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'constant'),
      NewParams=(OldParams-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      fis.output(output).mf(i).name = num2str(NewParams(1),3);
      
   elseif strcmp(MFType,'linear'),
      NewParams=(OldParams-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      fis.output(output).mf(i).name = ['Linear', num2str(NewParams(min(find(NewParams~=0))),3)];
      
   elseif strcmp(MFType,'gbellmf'),
      NewParams(1)=OldParams(1)/DiffOldRange*DiffNewRange;
      NewParams(2)=OldParams(2);
      NewParams(3)=(OldParams(3)-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'gaussmf'),
      NewParams(1)=OldParams(1)/DiffOldRange*DiffNewRange;
      NewParams(2)=(OldParams(2)-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'gauss2mf'),
      NewParams([1 3])=OldParams([1 3])/DiffOldRange*DiffNewRange;
      NewParams([2 4])=(OldParams([2 4])-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'sigmf'),
      NewParams(1)=OldParams(1)*DiffOldRange/DiffNewRange;
      NewParams(2)=(OldParams(2)-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'dsigmf') | strcmp(MFType,'psigmf'),
      NewParams([1 3])=OldParams([1 3])*DiffOldRange/DiffNewRange;
      NewParams([2 4])=(OldParams([2 4])-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
   end
   
   fis.output(output).mf(i).params = NewParams;
   
end

out = fis;