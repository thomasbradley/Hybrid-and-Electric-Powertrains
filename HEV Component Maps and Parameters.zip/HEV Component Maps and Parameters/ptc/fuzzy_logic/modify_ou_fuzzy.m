% Modify Oakland University fuzzy logic controller
% based on GUI variables and component sizes

% Load FE or EM Rule Base For Oakland University Fuzzy Logic Controller
if strcmp(model.strategy.conso.prop.init,'p_par_fuzzy_fueleconomy')
   PHVfueleconomy=readfis('PHVFuelEconomyFE'); % Load Fuel Economy (FE) rule base
   %PHVfueleconomy=readfis('PHVfueleconomyFE_updated'); % If adaptive fuzzy is used
elseif strcmp(model.strategy.conso.prop.init,'p_par_fuzzy_emission')
   PHVfueleconomy=readfis('PHVFuelEconomyEM'); % Load Reduced Emissions (EM) rule base
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modify membership functions of the controller according to GUI variables %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change ranges of the inputs and outputs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modify the controller based on component sizes %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PHVfueleconomy = Change_Input_Range(PHVfueleconomy, 3, [0 mc_spd_max_index_max]);
PHVfueleconomy = Change_Input_Range(PHVfueleconomy, 4, [ptc_tx_ratio_map_min ptc_tx_ratio_map_max]);
PHVfueleconomy = Change_Output_Range(PHVfueleconomy, 1, [0 eng_spd_hot_max]);
PHVbraking = Change_Output_Range(PHVbraking, 1, [0 eng_spd_hot_max]);
PHVperformance = Change_Output_Range(PHVperformance, 1, [0 eng_spd_hot_max]);
PHVfueleconomycorrection = Change_Input_Range(PHVfueleconomycorrection, 7, [ptc_tx_ratio_map_min ptc_tx_ratio_map_max]);

ptc_mc_charge_multiplier=eng_pwr_max/(ess_pwr_chg*ess_num_cell);
if ptc_mc_charge_multiplier<0.75,
    ptc_mc_charge_multiplier=0.75;
elseif ptc_mc_charge_multiplier>1.25
    ptc_mc_charge_multiplier=1.25;
end
change_fuzzy_params

% Variables used for normalizing the driver torque demand
% scaling based on maximum eng and mc power, and max braking torque
if exist('eng_pwr_max_des')
   max_eng_power = eng_pwr_max_des;
else
   max_eng_power = eng_pwr_max;
end

if exist('mc_pwr_max_des')
   max_mc_power = mc_pwr_max_des;
else
   max_mc_power = mc_pwr_max;
end
