%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: Change_Fuzzy_params						%			
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: Change the parameters used by fuzzy logic %
%                         if parameters are changed in the GUI by   %
%                         the user.                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: S.Saglini & N.Schouten - 02/06/2002		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks :     													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Engine speed scaling according to the max efficiency spd and trq curve %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%[a,b]=max(ptc_eng_trq_hot_opt_map);
%eng_spd_factor=ptc_eng_spd_hot_opt_trq_idx(b);
%if strcmp(model.strategy.conso.prop.init,'p_par_fuzzy_fueleconomy'),
%    eng_scale_factor=320/eng_spd_factor;
%elseif strcmp(model.strategy.conso.prop.init,'p_par_fuzzy_emission'),
%    eng_scale_factor=380/eng_spd_factor;
%end

%replace the new params in the apprpriate matrix
%PHVfueleconomy.output(1).mf(1).params = PHVfueleconomy.output(1).mf(1).params/eng_scale_factor;
%PHVfueleconomy.output(1).mf(2).params = PHVfueleconomy.output(1).mf(2).params/eng_scale_factor;
%PHVfueleconomy.output(1).mf(3).params = PHVfueleconomy.output(1).mf(3).params/eng_scale_factor;
%PHVfueleconomy.output(1).mf(4).params = PHVfueleconomy.output(1).mf(4).params/eng_scale_factor;
%PHVfueleconomy.output(1).mf(5).params = PHVfueleconomy.output(1).mf(5).params/eng_scale_factor;
%PHVfueleconomy.output(1).mf(6).params = PHVfueleconomy.output(1).mf(6).params/eng_scale_factor;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Percentage of best eng trq curve for NOx emission reduction            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%if strcmp(model.strategy.conso.prop.init,'p_par_fuzzy_emission'),
%    PHVfueleconomy.output(2).mf(2).params = 0.5;%0.54
%    PHVfueleconomy.output(2).mf(3).params = 0.5;%0.55
%    PHVfueleconomy.output(2).mf(4).params = 0.6;%0.61
%    PHVfueleconomy.output(2).mf(5).params = 0.7;%0.76
%    PHVfueleconomy.output(2).mf(6).params = 0.8;%0.75
%    PHVfueleconomy.output(2).mf(7).params = 0.9;%0.91
%end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Electric Motor Command                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if strcmp(model.strategy.conso.prop.init,'p_par_fuzzy_fueleconomy')
    ptc_mc_charge_multiplier=1.05;
elseif strcmp(model.strategy.conso.prop.init,'p_par_fuzzy_emission')
    ptc_mc_charge_multiplier=0.45;
end

%replace the new params in the apprpriate matrix
PHVfueleconomy.output(3).mf(1).params = PHVfueleconomy.output(3).mf(1).params*ptc_mc_charge_multiplier;
PHVfueleconomy.output(3).mf(2).params = PHVfueleconomy.output(3).mf(2).params*ptc_mc_charge_multiplier;
PHVfueleconomy.output(3).mf(3).params = PHVfueleconomy.output(3).mf(3).params*ptc_mc_charge_multiplier;
out = PHVfueleconomy;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change the driver MF values to try to have less eng ON/OFF             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PHVfueleconomy.input(1).mf(1).params = [0         0.02      0.08      0.1];%LOW / 0         0    0.0800    0.0900
PHVfueleconomy.input(1).mf(2).params = [0.08      0.12      0.38      0.4];%MedLow / 0.0800    0.0900    0.3200
PHVfueleconomy.input(1).mf(3).params = [0.38      0.42      0.68      0.7];%Med / 0.0900    0.3200    0.5000
PHVfueleconomy.input(1).mf(4).params = [0.68      0.72      0.88      0.9];%MedHigh / 0.3200    0.5000    0.9300
PHVfueleconomy.input(1).mf(5).params = [0.85      0.90      1.00      1.1];%Perfo / 0.5000    0.9300    1.0000    1.5000
PHVfueleconomy.input(1).mf(6).params = [-1.1      -1         0         0];% BRAKING / -1.1000   -1.0000         0         0
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change the Electric Motor (MC) optimal range of work taking in account %
% the upper bound and lower bound given by the user in the GUI           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ((ptc_p_mc_spd_opt_upper_bound<= PHVfueleconomy.input(3).range(2))&(ptc_p_mc_spd_opt_lower_bound>=PHVfueleconomy.input(3).range(1))...
        &(ptc_p_mc_spd_opt_upper_bound>= PHVfueleconomy.input(3).range(1))&(ptc_p_mc_spd_opt_lower_bound<=PHVfueleconomy.input(3).range(1))),
    % Check if upper bound is larger than lower bound, if not reverse the two
    if ptc_p_mc_spd_opt_upper_bound < ptc_p_mc_spd_opt_lower_bound;
        backup = ptc_p_mc_spd_opt_lower_bound;
        ptc_p_mc_spd_opt_lower_bound = ptc_p_mc_spd_opt_upper_bound;
        ptc_p_mc_spd_opt_upper_bound = backup;
    end
end
% get membership function parameters
mc_spd_curve1 = PHVfueleconomy.input(3).mf(1).params;
mc_spd_curve2 = PHVfueleconomy.input(3).mf(2).params;
mc_spd_curve3 = PHVfueleconomy.input(3).mf(3).params;

% Check if upper bound minus lower bound is larger than minimum membership function width
% if not, shift bounds away from each other
flank1 = mc_spd_curve2(2)-mc_spd_curve2(1);
flank2 = mc_spd_curve2(4)-mc_spd_curve2(3);
widht_min = (flank1+flank2)/2;
if (ptc_p_mc_spd_opt_upper_bound - ptc_p_mc_spd_opt_lower_bound) < widht_min
    bound_avg = (ptc_p_mc_spd_opt_upper_bound + ptc_p_mc_spd_opt_lower_bound)/2;
    mc_spd_opt_upper_bound = bound_avg + widht_min/2;
    mc_spd_opt_lower_bound = bound_avg - widht_min/2;
end

flank1_middle = (mc_spd_curve2(2)+mc_spd_curve2(1))/2;
flank2_middle = (mc_spd_curve2(4)+mc_spd_curve2(3))/2;
change1 = ptc_p_mc_spd_opt_lower_bound - flank1_middle;
change2 = ptc_p_mc_spd_opt_upper_bound - flank2_middle;
PHVfueleconomy.input(3).mf(1).params = mc_spd_curve1 + [0 0 1 1]*change1;
PHVfueleconomy.input(3).mf(2).params = mc_spd_curve2 + [1 1 0 0]*change1 + [0 0 1 1]*change2;
PHVfueleconomy.input(3).mf(3).params = mc_spd_curve3 + [1 1 0 0]*change2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change the SOC different's ranges according to the SOC limit given in the GUI %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Check if upper bound is larger than lower bound, if not reverse the two
if((ptc_p_soc_low_norm_limit>= PHVfueleconomy.input(2).range(1))&(ptc_p_soc_low_norm_limit<= PHVfueleconomy.input(2).range(2))&...
        (ptc_p_soc_toolow_low_limit>= PHVfueleconomy.input(2).range(1))&(ptc_p_soc_toolow_low_limit<= PHVfueleconomy.input(2).range(2))&...
        (ptc_p_soc_norm_toohi_limit>= PHVfueleconomy.input(2).range(1))&(ptc_p_soc_norm_toohi_limit<= PHVfueleconomy.input(2).range(2))),
    
    while ((ptc_p_soc_low_norm_limit<ptc_p_soc_toolow_low_limit)|(ptc_p_soc_norm_toohi_limit< ptc_p_soc_low_norm_limit)),
        if ptc_p_soc_low_norm_limit< ptc_p_soc_toolow_low_limit;
            backup = ptc_p_soc_toolow_low_limit;
            ptc_p_soc_toolow_low_limit = ptc_p_soc_low_norm_limit;
            ptc_p_soc_low_norm_limit = backup;
        end
        
        if ptc_p_soc_norm_toohi_limit< ptc_p_soc_low_norm_limit;
            backup = ptc_p_soc_low_norm_limit;
            ptc_p_soc_low_norm_limit = ptc_p_soc_norm_toohi_limit;
            ptc_p_soc_norm_toohi_limit = backup;
        end
    end
end
% get membership function parameters
soc_curve1 = PHVfueleconomy.input(2).mf(1).params;
soc_curve2 = PHVfueleconomy.input(2).mf(2).params;
soc_curve3 = PHVfueleconomy.input(2).mf(3).params;
soc_curve4 = PHVfueleconomy.input(2).mf(4).params;

% Check if upper bound minus lower bound is larger than minimum membership function width
% if not, shift bounds away from each other
flank1 = soc_curve2(2)-soc_curve2(1);
flank2 = soc_curve2(4)-soc_curve2(3);
widht_min = (flank1+flank2)/2;
if (ptc_p_soc_low_norm_limit - ptc_p_soc_toolow_low_limit) < widht_min
    bound_avg = (ptc_p_soc_low_norm_limit + ptc_p_soc_toolow_low_limit)/2;
    ptc_p_soc_low_norm_limit = bound_avg + widht_min/2;
    ptc_p_soc_toolow_low_limit = bound_avg - widht_min/2;
end

flank3 = soc_curve3(2)-soc_curve3(1);
flank4 = soc_curve3(4)-soc_curve3(3);
widht_min = (flank1+flank2)/2;
if (ptc_p_soc_norm_toohi_limit - ptc_p_soc_low_norm_limit) < widht_min
    bound_avg = (ptc_p_soc_norm_toohi_limit + ptc_p_soc_low_norm_limit)/2;
    ptc_p_soc_norm_toohi_limit = bound_avg + widht_min/2;
    ptc_p_soc_low_norm_limit = bound_avg - widht_min/2;
end

flank1_middle = (soc_curve2(2)+soc_curve2(1))/2;
flank2_middle = (soc_curve2(4)+soc_curve2(3))/2;
flank3_middle = (soc_curve3(4)+soc_curve3(3))/2;
change1 = ptc_p_soc_toolow_low_limit - flank1_middle;
change2 = ptc_p_soc_low_norm_limit - flank2_middle;
change3 = ptc_p_soc_norm_toohi_limit - flank3_middle;
PHVfueleconomy.input(2).mf(1).params = soc_curve1 + [0 0 1 1]*change1;
PHVfueleconomy.input(2).mf(2).params = soc_curve2 + [1 1 0 0]*change1 + [0 0 1 1]*change2;
PHVfueleconomy.input(2).mf(3).params = soc_curve3 + [1 1 0 0]*change2 + [0 0 1 1]*change3;
PHVfueleconomy.input(2).mf(4).params = soc_curve4 + [1 1 0 0]*change3;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change the vehicle speed different's ranges according to the vehicle speed limit given in the GUI %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

PHVfueleconomy.input(5).mf(1).params = [-10   -9    5.5    6];
PHVfueleconomy.input(5).mf(2).params = [5.5    6    6    12];
PHVfueleconomy.input(5).mf(3).params = [6   12    90    95];

%if((ptc_p_veh_spd_low_otherwise_limit<=PHVfueleconomy.input(5).range(2))&(ptc_p_veh_spd_low_otherwise_limit>=PHVfueleconomy.input(5).range(1))&...
%        (ptc_p_veh_spd_toolow_low_limit<=PHVfueleconomy.input(5).range(2))&(ptc_p_veh_spd_toolow_low_limit>=PHVfueleconomy.input(5).range(1))),
%    if ptc_p_veh_spd_low_otherwise_limit<ptc_p_veh_spd_toolow_low_limit;
%        backup = ptc_p_veh_spd_toolow_low_limit;
%        ptc_p_veh_spd_toolow_low_limit = ptc_p_veh_spd_low_otherwise_limit;
%        ptc_p_veh_spd_low_otherwise_limit = backup;
%    end
%end
%veh_spd_curve1 = PHVfueleconomy.input(5).mf(1).params;
%veh_spd_curve2 = PHVfueleconomy.input(5).mf(2).params;
%veh_spd_curve3 = PHVfueleconomy.input(5).mf(3).params;
%flank1 = veh_spd_curve2(2)-veh_spd_curve2(1);
%flank2 = veh_spd_curve2(4)-veh_spd_curve2(3);
%widht_min = (flank1+flank2)/2;

%if (ptc_p_veh_spd_low_otherwise_limit - ptc_p_veh_spd_toolow_low_limit) < widht_min
%    bound_avg = (ptc_p_veh_spd_low_otherwise_limit + ptc_p_veh_spd_toolow_low_limit)/2;
%    ptc_p_veh_spd_low_otherwise_limit = bound_avg + widht_min/2;
%    ptc_p_veh_spd_toolow_low_limit = bound_avg - widht_min/2;
%end

%flank_middle1 = (veh_spd_curve2(2) + veh_spd_curve1(3))/2;
%flank_middle2 = (veh_spd_curve3(2) + veh_spd_curve2(3))/2;
%change1 = ptc_p_veh_spd_toolow_low_limit - flank_middle1;
%change2 = ptc_p_veh_spd_low_otherwise_limit - flank_middle2;
%PHVfueleconomy.input(5).mf(1).params = veh_spd_curve1 + [0 0 1 1]*change1;
%PHVfueleconomy.input(5).mf(2).params = veh_spd_curve2 + [1 1 0 0]*change1 + [0 0 1 1]*change2;
%PHVfueleconomy.input(5).mf(3).params = veh_spd_curve3 + [1 1 0 0]*change2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change the regenerative properties depending on the SOC according to limit given in the GUI %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if((ptc_p_soc_max_regen<=PHVbraking.input(2).range(2))&(ptc_p_soc_max_regen>=PHVbraking.input(2).range(1))),
    % get membership function parameters
    soc_limit_stop_regen_cuvre1 = PHVbraking.input(2).mf(1).params;
    flank_middle = (soc_limit_stop_regen_cuvre1(1) + soc_limit_stop_regen_cuvre1(2))/2;
    change = ptc_p_soc_max_regen - flank_middle;
    soc_limit_stop_regen_cuvre1 = soc_limit_stop_regen_cuvre1 + [1 1 0 0]*change;
    PHVbraking.input(2).mf(1).params = soc_limit_stop_regen_cuvre1;
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change the regenerative properties depending on the vehicle speed according %
% to limit given in the GUI                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if((ptc_p_veh_spd_min_regen<=PHVbraking.input(3).range(2))&(ptc_p_veh_spd_min_regen>=PHVbraking.input(3).range(1))),
    % get membership function parameters
    veh_spd_limit_stop_regen_cuvre1 = PHVbraking.input(3).mf(1).params;
    flank_middle = (veh_spd_limit_stop_regen_cuvre1(4) + veh_spd_limit_stop_regen_cuvre1(3))/2;
    change = ptc_p_veh_spd_min_regen - flank_middle;
    veh_spd_limit_stop_regen_cuvre1 = veh_spd_limit_stop_regen_cuvre1 + [0 0 1 1]*change;
    PHVbraking.input(3).mf(1).params = veh_spd_limit_stop_regen_cuvre1;
end

PHVbraking.output(3).mf(1).params = [5  0   0  0];%1.48 - MC regen coeff
PHVbraking.output(4).mf(1).params = [-0.2  0   0  0];%-0.52 - mechanical brake regen coeff