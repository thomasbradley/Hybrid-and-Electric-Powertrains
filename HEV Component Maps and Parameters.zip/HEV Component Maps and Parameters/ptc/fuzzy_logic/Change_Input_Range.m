function out = Change_Input_Range(fis, input, NewRange)
% Change range of one of the fuzzy logic control inputs
% fis = name of fismatrix to modify
% input = number of input to modify
% NewRange = desired range for ouput: [lower bound, upper bound]
% out = modified fis matrix

OldRange = fis.input(input).range;
NumMFs = length(fis.input(input).mf);
DiffOldRange=diff(OldRange);
DiffNewRange=diff(NewRange);
fis.input(input).range = NewRange;


for i = 1:NumMFs
   
   MFType = fis.input(input).mf(i).type;
   OldParams = fis.input(input).mf(i).params;
   
   if strcmp(MFType,'trimf') | strcmp(MFType,'trapmf') | strcmp(MFType,'pimf') | ...
         strcmp(MFType,'smf') | strcmp(MFType,'smf'),
      NewParams=(OldParams-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'gbellmf'),
      NewParams(1)=OldParams(1)/DiffOldRange*DiffNewRange;
      NewParams(2)=OldParams(2);
      NewParams(3)=(OldParams(3)-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'gaussmf'),
      NewParams(1)=OldParams(1)/DiffOldRange*DiffNewRange;
      NewParams(2)=(OldParams(2)-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'gauss2mf'),
      NewParams([1 3])=OldParams([1 3])/DiffOldRange*DiffNewRange;
      NewParams([2 4])=(OldParams([2 4])-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'sigmf'),
      NewParams(1)=OldParams(1)*DiffOldRange/DiffNewRange;
      NewParams(2)=(OldParams(2)-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
      
   elseif strcmp(MFType,'dsigmf') | strcmp(MFType,'psigmf'),
      NewParams([1 3])=OldParams([1 3])*DiffOldRange/DiffNewRange;
      NewParams([2 4])=(OldParams([2 4])-OldRange(1))/DiffOldRange*DiffNewRange+NewRange(1);
   end
   
   fis.input(input).mf(i).params = NewParams;
   
end

out = fis;