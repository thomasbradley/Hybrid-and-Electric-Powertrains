function out = get_ou_fuzzy_variables(fis_fueleconomy, fis_braking)



% get 
          %the limit between Too low and low SOC
          %the limit between low and normal SOC 
          %the limit between normal and too high SOC 
          
soc_curve_mf1 = fis_fueleconomy.input(2).mf(1).params;
soc_curve_mf2 = fis_fueleconomy.input(2).mf(2).params;
soc_curve_mf3 = fis_fueleconomy.input(2).mf(3).params;
soc_curve_mf4 = fis_fueleconomy.input(2).mf(4).params;

out(1) = (soc_curve_mf1(3)+soc_curve_mf2(2))/2;       %the limit between Too low and low soc
out(2) = (soc_curve_mf2(3)+soc_curve_mf3(2))/2;       %the limit between low and normal soc 
out(3) = (soc_curve_mf3(3)+soc_curve_mf4(2))/2;       %the limit between normal and too high soc

% get veh_spd_min_regen
veh_spd_stop_regen_curve_mf1 = fis_braking.input(3).mf(1).params;

out(4) = (veh_spd_stop_regen_curve_mf1(4) + veh_spd_stop_regen_curve_mf1(3))/2;     %the speed limit where the vehicle should stop regen

% get soc_max_regen
soc_stop_regen_curve_mf1 = fis_braking.input(2).mf(1).params;
out(5) = (soc_stop_regen_curve_mf1(1) + soc_stop_regen_curve_mf1(2))/2;

% get mc_spd_opt_upper_bound and mc_spd_opt_lower_bound
mc_speed_curve_mf2 = fis_fueleconomy.input(3).mf(2).params;
out(6) = (mc_speed_curve_mf2(2)+mc_speed_curve_mf2(1))/2;
out(7) = (mc_speed_curve_mf2(4)+mc_speed_curve_mf2(3))/2;

% get veh_spd_min_eng_on
veh_speed_curve_mf1 = fis_fueleconomy.input(5).mf(1).params;
veh_speed_curve_mf2 = fis_fueleconomy.input(5).mf(2).params;
veh_speed_curve_mf3 = fis_fueleconomy.input(5).mf(3).params;

out(8) = (veh_speed_curve_mf2(2) + veh_speed_curve_mf1(3))/2;     %the limit between Too low and low vehicle speed
out(9) = (veh_speed_curve_mf3(2) + veh_speed_curve_mf2(3))/2;     %the limit between low and otherwise vehicle speed
