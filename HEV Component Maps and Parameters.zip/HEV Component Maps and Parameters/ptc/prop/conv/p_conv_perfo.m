%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: p_conv_perfo.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: initialize the parameters used in the	%
% conventionnal power controller model								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: A.Rousseau - ANL - 08/12/99			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERSptc_p_ess_soc_goal              = 0.7;      %DESCRIPTION: (0->1)SOC control variable: SOC charge map center point
ptc_p_ess_soc_chg_lim           = 0.6;     %DESCRIPTION: (0->1)SOC charge map: SOC at which maximum charging power of the battery is used.
ptc_p_ess_soc_dis_lim           = 0.8;      %DESCRIPTION: (0->1)SOC charge map: SOC at which maxmimum discharging power of the battery is used.
ptc_p_rate_ess_chg              = 0.8;      %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_chg_lim
ptc_p_rate_ess_dis              = 0;      %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_dis_lim
%END_STRATEGY_PARAMETERS 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute maximum tractive torque available at wheel
% Used to go from drv trq dmd to -1->1 pedal dmd (accel or brake)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1/wh_radius; % 10% more
ptc_wh_trq_max = min (ptc_wh_trq_slip,ptc_eng_ratio_cum*max(tx_ratio_map)*max(eng_trq_max_hot_map));


