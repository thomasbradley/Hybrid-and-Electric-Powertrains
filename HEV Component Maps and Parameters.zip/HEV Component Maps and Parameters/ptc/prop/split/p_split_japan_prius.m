%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: p_split_japan_prius.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters of the split ptc%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: P. Sharer								    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_p_eng_pwr_min_on_p            = 3270;     %DESCRIPTION: (W) When the engine is on this is the minimum power it will supply.  If less is requested, more is given
ptc_p_eng_on_soc_p                = 0.549;    %DESCRIPTION: (0->1) If the SOC is less than this value, the engine will turn on.
ptc_p_eng_off_soc_p               = 0.575;    %DESCRIPTION: (0->1) If the SOC is greater than this value, the engine will shut off.
ptc_p_eng_t_on_min_p              = 5;	      %DESCRIPTION: (sec.) Once the engine is turned on it will stay on for this minimum duration.    
ptc_p_eng_t_off_min_p             = 1.7;	  %DESCRIPTION: (sec.) Once the engine is turned off it will stay off for this minimum duration.
ptc_p_fc_pwr_on_p                 = 4000;     %DESCRIPTION:
ptc_p_fc_pwr_off_p                = 3000;     %DESCRIPTION:
ptc_p_mc_spd_max_eng_on_p         = 171;	  %DESCRIPTION: (rd/s) Above this motor speed the engine will continue to spin although it is no longer being fueled
ptc_p_mc_prop_on_soc_p            = 0.43;     %DESCRIPTION: (0->1) SOC above which we can assist
ptc_p_mc_prop_off_soc_p           = 0.40;     %DESCRIPTION: (0->1) SOC below which we cannot assit
ptc_p_mc_spd_regen_brake_off_p    = 5;        %DESCRIPTION: (km/hr) Speed at which the regenerative torque drops off to allow for
ptc_p_mc_soc_regen_off_p          = 0.97;     %DESCRIPTION: (0->1) SOC at which regenerative Braking is Disabled 	
ptc_p_mc_spd_regen_brake_off_p    = 1;        %DESCRIPTION: (m/s)  Speed at which the regenerative torque drops off to allow for
ptc_p_ess_soc_turtle_on_p         = 0.40;     %DESCRIPTION: (0->1) Battery Turtle Light Thresholds
ptc_p_ess_soc_turtle_off_p        = 0.43;     %DESCRIPTION: (0->1)
ptc_p_ess_curr_max_chg_p          = 50;       %DESCRIPTION: (Amps) Current Limit On Battery Recharge
ptc_p_veh_spd_regen_brake_off_p   = 1.4;      %DESCRIPTION: (m/s)  Regenerative Braking is reduced to allow friction braking
ptc_p_gc_kp_on_p                  = 0.9;      %DESCRIPTION:Proportional Gain for Engine On State 
ptc_p_gc_ki_on_p                  = 0.005;    %DESCRIPTION:Integral Gain for Engine Off State      
ptc_p_gc_kp_starting_p            = 0.25;	  %DESCRIPTION:Proportional Gain for Engine Starting State 
ptc_p_gc_ki_starting_p            = 0.005;    %DESCRIPTION:Integral Gain for Engine Starting State
ptc_p_gc_kp_stopping_p            = 0.01;     %DESCRIPTION:Proportional Gain for Engine Stopping State
ptc_p_gc_ki_stopping_p            = 0.009;    %DESCRIPTION:Integral Gain for Engine Stopping State
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ptc_p_veh_inertia = veh_mass / fd_ratio * trc_ratio * wh_radius^2 + mc_inertia;  

% Accelerator Pedal demand maps used to determine when the engine turns on or off
% Specific for the Japan Prius
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_p_acc_veh_spd_index = [0 10 20 25 30 35 40 45 50 55 60 65 70 80 90 100]*1.6/3.6;
ptc_p_acc_ess_soc_index = [0.2 0.3 0.4 0.5 0.58 0.59 0.60 0.65 0.7 0.8];
ptc_p_veh_acc_on_map = [ ...
        0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.1 0.1 0.1 0.10 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04];
ptc_p_veh_acc_off_map = [ ...
        0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04;
    0.07 0.07 0.07 0.070 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04 0.04];

% SOC to Battery Power Demand Curve
ptc_p_ess_soc_index = [0.35  0.36   0.365  0.45   0.46   0.49  0.51   		 0.52   		0.53  	 0.56   0.57   0.58 0.585   0.592  0.61    0.63];
ptc_p_ess_pwr_map = [ 8137.1 6910.7 6800.5 6800.5 6730.4 6500  2962.1+1500 1759.5+1500 1377.0+1500 812.0 759.0  600    500   -1000 -1600 -2000.0] + 1700;

% Most Efficient Operating Curve of the Engine - special tuning for the Japan Prius
ptc_p_eng_pwr_hot_opt_map = [0 3.27 4.96 6.25 7.68 9.1 11.1 12.705 15.08 40.336 43]*1000;
ptc_p_eng_spd_hot_opt_pwr_idx = [0+eps 119 124 125 128 130 150 165 188.5 418.9 445];
ptc_p_eng_trq_hot_opt_map = ptc_p_eng_pwr_hot_opt_map./(ptc_p_eng_spd_hot_opt_pwr_idx+(ptc_p_eng_spd_hot_opt_pwr_idx==0)).*(ptc_p_eng_spd_hot_opt_pwr_idx~=0);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I - Parameters used by all control strategies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute maximum tractive torque available at wheel
% Used to go from drv trq dmd to -1->1 pedal dmd (accel or brake)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if exist('trc_ratio')~=1, trc_ratio=1; end
ptc_p_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.8*1.1*wh_radius;
ptc_p_wh_trq_max = min(ptc_p_wh_trq_slip,fd_ratio * trc_ratio *(max(mc_trq_max_map) + 1 * tx_ring_nb_teeth/(tx_ring_nb_teeth+tx_sun_nb_teeth) * max(eng_trq_max_hot_map))); 

ptc_p_percent_front_brake = 0.7;%used for 4WD configurations
