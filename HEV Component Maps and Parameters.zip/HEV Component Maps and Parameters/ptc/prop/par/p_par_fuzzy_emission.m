%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: p_par_fuzzy_emission.m    				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
%                         parallel hybrid power controller model	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			:  A. Rousseau - ANL - 09/12/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:                                           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%BEGIN_STRATEGY_DESCRIPTION
%END_STRATEGY_DESCRIPTION

PHVfueleconomy=readfis('PHVFuelEconomyEM'); % Load Emission (EM) rule base
PHVbraking=readfis('PHVBraking');
PHVperformance=readfis('PHVPerformance');
PHVfueleconomycorrection=readfis('PHVFuelEconomyCorrection');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modify the controller based on component sizes %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Change ranges of the inputs and outputs
PHVfueleconomy = Change_Input_Range(PHVfueleconomy, 3, [0 mc_spd_max_index_max]);
PHVfueleconomy = Change_Input_Range(PHVfueleconomy, 4, [ptc_tx_ratio_map_min ptc_tx_ratio_map_max]);
PHVfueleconomy = Change_Output_Range(PHVfueleconomy, 1, [0 eng_spd_hot_max]);
PHVbraking     = Change_Output_Range(PHVbraking, 1, [0 eng_spd_hot_max]);
PHVperformance = Change_Output_Range(PHVperformance, 1, [0 eng_spd_hot_max]);
PHVfueleconomycorrection = Change_Input_Range(PHVfueleconomycorrection, 7, [ptc_tx_ratio_map_min ptc_tx_ratio_map_max]);

ou_fuzzy_vars = get_ou_fuzzy_variables(PHVfueleconomy, PHVbraking);    % Get values of the GUI variables from the fuzzy logic controller

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_p_eng_min_on_time             = 1;					                %DESCRIPTION: internal Combustion Engine Minimum On Time (s)
ptc_p_eng_min_off_time            = 1;				                    %DESCRIPTION: internal Combustion Engine Minimum Off Time (s)
ptc_p_soc_toolow_low_limit        = ou_fuzzy_vars(1);                   %DESCRIPTION: limit between too low and low SOC
ptc_p_soc_low_norm_limit          = ou_fuzzy_vars(2);                   %DESCRIPTION: limit between low and normal SOC
ptc_p_soc_norm_toohi_limit        = ou_fuzzy_vars(3);                   %DESCRIPTION: limit between normal and too high SOC  
ptc_p_veh_spd_min_regen           = ou_fuzzy_vars(4);	                %DESCRIPTION: vehicle Speed Below Which Regenerative Braking Is Disabled (m/s)
ptc_p_soc_max_regen               = ou_fuzzy_vars(5);		            %DESCRIPTION: soc Above Which Regenerative Braking Is Disabled
ptc_p_mc_spd_opt_lower_bound      = ou_fuzzy_vars(6);                   %DESCRIPTION: Lower Bound of Optimal Electric Motor Speed Range (rad/s)
ptc_p_mc_spd_opt_upper_bound      = ou_fuzzy_vars(7);                   %DESCRIPTION: upper Bound of Optimal Electric Motor Speed Range (rad/s)
ptc_p_veh_spd_toolow_low_limit    = ou_fuzzy_vars(8);                   %DESCRIPTION: limit between too low and low vehicle speed
ptc_p_veh_spd_low_otherwise_limit = ou_fuzzy_vars(9);                   %DESCRIPTION: limit between low and otherwise vehicle speed
ptc_p_mc_charge_multiplier        = 1;                                  %DESCRIPTION: Charging Power Multiplier (0.75 to 1.25)
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ptc_p_veh_spd_above_eng_start     = 15;%m/s - vehicle speed above we have to start the engine
ptc_p_eng_cmd_min                 = 0.5;%minimum engine command when the vehicle speed is above ptc_p_veh_spd_above_eng_start
ptc_p_tx_trq_blend_sft            = 0.5;
ptc_p_tx_t_shift                  = 0.5;%for automatic tx
ptc_p_t_gear_maintain_up_sft      = 1; %time in sec where a gear is maintained during upshifting
ptc_p_t_gear_maintain_dwn_sft     = 1; %time in sec where a gear is maintained during downshifting
ptc_p_tx_in_inertia               = eng_inertia;

ptc_p_t_cpl_start_index 	      = [0;0.4;2];%for manual and CVT tx
ptc_p_pwm_cpl_start_map 	      = [0;0.5;1];%for manual and CVT tx
ptc_p_t_cpl_stop_only_index       = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_stop_only_map       = [1;1;0;0];%for manual and CVT tx
ptc_p_t_cpl_shift_index 	      = [0;0.1;0.35;0.45;0.7;0.8]; %only for manual tx
ptc_p_pwm_cpl_shift_map 		  = [1;1;0;0;1;1];%only for manual tx
ptc_p_t_cpl_eng_engage_index 	  = [0;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_engage_map 	  = [0;1;1];%for manual and CVT tx
ptc_p_t_cpl_eng_disengage_index   = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_disengage_map   = [1;1;0;0];%for manual and CVT tx

if strcmp(model.drivetrain.trans,'ct'),%need to define here as no sft files for ct - AYR
    [spd_index, trq_index]=find(max(max(eng_eff_hot_map))==eng_eff_hot_map);
    sft_spd_op_max = min((eng_spd_fuel_hot_index(spd_index) + 100),(max(eng_spd_max_hot_index)));
end

ptc_p_tx_in_inertia = eng_inertia + mc_inertia;
ptc_p_wh_trq_brake_max = 2000;

% Compute maximum tractive torque available at wheel
% Used to go from drv trq dmd to -1->1 pedal dmd (accel or brake)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1/wh_radius;% 10% more
if strcmp(model.drivetrain.pos1,'Pre-transmission') | strcmp(model.drivetrain.pos1,'Starter_motor_alternator'), % upstream coupled   
    ptc_wh_trq_max = min (ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
else												 % coupled downstream
    ptc_wh_trq_max = min ( ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*max(mc_trq_max_map) );
end  