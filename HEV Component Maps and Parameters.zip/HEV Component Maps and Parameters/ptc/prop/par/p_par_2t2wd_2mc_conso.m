%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: p_par_2t2wd_2mc_conso.m				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
%                         parallel hybrid power controller model	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			:  A. Rousseau - ANL - 09/12/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:                        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%BEGIN_STRATEGY_DESCRIPTION
%END_STRATEGY_DESCRIPTION

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_p_t_eng_dmd_min_p    			= 2;    %DESCRIPTION: (sec) min time fc is on
ptc_p_eng_on_soc_p   				= 0.54; %DESCRIPTION: (0->1) keeps engine on during idling when below value
ptc_p_fc_off_soc_p   				= 0.6;  %DESCRIPTION: (0->1) engine off during idling when above value
ptc_p_mc_ch_on_soc_p   			    = 0.6;  %DESCRIPTION: (0->1) allows mc charging (by road or fc) when SOC below
ptc_p_mc_dis_on_soc_p   			= 0.65; %DESCRIPTION: (0->1) allows mc assist when SOC above value
ptc_p_mc_soc_regen_off_p 			= 0.97; %DESCRIPTION: (0->1) no regen allowed when SOC above value
ptc_p_mc_spd_regen_brake_off_p      = 300 *c_rpm_radps ;%DESCRIPTION: (rd/s) mc spd below which no regen is allowed
ptc_p_mc_trq_brake_frac_max_p 	    = 0.65; %DESCRIPTION: (0->1) Fraction of max mot brk mot can supply  
ptc_p_mc_alone_thresh 			    = 10;	%DESCRIPTION: (Nm) difference of Torque (demand-mot max) to see if we have to start the engine
ptc_p_veh_spd_regen_brake_off_p	    = 1;	%DESCRIPTION: (m/s) veh spd below which no regen is allowed
ptc_p_wh_trq_brake_frac_p 		    = 0;    %DESCRIPTION: (0->1) Fraction of brk srv brk must supply
ptc_p_heat_stop_start_p		        = .80;	%DESCRIPTION: (0->1) fc heat index to allow stop start
ptc_p_heat_emis_p				    = .40;	%DESCRIPTION: (0->1) fc heat index to using motor assist to reduce cold start emissions
ptc_p_spd_start_stop_p		        = 3;	%DESCRIPTION: (m/s) veh speed below which stop start is allowed
ptc_p_soc_assist_p			        = .60;	%DESCRIPTION: (0->1) soc above which use mc2 assist
ptc_p_soc_charge_p			        = .70;	%DESCRIPTION: (0->1) soc below which charge the battery
ptc_p_mc2_trq_brake_frac_max_p      = 0.65; %DESCRIPTION: (0->1) Fraction of max mot brk mot can supply
ptc_p_mc2_soc_regen_off_p		    = 0.97; %DESCRIPTION: (rd/s) mc2 spd below which no regen is allowed  
ptc_p_mc2_alone_thresh 		        = 10;   %DESCRIPTION: (Nm) difference of Torque (demand-mot2 max) to see if we have to start the engine
ptc_p_mc2_spd_regen_brake_off       = 30;   %DESCRIPTION: (rd/s) mc spd below which no regen is allowed
ptc_p_eng_t_on_min_p                = 5;    %DESCRIPTION: Minimum time for the engine to be on
ptc_p_eng_off_soc_p                 = 0.8; %DESCRIPTION: SOC at which the engine is shut off
ptc_p_eng_on_soc_p                  = 0.5;  %DESCRIPTION: SOC at which the engine is turned back on
ptc_p_ess_soc_goal                  = 0.7;  %DESCRIPTION: (0->1)SOC control variable: SOC charge map center point
ptc_p_ess_soc_chg_lim               = 0.45; %DESCRIPTION: (0->1)SOC charge map: SOC at which maximum charging power of the battery is used.
ptc_p_ess_soc_dis_lim               = 0.8;  %DESCRIPTION: (0->1)SOC charge map: SOC at which maxmimum discharging power of the battery is used.
ptc_p_rate_ess_chg                  = 0.5;  %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_chg_lim
ptc_p_rate_ess_dis                  = 0.5;  %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_dis_lim
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute maximum tractive torque available at wheel
% Used to go from drv trq dmd to -1->1 pedal dmd (accel or brake)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1/wh_radius;% 10% more
if strcmp(model.drivetrain.pos1,'Pre-transmission') | strcmp(model.drivetrain.pos1,'Starter_motor_alternator'), % upstream coupled   
    ptc_wh_trq_max = min (ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
else												 % coupled downstream
    ptc_wh_trq_max = min ( ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*max(mc_trq_max_map) );
end  