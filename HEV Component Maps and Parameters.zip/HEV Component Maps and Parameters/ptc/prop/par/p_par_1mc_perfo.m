%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: p_par_1mc_perfo.m									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% parallel hybrid power controller model							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			:  A. Rousseau - ANL - 09/12/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: C. Kwon - ANL - 05/30/00                  %
%(1)ptc_p_gear min = 0 for man, 1 for auto                            %
%(2)fast acceleration strategy added                                %
% Xi Wei -8/18/00 add the maximum torque at the wheels calculation	%
% A. Rousseau (ANL) - 04/26/00 - parameterization of the clutch		%
% characteristics for shifting, clutch and declutch only			%
% A. Rousseau (ANL) - 09/26/01 - rewrote the file to incorporate    %
% Insight and new defualt control for POS1 + differentiation of     %
% parameters for each control strategy                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%fs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('huh')

% Compute maximum tractive torque available at wheel
% Used to go from drv trq dmd to -1->1 pedal dmd (accel or brake)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1/wh_radius;% 10% more
if strcmp(model.drivetrain.pos1,'Pre-transmission') | strcmp(model.drivetrain.pos1,'Starter_motor_alternator'), % upstream coupled   
    ptc_wh_trq_max = min (ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
else												 % coupled downstream
    ptc_wh_trq_max = min ( ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*max(mc_trq_max_map) );
end  

