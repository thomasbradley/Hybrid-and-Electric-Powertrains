%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: p_par_1mc_conso_start_alter.m				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
%                         parallel hybrid power controller model    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			:  A. Rousseau - ANL - 09/12/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
disp('p_par_1mc_conso_start_alter')

%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION

%BEGIN_STRATEGY_PARAMETERSptc_p_eng_t_on_min_p            = 10;       %DESCRIPTION:<PROTECTEDDEFAULT><RANGE BETWEEN([0 5])>(sec) min time eng is on
ptc_p_eng_t_off_min             = 2; 
ptc_p_eng_on_soc_p              = 0.17;     %DESCRIPTION:<RANGE BETWEEN([0 1])>(0->1) keeps engine on during idling when below value
ptc_p_eng_off_soc_p             = 0.19;     %DESCRIPTION:<RANGE BETWEEN([0 1])> (0->1) engine off during idling when above value
ptc_p_mc_ch_on_soc_p            = 0.5;      %DESCRIPTION:<RANGE BETWEEN([0 1])> 0->1) allows mc charging (by road or eng) when SOC below
ptc_p_mc_dis_on_soc_p           = 0.6;      %DESCRIPTION:<RANGE BETWEEN([0 1])> (0->1) allows mc assist when SOC above value
ptc_p_mc_soc_regen_off_p        = 0.99999;  %DESCRIPTION:<RANGE BETWEEN([0 1])>(0->1) no regen allowed when SOC above value
ptc_p_mc_spd_regen_brake_off_p  = 31;       %DESCRIPTION:<RANGE EQUAL(0) OR EQUAL(1) OR BETWEEN([99 100])>(rd/s) mc spd below which no regen is allowed
ptc_p_veh_spd_regen_brake_off_p = 1;        %DESCRIPTION:(m/s) veh spd below which no regen is allowed
ptc_p_mc_trq_brake_frac_max_p   = 0.65;     %DESCRIPTION:
ptc_p_wh_trq_brake_frac_p       = 0.5;      %DESCRIPTION:
ptc_p_ess_soc_goal              = 0.65;     %DESCRIPTION: (0->1)SOC control variable: SOC charge map center point
ptc_p_ess_soc_chg_lim           = 0.45;     %DESCRIPTION: (0->1)SOC charge map: SOC at which maximum charging power of the battery is used.
ptc_p_ess_soc_dis_lim           = 0.8;      %DESCRIPTION: (0->1)SOC charge map: SOC at which maxmimum discharging power of the battery is used.
ptc_p_rate_ess_chg              = 0.5;      %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_chg_lim
ptc_p_rate_ess_dis              = 0.5;      %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_dis_lim

ptc_p_key_on_pulse_width        = -1;       %DESCRIPTION: (sec) set to -1 to remove key on engine pull up (THB)
ptc_em_idle_enable              = 1;        %DESCRIPTION: (1) make the em idle to run the trans pump etc.  (THB)  

ptc_p_fc_on_spd_low             = 15;       %DESCRIPTION: (m/s) Vehicle Speed at which engine turns off (THB)
ptc_p_fc_on_spd_high            = 16;       %DESCRIPTION: (m/s) Vehicle Speed at which engine turns on (THB)

ptc_p_fc_on_spd_soc             = [0 .19 .195 1];
ptc_p_fc_on_spd_line            = [ 5 10 20 20 ]/2;

ptc_p_battery_temp_disable      = 1;        %DESCRIPTION: (0->1) Disable Battery Temp Calc and Control (THB)
ptc_p_engine_off_ess_temp_high  = 30;       %DESCRIPTION: (degC) When engine is off, turn engine on at this temp (THB)
ptc_p_engine_off_ess_temp_low   = 29;       %DESCRIPTION: (degC) When engine is off, turn engine off at this temp  (THB)
ptc_p_total_power_request_high  = 30e3;     %DESCRIPTION: (W) Total 1sec averaged vehicle power that demands ICE pull up (THB)
ptc_p_total_power_request_low   = 26e3;     %DESCRIPTION: (W) Total 1sec averaged vehicle power that demands ICE pull down (THB)
ptc_p_accel_percent_engine_on   = .45;      %DESCRIPTION: (1) Accel pedal fraction that demands ICE pull up (THB)
ptc_p_ess_pwr_max_frac          = .71;      %DESCRIPTION: (1) Battery MaxPwr fraction that demands ICE pull up (THB)
ptc_p_force_ev                  = 0;%;      %DESCRIPTION: (1) EV Force switch (THB)
ptc_p_optimal_control           = 0;        %DESCRIPTION: (1) optimal engine torque scheduling flag (THB)
ptc_p_enforce_volt_lid          = 420;
ptc_p_enforce_volt_floor        = 220;
ptc_torque_converter_idle_pwr   = 700;      %DESCRIPTION: (W) Power Consumed by transmission input pump, W (THB)
ptc_tx_trq_max                  = 385;      % (Nm) Maximum torque output of the powertrain 

ptc_epu_off_oft                 = 1;        %DESCRIPTION: (1) EV Force switch (THB)
ptc_epu_on_oft                  = 1;        %DESCRIPTION: (1) EV Force switch (THB)
ptc_epu_min_oft                 = 1;        %DESCRIPTION: (1) EV Force switch (THB)

ptc_ch_on_soc                   = 1;        %DESCRIPTION: (1) EV Force switch (THB)
ptc_ch_min_soc                  = 1;        %DESCRIPTION: (1) EV Force switch (THB)
ptc_ch_off_soc                  = 1;        %DESCRIPTION: (1) EV Force switch (THB)
ptc_coolant_eng_pull_up_high    = .8;       %DESCRIPTION: (1) EV Force switch (THB)
ptc_coolant_eng_pull_up_low     = .78;      %DESCRIPTION: (1) EV Force switch (THB)
ptc_turtle_k                    = 300;      %DESCRIPTION: (-) Proportional Control Constant for Turtle Light Mode (THB)
ptc_turtle_int                  = 1000;     %DESCRIPTION: (-) Integral Control Constant for Turtle Light Mode (THB)
ptc_turtle_d                    = 10;       %DESCRIPTION: (-) Derivative Control Constant for Turtle Light Mode (THB)
ptc_ess_soc_index               = [.15 .18 .2 .21 .211 .75 1.00];     %DESCRIPTION: (-) Index of SOC for ess power demand  (THB)
ptc_ess_pwr_map                 = -[-10 -10 -5 10 10 10 10 ]*1000;         %DESCRIPTION: (W) ess power demand  (THB)
ptc_ess_soc_turtle_light_off    = .18;      %DESCRIPTION: (-)  SOC at which Turtle Light turns off (THB)
ptc_ess_soc_turtle_light_on     = .15;      %DESCRIPTION: (-) SOC at which Turtle Light turns on (THB)
ptc_ess_soc_ipd_on              = ptc_ess_soc_turtle_light_off;
ptc_ess_soc_ipd_off             = .2;
ptc_upshift_delay               = .10;      %DESCRIPTION: (s) time between shift dmd and cmd only for hard limit shift strat. (THB)
ptc_downshift_delay             = .10;      %DESCRIPTION: (s) time between shift dmd and cmd only for hard limit shift strat. (THB)

ptc_cs_on                       = .2;       %DESCRIPTION: (-) state of charge at which charge sustain algorithm begins for optimal control(THB)
ptc_cs_off                      = .21;      %DESCRIPTION: (-) state of charge at which charge sustain algorithm ends for optimal control(THB)



%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Modified by THB 5/28/03 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%ptc_eng_opt_rpm                 = [800	1000	1200	1400	1600	1800	2000	2200	2400	2600	2800	3000	3200	3400	3600	3800	4000]*2*pi/60;
%ptc_eng_on_opt_dmd              = [1e6 1e6 1e6 1e6 45 40 40 35 40 40 40 40 40 40 45 45 45 45 50 50 50 50 55 55 55 55 55 60 60 60 65];

ptc_eng_opt_TrqDes_on_off       = [-240:5:510];

ptc_eng_opt_rpm                 = [800:50:6400] * 2*pi/60;
                        
optimal_control_data_highres_ol
optimal_control_data_highres_ne               % loads up the data for optimal control
ptc_eng_opt_TrqDes              = [-240:5:510];

%ptc_eng_opt_TrqDes              = [-240:20:510];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% END Modified by THB 5/28/03 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ptc_p_tx_trq_blend_sft          = 0.5;
tx_t_shift                      = 0.2;%for automatic tx
ptc_p_t_gear_maintain_up_sft    = 1; %time in sec where a gear is maintained during upshifting
ptc_p_t_gear_maintain_dwn_sft   = 1; %time in sec where a gear is maintained during downshifting
ptc_p_tx_in_inertia             = eng_inertia;

ptc_p_t_cpl_start_index 	    = [0;0.4;2];%for manual and CVT tx
ptc_p_pwm_cpl_start_map 	    = [0;0.5;1];%for manual and CVT tx
ptc_p_t_cpl_stop_only_index     = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_stop_only_map     = [1;1;0;0];%for manual and CVT tx
ptc_p_t_cpl_shift_index         = [0;0.1;0.35;0.45;0.7;0.8]; %only for manual fstx
ptc_p_pwm_cpl_shift_map         = [1;1;0;0;1;1];%only for manual tx
ptc_p_t_cpl_eng_engage_index    = [0;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_engage_map 	= [0;1;1];%for manual and CVT tx
ptc_p_t_cpl_eng_disengage_index = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_disengage_map = [1;1;0;0];%for manual and CVT tx

ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1/wh_radius;% 10% more
if strcmp(model.drivetrain.pos1,'Pre-transmission') | strcmp(model.drivetrain.pos1,'Starter_motor_alternator'), % upstream coupled   
    ptc_wh_trq_max = min (ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
else												 % coupled downstream
    ptc_wh_trq_max = min ( ptc_wh_trq_slip, ...
        ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*max(mc_trq_max_map) );
end 
