%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION

%BEGIN_STRATEGY_PARAMETERS
ptc_p_spd_min_eng_off				= 200*c_rpm_radps;  %DESCRIPTION: (rd/s) minimum speed to have engine off with a gear engaged
ptc_p_eng_t_on_min_p    			= 10;               %DESCRIPTION: (sec) min time eng is on
ptc_p_mc_trq_brake_frac_max_p 	= 0.65;                 %DESCRIPTION: (0->1) Fraction of max mot brk mot can supply  
ptc_p_wh_trq_brake_frac_p 		= 0;                    %DESCRIPTION: (0->1) Fraction of brk srv brk must supply
ptc_p_eng_off_soc                  = 0.8;               %DESCRIPTION: SOC below which charging is allowed
ptc_p_t_eng_dmd_min               = 2;                  %DESCRIPTION:
ptc_p_mc_lim_on_soc   			= ess_soc_min + 0.1;    %DESCRIPTION: ESS net SOC to limit motor
ptc_p_mc_lim_off_soc   			= ess_soc_min + 0.05;   %DESCRIPTION: ESS net SOC to limit motor
ptc_p_soc_low_mode                = 0.58;               %DESCRIPTION: SOC below which we are in "Low SOC mode"
ptc_p_soc_very_low_mode           = 0.35;               %DESCRIPTION: SOC below which we are in "Very low SOC mode"
ptc_p_ess_soc_eng_on_p				= 0.2;              %DESCRIPTION: (0->1) SOC below which the engine is kept on during idling
ptc_p_soc_no_regen                = 0.75;               %DESCRIPTION: (0->1) SOC above which we are in normal mode, discharging
ptc_p_mc_soc_regen_off_p 			= 0.97;             %DESCRIPTION: (rd/s) mc spd below which no regen is allowed
ptc_p_veh_spd_regen_brake_off_p	= 1;		            %DESCRIPTION: (m/s) veh spd below which no regen is allowed
ptc_p_mc_spd_regen_brake_off      = 300 *c_rpm_radps;   %DESCRIPTION: (rd/s) mc spd below which no regen is allowed
%END_STRATEGY_PARAMETERS

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ptc_p_eng_trq_ass_index            = [0 10 35 100];
ptc_p_mc_trq_ass_map              = [0 0 5 9];        % (Nm) motor trq dmd in regen and normal modes when discharging
ptc_p_ess_abs_soc_index           = [0  0.35  0.58  1];
ptc_p_eng_trq_ch_index             = [0  50  70  100];
ptc_p_mc_trq_regen_map            = [ 20   20	    0	0;...% (Nm) motor trq dmd in regen mode when charging
        20	 20	    0	0;...
        10	 10		0	0;...
        0	 0		0	0];
ptc_p_eng_trq_min_ass_index        = [0 10 80 100];
ptc_p_accel_assist_index          = [0 5 75 100];
ptc_p_assist_map                  = [ 0	0	0	0;...% (0/1) determine in the normal mode if we are charging(0) or discharging(1)
        0	0	1	1;...
        0	1	1	1;...
        0	1	1	1];
ptc_p_trq_end_assist_index        = [0 30 45 60 65 75 90 100];
ptc_p_decel_assist_index          = [-150 -90 -55 -40 -15 0 10];
ptc_p_end_assist_map              = [ 1	1	1	1	1	1	0;...% (0/1) determine in the normal mode when we are done discharging (1)
        1	1	1	1	1	1	0;...
        1	1	1	1	1	0	0;...
        1	1	1	1	0	0	0;...
        1	1	1	0	0	0	0;...
        1	1	0	0	0	0	0;...
        1	0	0	0	0	0	0;...
        0	0	0	0	0	0	0];
ptc_p_eng_trq_min_ass_regen_index  = [0 90 100];
ptc_p_accel_assist_regen_index    = [0 50 100];
ptc_p_assist_regen_map            = [ 0	0	0;...   % (0/1) determine in the regen mode if we are charging(0) or discharging(1)
        0	1	1;...
        0	1	1];
ptc_p_trq_end_assist_regen_index  = [0 30 45 60 65 90 100];
ptc_p_decel_assist_regen_index    = [-90 -53 -40 -15 0 10];
ptc_p_end_assist_regen_map        = [ 1	1	1	1	1	0;...% (0/1) determine in the regen mode when we are done discharging (1)
        1	1	1	1	1	0;...
        1	1	1	1	0	0;...
        1	1	1	0	0	0;...
        1	1	0	0	0	0;...
        1	0	0	0	0	0;...
        0	0	0	0	0	0];

ptc_wh_trq_max = min (ptc_wh_trq_slip,ptc_eng_ratio_cum*(ptc_tx_ratio_map_max - ptc_tx_ratio_map_min)*max(eng_trq_max_hot_map) + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map));
