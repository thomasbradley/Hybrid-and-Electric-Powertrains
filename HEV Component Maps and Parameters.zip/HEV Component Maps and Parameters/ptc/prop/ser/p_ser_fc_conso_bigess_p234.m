%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		:p_ser_fc_conso_bigess_p234.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: initialize the parameters used in the	%
% series hybrid power controller model	with fuel cell				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: A. Rousseau (ANL) 10/01/99			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% Xi Wei -8/18/00 add the maximum torque at the wheels calculation	%
% A. Rousseau (ANL) - 04/26/00 - parameterization of the clutch		%
% characteristics for shifting, clutch and declutch only			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_p_fc_t_on_min_p    		    = 5;        			%DESCRIPTION: fcv minimum on time  (sec)
ptc_p_fc_t_off_min_p   		    = 5;        			%DESCRIPTION: fcv minimum off time (sec)
ptc_p_fc_on_soc_p   			= 0.5;        			%DESCRIPTION: ESS net SOC to turn fcv on  (thermostat)
ptc_p_fc_off_soc_p   			= 0.7;        		    %DESCRIPTION: ESS net SOC to turn fcv off (thermostat)
ptc_p_mc_lim_on_soc   			= 0.35;        	        %DESCRIPTION: ESS net SOC to limit motor
ptc_p_mc_lim_off_soc   			= 0.3;        	        %DESCRIPTION: ESS net SOC to limit motor
ptc_p_t_mc_dmd_min              = 1;                    %DESCRIPTION:
ptc_p_t_fc_dmd_min              = 2;                    %DESCRIPTION:
ptc_p_fc_spd_opt_p 				= 0; 					%DESCRIPTION: User selected optimal APU speed; gui_ptc is in rpm
ptc_p_fc_on_init                = 1;                    %DESCRIPTION:
ptc_p_mc_soc_regen_off_p 		= 0.97;                 %DESCRIPTION:
ptc_p_mc_trq_brake_frac_max_p   = 0.5;        			%DESCRIPTION: Fraction of max mot brk mot can supply
ptc_p_mc_spd_regen_brake_off    = c_rpm_radps*pi/30 * 300; %DESCRIPTION: arbitrarily set to 300 rpm
ptc_p_wh_4rd                    = 3;
ptc_p_wh_trq_brake_frac_p		= 0.2;        			%DESCRIPTION: Fraction of brk srv brk must supply
ptc_p_veh_spd_regen_brake_off   = 1;                    %DESCRIPTION: Vehicle speed below which regenerative braking should be disabled
ptc_p_tx_acc_bklash_thresh 	    = 0.05; 	            %DESCRIPTION: Backlash used in "Shift control" (for MGB and CVT)
ptc_p_ess_soc_goal              = 0.7;                  %DESCRIPTION: (0->1)SOC control variable: SOC charge map center point
ptc_p_ess_soc_chg_lim           = 0.45;                 %DESCRIPTION: (0->1)SOC charge map: SOC at which maximum charging power of the battery is used.
ptc_p_ess_soc_dis_lim           = 0.8;                  %DESCRIPTION: (0->1)SOC charge map: SOC at which maxmimum discharging power of the battery is used.
ptc_p_rate_ess_chg              = 0.5;                  %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_chg_lim
ptc_p_rate_ess_dis              = 0.5;                  %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_dis_lim
% start thb
ptc_p_enforce_volt_lid          = 420;
ptc_p_enforce_volt_floor        = 0.7638 * ess_num_cell;
% start thb
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ptc_p_fc_pwr_max 				= fc_pwr_max; 			% Max APU power rating, W
ptc_p_fc_pwr_opt_p 				= fc_pwr_opt ; 		    % User selected optimal APU power, W
ptc_p_spd_max_goal              = 100 * mph2mps / wh_radius; % rad/sec

% Motor speed below which the following power is used for road demand calculation
ptc_mc_pwr_max_4rd_map = max(mc_spd_max_index)/20 *interp1(mc_spd_max_index, mc_trq_max_map, max(mc_spd_max_index)/20);
ptc_mc_pwr_cont_4rd_map = max(mc_spd_max_index)/20 * interp1(mc_spd_cont_index, mc_trq_cont_map, max(mc_spd_max_index)/20);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I - Parameters used by all control strategies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parameters used to characterize the shifting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_tx_trq_blend_sft            = 0.5;
tx_t_shift                      = 0.5;%for automatic tx
ptc_t_gear_maintain_up_sft		= 1; %time in sec where a gear is maintained during upshifting
ptc_t_gear_maintain_dwn_sft     = 1; %time in sec where a gear is maintained during downshifting

ptc_t_cpl_start_index 	        = [0;0.4;2];%for manual and CVT tx
ptc_pwm_cpl_start_map 	        = [0;0.5;1];%for manual and CVT tx
ptc_t_cpl_stop_only_index       = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_pwm_cpl_stop_only_map       = [1;1;0;0];%for manual and CVT tx
ptc_t_cpl_shift_index 			= [0;0.1;0.35;0.45;0.7;0.8]; %only for manual tx
ptc_pwm_cpl_shift_map 			= [1;1;0;0;1;1];%only for manual tx
ptc_t_cpl_eng_engage_index 	    = [0;0.35;0.45];%for manual and CVT tx
ptc_pwm_cpl_eng_engage_map 	    = [0;1;1];%for manual and CVT tx
ptc_t_cpl_eng_disengage_index   = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_pwm_cpl_eng_disengage_map   = [1;1;0;0];%for manual and CVT tx

% Compute maximum tractive torque available at wheel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ~strcmp(model.drivetrain.fd.init,'')
    ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1/wh_radius; % 10% more
    ptc_wh_trq_max = min (ptc_wh_trq_slip, ptc_mc_ratio_cum*max(mc_trq_max_map) );
    ptc_wh_comb_xbq = min ( ptc_wh_trq_slip, wh_trq_brake_max + ptc_mc_ratio_cum*max(mc_trq_max_map) );
    ptc_percent_front_brake = 0.7;%used for 4WD configurations
end