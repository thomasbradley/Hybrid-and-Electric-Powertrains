%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ptc_p_ser_fc.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: initialize the parameters used in the	%
% series hybrid power controller model	with fuel cell				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: A. Rousseau (ANL) 10/01/99			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% Xi Wei -8/18/00 add the maximum torque at the wheels calculation	%
% A. Rousseau (ANL) - 04/26/00 - parameterization of the clutch		%
% characteristics for shifting, clutch and declutch only			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_p_fc_on_soc_p   			    = 0.5;        			% ESS net SOC to turn fcv on  (thermostat)
ptc_p_fc_off_soc_p   			    = 0.7;        		    % ESS net SOC to turn fcv off (thermostat)
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I - Parameters used by all control strategies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% parameters used to characterize the shifting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_p_tx_trq_blend_sft            = 0.5;
tx_t_shift                      = 0.5;%for automatic tx
ptc_p_t_gear_maintain_up_sft		= 1; %time in sec where a gear is maintained during upshifting
ptc_p_t_gear_maintain_dwn_sft     = 1; %time in sec where a gear is maintained during downshifting

ptc_p_t_cpl_start_index 	        = [0;0.4;2];%for manual and CVT tx
ptc_p_pwm_cpl_start_map 	        = [0;0.5;1];%for manual and CVT tx
ptc_p_t_cpl_stop_only_index       = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_stop_only_map       = [1;1;0;0];%for manual and CVT tx
ptc_p_t_cpl_shift_index 			= [0;0.1;0.35;0.45;0.7;0.8]; %only for manual tx
ptc_p_pwm_cpl_shift_map 			= [1;1;0;0;1;1];%only for manual tx
ptc_p_t_cpl_eng_engage_index 	    = [0;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_engage_map 	    = [0;1;1];%for manual and CVT tx
ptc_p_t_cpl_eng_disengage_index   = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_disengage_map   = [1;1;0;0];%for manual and CVT tx

% Compute maximum tractive torque available at wheel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1*wh_radius; % 10% more
ptc_wh_trq_max = min (ptc_wh_trq_slip,ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
ptc_wh_comb_xbq = min ( ptc_wh_trq_slip,wh_trq_brake_max + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );

ptc_p_percent_front_brake = 0.7;%used for 4WD configurations
