%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		:p_ser_eng_conso_bigess_p1.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% series hybrid power controller model								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) 10/01/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% Xi Wei -8/18/00 add the maximum torque at the wheels calculation	%
% A. Rousseau (ANL) - 04/26/00 - parameterization of the clutch		%
% characteristics for shifting, clutch and declutch only			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_p_gc_kp                     = 2;        %DESCRIPTION:
ptc_p_gc_ki                     = 5;        %DESCRIPTION:
ptc_p_eng_t_on_min              = 5;        %DESCRIPTION: Minimum time to let the engine ON
ptc_p_eng_on_soc_p   			= 0.5;      %DESCRIPTION: ESS net SOC to turn eng on  (thermostat)
ptc_p_eng_off_soc_p   			= 0.55;     %DESCRIPTION: ESS net SOC to turn eng off (thermostat)
ptc_p_reg_on_soc   				= 0.75;     %DESCRIPTION: ESS net SOC to allow regen
ptc_p_reg_off_soc   			= 0.8;      %DESCRIPTION: ESS net SOC to allow regen
ptc_p_t_mc_dmd_min              = 1;        %DESCRIPTION:
ptc_p_t_gc_dmd_min              = 2;        %DESCRIPTION:
ptc_p_t_mode_min                = 0.5;      %DESCRIPTION:
ptc_p_mc_spd_regen_brake_off_p 	= pi/30 * 300;    %DESCRIPTION: Motor speed below which regenerative braking should be disabled
ptc_p_mc_soc_regen_off_p 		= 0.97;     %DESCRIPTION:
ptc_p_wh_trq_brake_frac_p		= 0;        %DESCRIPTION: Fraction of brk srv brk must supply
ptc_p_veh_spd_regen_brake_off_p = 1;        %DESCRIPTION: Vehicle speed (m/s) below which regenerative braking should be disabled
ptc_p_tx_acc_bklash_thresh 		= 0.05; 	%DESCRIPTION: Backlash used in "Shift control" (for MGB and CVT)
ptc_p_ess_alone_thresh          = 10;       %DESCRIPTION:
ptc_p_soc_max_at_zero_v_p       = 1; 	    %DESCRIPTION:
ptc_p_ess_soc_goal              = 0.7;      %DESCRIPTION: (0->1)SOC control variable: SOC charge map center point
ptc_p_ess_soc_chg_lim           = 0.45;     %DESCRIPTION: (0->1)SOC charge map: SOC at which maximum charging power of the battery is used.
ptc_p_ess_soc_dis_lim           = 0.8;      %DESCRIPTION: (0->1)SOC charge map: SOC at which maxmimum discharging power of the battery is used.
ptc_p_rate_ess_chg              = 0.5;      %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_chg_lim
ptc_p_rate_ess_dis              = 0.5;      %DESCRIPTION: percentage of the battery power to be charged when SOC =  ptc_p_ess_soc_dis_lim
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% I - Parameters used by all control strategies
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ptc_p_mc_lim_on_soc   				= ess_soc_min + 0.1;        	% ESS net SOC to limit motor
ptc_p_mc_lim_off_soc   				= ess_soc_min + 0.05;        	% ESS net SOC to limit motor
ptc_p_gc_pro_kp                     = 50 * (eng_inertia + gc_inertia); % Proportional gain for engine speed control while propelling
ptc_p_gc_pro_ki                     = 5 * (eng_inertia + gc_inertia);  % Integrator gain for engine speed control while propelling
ptc_p_gc_brk_kp                     = 10 * (eng_inertia + gc_inertia); % Proportional gain for engine speed control while braking
ptc_p_gc_brk_ki                     = 1 * (eng_inertia + gc_inertia);  % Integrator gain for engine speed control while braking
ptc_p_percent_front_brake         = 0.7;%used for 4WD configurations

% parameters used to characterize the shifting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_p_tx_trq_blend_sft            = 0.5;
tx_t_shift                        = 0.5;%for automatic tx
ptc_p_t_gear_maintain_up_sft      = 1; %time in sec where a gear is maintained during upshifting
ptc_p_t_gear_maintain_dwn_sft     = 1; %time in sec where a gear is maintained during downshifting
ptc_p_tx_in_inertia               = eng_inertia;

ptc_p_t_cpl_start_index 	      = [0;0.4;2];%for manual and CVT tx
ptc_p_pwm_cpl_start_map 	      = [0;0.5;1];%for manual and CVT tx
ptc_p_t_cpl_stop_only_index       = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_stop_only_map       = [1;1;0;0];%for manual and CVT tx
ptc_p_t_cpl_shift_index           = [0;0.1;0.35;0.45;0.7;0.8]; %only for manual tx
ptc_p_pwm_cpl_shift_map           = [1;1;0;0;1;1];%only for manual tx
ptc_p_t_cpl_eng_engage_index 	  = [0;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_engage_map 	  = [0;1;1];%for manual and CVT tx
ptc_p_t_cpl_eng_disengage_index   = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_p_pwm_cpl_eng_disengage_map   = [1;1;0;0];%for manual and CVT tx

% Compute maximum tractive torque available at wheel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1*wh_radius; % 10% more
ptc_wh_trq_max = min (ptc_wh_trq_slip,ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
ptc_wh_comb_xbq = min ( ptc_wh_trq_slip,wh_trq_brake_max + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );

