% Name of the file 		: p_elec_conso_tx.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: initialize the parameters used in the	%
% series hybrid power controller model	with fuel cell				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: A. Rousseau (ANL) 10/01/99			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
%		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_p_tx_trq_blend_sft            = 0.5;%DESCRIPTION:
ptc_p_tx_t_shift                      = 0.5;%DESCRIPTION:%for automatic tx
ptc_p_t_gear_maintain_up_sft		= 1; %DESCRIPTION:%time in sec where a gear is maintained during upshifting
ptc_p_t_gear_maintain_dwn_sft     = 1; %DESCRIPTION:%time in sec where a gear is maintained during downshifting
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Compute maximum tractive torque available at wheel
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ptc_wh_trq_slip = 0.85*veh_ratio_weight_front*veh_mass*9.81*1.1/wh_radius; % 10% more
if strcmp(model.drivetrain.pos1,'With transmission'),						 % coupled upstream
   ptc_wh_trq_max = min (ptc_wh_trq_slip,ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
   ptc_wh_comb_xbq = min ( ptc_wh_trq_slip,wh_trq_brake_max + ptc_mc_ratio_cum*ptc_tx_ratio_map_max*max(mc_trq_max_map) );
else												 % coupled downstream
   ptc_wh_trq_max = min (ptc_wh_trq_slip, ptc_mc_ratio_cum*max(mc_trq_max_map) );
   ptc_wh_comb_xbq = min ( ptc_wh_trq_slip, wh_trq_brake_max + ptc_mc_ratio_cum*max(mc_trq_max_map) );
end  


