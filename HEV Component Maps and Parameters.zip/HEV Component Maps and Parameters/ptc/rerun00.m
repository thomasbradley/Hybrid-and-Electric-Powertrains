% rerun00.m PSAT V5.1  input file created: 16-Jan-2003 11:09:04

% simulate a Parallel Hybrid vehicle
%

[info]=what('root/run');
if isempty(info),
	fprintf(1,'You forgot to set the path by typing ''set_path'' under the directory psat/root \n');
	return
end

global model

save_mode = 0;
model.drivetrain.select_to_workspace = 'off';
model.prototyping = 0;
rerun_file = 'rerun.m';
model.drivetrain.name = 'par_2wd_p2_dm';
model.sim.compil = 'off';


% Load the Components
model.drivetrain.drv.ver = '1';
model.drivetrain.drv.init = 'drv_normal_1000_05';
model.drivetrain.drv.scale = '';
model.drivetrain.drv.calc = {''};
model.drivetrain.drv.prev_ver = '1';
model.drivetrain.drv.prev_init = 'drv_cool_200_5';

model.drivetrain.str.ver = '1';
model.drivetrain.str.init = 'str_10_10';
model.drivetrain.str.scale = '';
model.drivetrain.str.calc = {''};

model.drivetrain.eng.ver = '1';
model.drivetrain.eng.type = 'si';
model.drivetrain.eng.init = 'eng_si_1800_99_HOT';
model.drivetrain.eng.scale = '';
model.drivetrain.eng.calc = {'eng_calculation'};
model.drivetrain.eng.prev_ver = '1';
model.drivetrain.eng.prev_init = 'eng_si_10000_224_HOT';
model.drivetrain.eng.prev_type = 'si';

model.drivetrain.accmech.ver = '1';
model.drivetrain.accmech.init = 'accmech_0';
model.drivetrain.accmech.scale = '';
model.drivetrain.accmech.calc = {''};

model.drivetrain.cpl.ver = '1';
model.drivetrain.cpl.init = 'clutch_1';
model.drivetrain.cpl.scale = '';
model.drivetrain.cpl.calc = {''};

model.drivetrain.ess.ver = '1';
model.drivetrain.ess.type = 'nimh';
model.drivetrain.ess.init = 'ess_nimh_90_300_ovonic';
model.drivetrain.ess.scale = '';
model.drivetrain.ess.calc = {''};
model.drivetrain.ess.prev_ver = '1';
model.drivetrain.ess.prev_init = 'ess_nimh_11_240';
model.drivetrain.ess.prev_type = 'nimh';

model.drivetrain.accelec.ver = '1';
model.drivetrain.accelec.init = 'accelec_500';
model.drivetrain.accelec.scale = '';
model.drivetrain.accelec.calc = {''};
model.drivetrain.accelec.prev_ver = '1';
model.drivetrain.accelec.prev_init = 'accelec_0';

model.drivetrain.mc.ver = '1';
model.drivetrain.mc.type = 'pm';
model.drivetrain.mc.init = 'mc_pm_32_uqm';
model.drivetrain.mc.scale = '';
model.drivetrain.mc.calc = {'mc_calculation'};
model.drivetrain.mc.prev_ver = '1';
model.drivetrain.mc.prev_init = 'mc_pm_08';
model.drivetrain.mc.prev_type = 'pm';

model.drivetrain.tx.ver = '1';
model.drivetrain.tx.init = 'tx_5_dm_37_21_13_09_07_VW_Jetta';
model.drivetrain.tx.scale = '';
model.drivetrain.tx.calc = {''};
model.drivetrain.tx.prev_ver = '1';
model.drivetrain.tx.prev_init = 'tx_2_dm_186_1';

model.drivetrain.fd.ver = '1';
model.drivetrain.fd.init = 'fd_454_intets';
model.drivetrain.fd.scale = '';
model.drivetrain.fd.calc = {''};
model.drivetrain.fd.prev_ver = '1';
model.drivetrain.fd.prev_init = 'fd_31_hil';

model.drivetrain.wh.ver = '1';
model.drivetrain.wh.init = 'wh_035_suv';
model.drivetrain.wh.scale = '';
model.drivetrain.wh.calc = {''};
model.drivetrain.wh.prev_ver = '1';
model.drivetrain.wh.prev_init = 'wh_026_PNGV';

model.drivetrain.veh.ver = '1';
model.drivetrain.veh.init = 'veh_2270_317_036_SUV_ucdavis';
model.drivetrain.veh.scale = '';
model.drivetrain.veh.calc = {''};
model.drivetrain.veh.prev_ver = '1';
model.drivetrain.veh.prev_init = 'veh_1000_20_033_large_car';

model.drivetrain.ex.ver = '1';
model.drivetrain.ex.type = '3c';
model.drivetrain.ex.init = 'ex_3c_1';
model.drivetrain.ex.scale = '';
model.drivetrain.ex.calc = {'ex_calculation'};


%------------------------------
gui_param_file = 'gui_param_models';

%Modified variables
model.drivetrain.variables = {'ess_soc_init',0.9,0.2};
%End Modified variables


%------------------------------
%Strategy
model.strategy.conso.prop.init = 'p_par_pretx_1mc_conso';
model.strategy.conso.prop.model = 'p_par_pretx_1mc_pwr_cmd';
model.strategy.conso.shifting.init = 'tx_shift';
model.strategy.conso.shifting.model = 's_dm_best_eng_curve';
model.strategy.conso.braking.init = 'b_par_pretx_1axle_1mc';
model.strategy.conso.braking.model = 'b_par_pretx_1axle_1mc';
model.strategy.conso.trs.init = {...
	'trs_tx_cpl';...
	'';...
	'';...
	'';...
	''};
model.strategy.conso.trs.model = {...
	'tx','lib_trs_tx_dm_par_p2';...
	'eng','lib_trs_eng_dm';...
	'mc','lib_trs_mc_nostr_sip';...
	'str','lib_trs_str';...
	'wh','lib_trs_wh_2wd'};
%------------------------------
gui_control_file = 'gui_param_control';

%Control variables

%End Control variables

%------------------------------
%Cycle Simulation
model.sim.cycle.run = 'on';
model.sim.cycle.number = 1;
model.sim.cycle.name = 'car_505';
model.sim.cycle.steady = 'off';
model.sim.cycle.steady_spd = 25;
model.sim.cycle.duration = 'off';
model.sim.cycle.duration_time = 200;

model.sim.multi_cycles.run = 'off';
model.sim.trip.run = 'off';
model.sim.test_procedures.run = 'off';
model.sim.road_grade.run = 'off';
model.sim.road_load.run = 'off';
model.sim.acceleration.run = 'off';
model.sim.gradeability.run = 'off';
model.sim.parametric.run = 'off';
model.sim.soc.run = 'off';

%------------------------------
%Simulink Parameters
model.sim.simulink.AbsTol = 'auto';
model.sim.simulink.Debug = 'off';
model.sim.simulink.Decimation = 1;
model.sim.simulink.DstWorkspace = 'current';
model.sim.simulink.FinalStateName = '';
model.sim.simulink.FixedStep = '0.01';
model.sim.simulink.InitialState = [];
model.sim.simulink.InitialStep = 'auto';
model.sim.simulink.MaxOrder = 5;
model.sim.simulink.SaveFormat = 'Matrix';
model.sim.simulink.MaxRows = 0;
model.sim.simulink.MaxStep = 'auto';
model.sim.simulink.OutputPoints = 'all';
model.sim.simulink.OutputVariables = 'ty';
model.sim.simulink.Refine = 1;
model.sim.simulink.RelTol = '0.001';
model.sim.simulink.Solver = 'ode4';
model.sim.simulink.SrcWorkspace = 'base';
model.sim.simulink.Trace = '';
model.sim.simulink.ZeroCross = 'off';
model.sim.simulink.SimStep = 'Fixed';
model.sim.simulink.SolverMode = 'auto';

% Load the debug parameters
debug_psat = 0;
stop_simu_before_end = 0;
show_building = 0;
manual_sim_stop = 0;
create_param_files(rerun_file);

