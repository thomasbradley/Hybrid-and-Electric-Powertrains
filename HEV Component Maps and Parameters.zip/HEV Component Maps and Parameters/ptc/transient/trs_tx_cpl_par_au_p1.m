%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: trs_tx_cpl_par_au_p1.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the shifting law for a 	    %
%                         parallel position 1 vehicle with au       %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: 			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%BEGIN_STRATEGT_DESCRIPTION
%END_STRATEGY_DESCRIPTION
disp('trs_tx_cpl_par_au_p1')
%BEGIN_STRATEGY_PARAMETERS
ptc_trs_tx_cpl_lock_spd_hev     = 8; %DESCRIPTION:Torque Converter locks at 50 miles per hour For Conventional Vehicle
ptc_trs_tx_cpl_lock_spd_ev      = 3;%2.2; %DESCRIPTION:Torque Converter locks at 50 miles per hour For Conventional Vehicle

ptc_trs_tx_cpl_lock_gear_hev    = 3; %DESCRIPTION:Torque Converter locks in 3rd gear For Conventional Vehicle
ptc_trs_tx_cpl_lock_gear_ev     = 1;%1; %DESCRIPTION:Torque Converter locks in 3rd gear For Conventional Vehicle

%%%%%%%%%%%%%%%%%%%%%%%%% Added by THB 9-4-03 %%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%% Added by THB 9-4-03 %%%%%%%%%%%%%%%%%%%%%%%%%

%END_STRATEGY_PARAMETERS


ptc_trs_tx_trq_blend_sft        = 0.2;
tx_t_shift                      = 0.2;%for automatic tx
ptc_t_gear_maintain_up_sft		= 1; %time in sec where a gear is maintained during upshifting
ptc_t_gear_maintain_dwn_sft     = 1; %time in sec where a gear is maintained during downshifting
ptc_tx_in_inertia = eng_inertia;

ptc_t_cpl_start_index 	        = [0;0.4;2];%for manual and CVT tx
ptc_pwm_cpl_start_map 	        = [0;0.5;1];%for manual and CVT tx
ptc_t_cpl_stop_only_index       = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_pwm_cpl_stop_only_map       = [1;1;0;0];%for manual and CVT tx

ptc_t_cpl_shift_index 			= [0;0.1;0.35;0.45;0.7;0.8]; %only for manual tx
ptc_pwm_cpl_shift_map 			= [1;1;0;0;1;1];%only for manual tx

ptc_t_cpl_eng_engage_index 	    = [0;0.35;0.45];%for manual and CVT tx
ptc_pwm_cpl_eng_engage_map 	    = [0;1;1];%for manual and CVT tx
ptc_t_cpl_eng_disengage_index   = [0;0.1;0.35;0.45];%for manual and CVT tx
ptc_pwm_cpl_eng_disengage_map   = [1;1;0;0];%for manual and CVT tx

%Calculation of time spent in neutral during shifting based on
ptc_tx_t_neutral               = ptc_t_cpl_shift_index(max(find(ptc_pwm_cpl_shift_map==0))) - ptc_t_cpl_shift_index(min(find(ptc_pwm_cpl_shift_map==0))); 


if strcmp(model.drivetrain.trans,'ct'),%need to define here as no sft files for ct - AYR
   [spd_index, trq_index]=find(max(max(eng_eff_hot_map))==eng_eff_hot_map);
    sft_spd_op_max = min((eng_spd_fuel_hot_index(spd_index) + 100),(max(eng_spd_max_hot_index)));
end

% desired engine spd during starting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isfield(model.strategy,'perfo')
    ptc_trs_eng_spd_veh_start = 4*eng_spd_idle;
else
    ptc_trs_eng_spd_veh_start = 2*eng_spd_idle;
end

if strcmp(model.drivetrain.pos1,'Starter_motor_alternator')
    ptc_tx_in_inertia = eng_inertia + mc_inertia;
else
    ptc_tx_in_inertia = eng_inertia;
end
