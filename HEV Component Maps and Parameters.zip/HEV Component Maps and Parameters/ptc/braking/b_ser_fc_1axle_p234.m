%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_b_mc_trq_brake_frac = 0.5;
ptc_b_mc_trq_brake_frac_max = 1;
ptc_b_wh_trq_brake_frac = 0;
ptc_b_mc_spd_regen_brake_off = 31;
ptc_b_veh_spd_regen_brake_off = 1;
ptc_b_fc_t_on_min = 5;
ptc_b_mc_t_dmd_min = 1;
ptc_b_fc_off_soc = 0.8;
ptc_b_fc_on_soc =0.5;
ptc_b_mc_soc_regen_off = 10;
ptc_p_fc_t_on_min = 5;
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%