%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_b_mc_trq_brake_frac = 0.5;
ptc_b_mc_trq_brake_frac_max = 1;
ptc_b_percent_front_brake = 0.7;%used for 4WD configurations
ptc_b_wh_trq_brake_frac = 0;
ptc_b_mc_spd_regen_brake_off = 31;
ptc_b_veh_spd_regen_brake_off = 1;
ptc_b_fc_t_on_min = 5;
ptc_b_t_mc_dmd_min_p =1;
ptc_b_fc_off_soc_p = 0.8;
ptc_b_fc_on_soc_p = 0.3;
ptc_b_mc_soc_regen_off = 0.9;
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%