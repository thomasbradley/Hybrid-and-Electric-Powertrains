%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BEGIN_STRATEGY_PARAMETERS
ptc_b_eng_t_on_min = 2;
ptc_b_t_gc_dmd_min = 1;
ptc_b_mc_trq_brake_frac = 0.5;
ptc_b_mc_trq_brake_frac_max = 1;
ptc_b_wh_trq_brake_frac = 0;
ptc_b_mc_spd_regen_brake_off = 31;
ptc_b_eng_off_soc = 0.6;
ptc_b_eng_on_soc = 0.54;
ptc_b_veh_spd_regen_brake_off = 1;
ptc_b_mc_soc_regen_off = 0.99;
%END_STRATEGY_PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%