% rerun02.m PSAT V5.1  input file created: 03-Sep-2003 22:14:35

% simulate a Conventional vehicle
%

[info]=what('root/run');
if isempty(info),
	fprintf(1,'You forgot to set the path by typing ''set_path'' under the directory psat/root \n');
	return
end

global model

save_mode = 0;
model.drivetrain.select_to_workspace = 'off';
model.prototyping = 0;
rerun_file = 'rerun.m';
model.drivetrain.name = 'conv_2wd_au';
model.sim.compil = 'off';


% Load the Components
model.drivetrain.drv.ver = '1';
model.drivetrain.drv.init = 'drv_normal_1000_05';
model.drivetrain.drv.scale = '';
model.drivetrain.drv.calc = {''};
model.drivetrain.drv.prev_ver = '1';
model.drivetrain.drv.prev_init = 'drv_cool_200_5';

model.drivetrain.str.init = 'str_10_10';
model.drivetrain.str.ver = '1';
model.drivetrain.str.type = '';
model.drivetrain.str.calc = {''};
model.drivetrain.str.scale = '';

model.drivetrain.eng.ver = '1';
model.drivetrain.eng.type = 'ci';
model.drivetrain.eng.init = 'eng_ci_OM611_80kw';
model.drivetrain.eng.scale = '';
model.drivetrain.eng.calc = {'eng_calculation'};
model.drivetrain.eng.prev_ver = '1';
model.drivetrain.eng.prev_init = 'eng_ci_10800_246_HOT';
model.drivetrain.eng.prev_type = 'ci';

model.drivetrain.accmech.ver = '1';
model.drivetrain.accmech.init = 'accmech_500';
model.drivetrain.accmech.scale = '';
model.drivetrain.accmech.calc = {''};
model.drivetrain.accmech.prev_ver = '1';
model.drivetrain.accmech.prev_init = 'accmech_0';

model.drivetrain.cpl.ver = '2';
model.drivetrain.cpl.init = 'torqconv_over250Nm';
model.drivetrain.cpl.scale = '';
model.drivetrain.cpl.calc = {''};
model.drivetrain.cpl.prev_ver = '2';
model.drivetrain.cpl.prev_init = 'torqconv_under150Nm';

model.drivetrain.tx.ver = '2';
model.drivetrain.tx.init = 'tx_5_au_sprinter_v2';
model.drivetrain.tx.scale = '';
model.drivetrain.tx.calc = {''};
model.drivetrain.tx.prev_ver = '2';
model.drivetrain.tx.prev_init = 'tx_5_au_sprinter_v2';
model.drivetrain.tx.type = 'au';

model.drivetrain.fd.ver = '1';
model.drivetrain.fd.init = 'fd_327_explorer';
model.drivetrain.fd.scale = '';
model.drivetrain.fd.calc = {''};
model.drivetrain.fd.prev_ver = '1';
model.drivetrain.fd.prev_init = 'fd_454_intets';

model.drivetrain.wh.ver = '1';
model.drivetrain.wh.init = 'wh_035_suv';
model.drivetrain.wh.scale = '';
model.drivetrain.wh.calc = {''};
model.drivetrain.wh.prev_ver = '1';
model.drivetrain.wh.prev_init = 'wh_026_PNGV';

model.drivetrain.veh.ver = '1';
model.drivetrain.veh.init = 'veh_Sprinter_SUV';
model.drivetrain.veh.scale = '';
model.drivetrain.veh.calc = {''};
model.drivetrain.veh.prev_ver = '1';
model.drivetrain.veh.prev_init = 'veh_2270_317_036_SUV_ucdavis';

model.drivetrain.ex.ver = '3';
model.drivetrain.ex.type = 'ox';
model.drivetrain.ex.init = 'ex_ot_1';
model.drivetrain.ex.scale = '';
model.drivetrain.ex.calc = {'ex_calculation'};

model.drivetrain.ess.ver = '1';
model.drivetrain.ess.type = 'pb';
model.drivetrain.ess.init = 'ess_pb_16_144_hawker';
model.drivetrain.ess.scale = '';
model.drivetrain.ess.calc = {''};
model.drivetrain.ess.prev_ver = '1';
model.drivetrain.ess.prev_init = 'ess_pb_104_150';
model.drivetrain.ess.prev_type = 'pb';

model.drivetrain.accelec.ver = '1';
model.drivetrain.accelec.init = 'accelec_0';
model.drivetrain.accelec.scale = '';
model.drivetrain.accelec.calc = {''};
model.drivetrain.accelec.prev_ver = '1';
model.drivetrain.accelec.prev_init = 'accelec_500';

model.drivetrain.gc.init = 'gc_pm_2';
model.drivetrain.gc.ver = '2';
model.drivetrain.gc.type = 'pm';
model.drivetrain.gc.calc = {'gc_calculation'};
model.drivetrain.gc.scale = '';

model.drivetrain.tc.init = 'tc_16_explorer';
model.drivetrain.tc.ver = '1';
model.drivetrain.tc.type = '';
model.drivetrain.tc.calc = {''};
model.drivetrain.tc.scale = '';
model.drivetrain.tc.prev_ver = '1';
model.drivetrain.tc.prev_init = 'tc_08';
model.drivetrain.tc.prev_type = '';


%------------------------------
gui_param_file = 'gui_param_models';

%Modified variables
model.drivetrain.variables = {...
	'ess_soc_init',0.22,0.2;...
	'veh_mass_des',3880,3880;...
	'ess_num_cell',6,[]};
%End Modified variables


%------------------------------
%Strategy
model.strategy.conso.prop.init = 'p_conv_conso';
model.strategy.conso.prop.model = 'p_conv_conso';
model.strategy.conso.shifting.init = 'tx_shift';
model.strategy.conso.shifting.model = 's_dm_best_eng_curve_conv';
model.strategy.conso.braking.init = 'b_conv_1axle';
model.strategy.conso.braking.model = 'b_conv_1axle';
model.strategy.conso.trs.init = {...
	'trs_tx_cpl';...
	'';...
	'';...
	'';...
	''};
model.strategy.conso.trs.model = {...
	'tx','lib_trs_tx_au';...
	'eng','lib_trs_eng_au';...
	'gc','lib_trs_gc_conv';...
	'str','lib_trs_str';...
	'wh','lib_trs_wh_2wd'};
%------------------------------
gui_control_file = 'gui_param_control';

%Control variables

%End Control variables

%------------------------------
%Cycle Simulation
model.sim.cycle.run = 'on';
model.sim.cycle.number = 1;
model.sim.cycle.name = 'car_ECE';
model.sim.cycle.steady = 'off';
model.sim.cycle.steady_spd = 25;
model.sim.cycle.duration = 'off';
model.sim.cycle.duration_time = 200;

model.sim.multi_cycles.run = 'off';
model.sim.trip.run = 'off';
model.sim.test_procedures.run = 'off';
model.sim.road_grade.run = 'off';
model.sim.road_load.run = 'off';
model.sim.acceleration.run = 'off';
model.sim.gradeability.run = 'off';
model.sim.parametric.run = 'off';
model.sim.soc.run = 'off';

%------------------------------
%Simulink Parameters
model.sim.simulink.AbsTol = 'auto';
model.sim.simulink.Debug = 'off';
model.sim.simulink.Decimation = 1;
model.sim.simulink.DstWorkspace = 'current';
model.sim.simulink.FinalStateName = '';
model.sim.simulink.FixedStep = '0.01';
model.sim.simulink.InitialState = [];
model.sim.simulink.InitialStep = 'auto';
model.sim.simulink.MaxOrder = 5;
model.sim.simulink.SaveFormat = 'Matrix';
model.sim.simulink.MaxRows = 0;
model.sim.simulink.MaxStep = 'auto';
model.sim.simulink.OutputPoints = 'all';
model.sim.simulink.OutputVariables = 'ty';
model.sim.simulink.Refine = 1;
model.sim.simulink.RelTol = '0.001';
model.sim.simulink.Solver = 'ode4';
model.sim.simulink.SrcWorkspace = 'base';
model.sim.simulink.Trace = '';
model.sim.simulink.ZeroCross = 'off';
model.sim.simulink.SimStep = 'Fixed';
model.sim.simulink.SolverMode = 'auto';

% Load the debug parameters
debug_psat = 0;
stop_simu_before_end = 0;
show_building = 0;
manual_sim_stop = 0;
create_param_files(rerun_file);

