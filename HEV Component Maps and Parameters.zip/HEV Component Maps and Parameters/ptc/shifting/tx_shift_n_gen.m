%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_shiftN_gen.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the shifting law for a five gear%
% transmission														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: P.Sharer - ANL - 4/8/02				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global model

clear ptc_s_acc_up_index ptc_s_acc_dn_index ptc_s_veh_spd_upshift_index ptc_s_veh_spd_dnshift_index ptc_s_gear_upshift_map ptc_s_gear_dnshift_map;


if ~strcmp(model.drivetrain.eng.init,'')
    ptc_trs_eng_spd_veh_start = eng_spd_idle*2;
end

%Scaling input
if strcmp(model.drivetrain.eng.scale,'')   
    ptc_s_sr=1;
else
    ptc_s_sr=eng_sr;
end

if ptc_s_sr<=1
    ptc_s_sr=1;
end

gear_ratio=tx_ratio_map;

if min(tx_ratio_map)==0
    gear_ratio(1)='';
end

% Shift table accelerator command
if strcmp(model.drivetrain.pwt,'Fuel Cell Only') | strcmp(model.drivetrain.pwt,'Series Fuel Cell Hybrid') | strcmp(model.drivetrain.pwt,'Series Engine Hybrid') | strcmp(model.drivetrain.pwt,'Electric'),
    ptc_s_spd_op_max = 3/4*max(mc_spd_max_index);
    ptc_s_spd_op_min = 1/4*max(mc_spd_max_index);
else
    [spd_index, trq_index]=find(max(max(eng_eff_hot_map))==eng_eff_hot_map);
    spd_index = spd_index(1); %In case there is more than one optimal point. Just take the first one.
    trq_index = trq_index(1); %In case there is more than one optimal point. Just take the first one.
    ptc_s_spd_op_max = min((eng_spd_fuel_hot_index(spd_index) + 100),(max(eng_spd_max_hot_index)));
    ptc_s_spd_op_min = max((eng_spd_fuel_hot_index(spd_index) - 150),(eng_spd_idle+20));
end

if strcmp(model.drivetrain.axle,'4 wheel drive')
    veh_spd_op_max=ptc_s_spd_op_max*wh_radius/fd_ratio/trc_ratio./gear_ratio;
    veh_spd_op_min=ptc_s_spd_op_min*wh_radius/fd_ratio/trc_ratio./gear_ratio;
else
    veh_spd_op_max=ptc_s_spd_op_max*wh_radius/fd_ratio./gear_ratio;
    veh_spd_op_min=ptc_s_spd_op_min*wh_radius/fd_ratio./gear_ratio;
end


j = 1;
for i=length(gear_ratio):-1:2
    ptc_s_acc_up_index(j) = gear_ratio(i)/gear_ratio(1);
    j=j+1;
end
ptc_s_acc_up_index=[0 ptc_s_acc_up_index];
ptc_s_acc_up_index(end+1)=1;



j = 1;
for i=length(gear_ratio):-1:2
    ptc_s_acc_dn_index(j) = gear_ratio(i)/gear_ratio(1);
    j=j+1;
end
ptc_s_acc_dn_index= [0 ptc_s_acc_dn_index];
ptc_s_acc_dn_index(end+1)=1;



ptc_s_veh_spd_upshift_index(1)=0;

if strcmp(model.drivetrain.pwt,'Fuel Cell Only') | strcmp(model.drivetrain.pwt,'Series Fuel Cell Hybrid')  | strcmp(model.drivetrain.pwt,'Series Engine Hybrid') | strcmp(model.drivetrain.pwt,'Electric'),
    ptc_s_veh_spd_upshift_index(2) = ptc_s_veh_spd_upshift_index(1) + 3;
else
    if strcmp(model.drivetrain.axle,'4 wheel drive')
        ptc_s_veh_spd_upshift_index(2)=max((eng_spd_idle+50)*wh_radius/fd_ratio/trc_ratio./gear_ratio(2),(ptc_trs_eng_spd_veh_start+50)*wh_radius/fd_ratio/trc_ratio./gear_ratio(1));
    else
        ptc_s_veh_spd_upshift_index(2)=max((eng_spd_idle+50)*wh_radius/fd_ratio./gear_ratio(2),(ptc_trs_eng_spd_veh_start+50)*wh_radius/fd_ratio/gear_ratio(1));
    end
end

j = 1;
for i=3:(length(gear_ratio)+2)
    ptc_s_veh_spd_upshift_index(i) = max(veh_spd_op_max(j),ptc_s_veh_spd_upshift_index(i-1)+2);
    j = j + 1; 
end

ptc_s_veh_spd_dnshift_index(1)=0;
for i=2:(length(gear_ratio)+1)
    ptc_s_veh_spd_dnshift_index(i) = veh_spd_op_min(i-1);
end
ptc_s_veh_spd_dnshift_index(end+1) = 2*veh_spd_op_min(end)-veh_spd_op_min(end-1);


gear_num = [1:length(gear_ratio)];
ptc_s_gear_upshift_map = [];
for i = 1:length(ptc_s_acc_up_index)
    if i <=2
        ptc_s_gear_upshift_map =[ptc_s_gear_upshift_map [gear_num gear_num(end) gear_num(end)]'];
    else
        ptc_s_gear_upshift_map =[ptc_s_gear_upshift_map [1 gear_num gear_num(end)]'];
    end
end

ptc_s_gear_dnshift_map = [];
for i = 1:length(ptc_s_acc_dn_index)
    if i >=(length(ptc_s_acc_dn_index)-1)
        ptc_s_gear_dnshift_map =[ptc_s_gear_dnshift_map [1 1 gear_num]'];
    else
        ptc_s_gear_dnshift_map =[ptc_s_gear_dnshift_map [1 gear_num gear_num(end)]'];
    end
end

    
ptc_s_gear_upshift_map = ptc_s_gear_upshift_map';
ptc_s_gear_dnshift_map = ptc_s_gear_dnshift_map';

clear gear_ratio gear_index