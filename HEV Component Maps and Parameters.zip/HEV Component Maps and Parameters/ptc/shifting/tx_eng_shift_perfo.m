%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_shift_perfo.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the shifting law for a 	    %
% performance study                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 07/04/01				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear ptc_s_veh_spd_upshift_index ptc_s_gear_upshift_map veh_spd_max_ratio_map wh_trq_max_ratio_map;

if ~strcmp(model.drivetrain.trans,'ct')
    gear_ratio=tx_ratio_map;
    gear_index=tx_gear_index;
    
    if min(tx_ratio_map)==0,
        gear_ratio(1)='';
        gear_index(1)='';  
    end
    
    if strcmp(model.drivetrain.axle,'4 wheel drive')
        for idx=1:length(gear_ratio)
            veh_spd_max_ratio_map(idx,:) = eng_spd_max_hot_index * wh_radius / fd_ratio /trc_ratio ./ gear_ratio(idx);
            wh_trq_max_ratio_map(idx,:)  = eng_trq_max_hot_map * fd_ratio * trc_ratio .* gear_ratio(idx);
        end
    else
        for idx=1:length(gear_ratio)
            veh_spd_max_ratio_map(idx,:) = eng_spd_max_hot_index * wh_radius / fd_ratio ./ gear_ratio(idx);
            wh_trq_max_ratio_map(idx,:)  = eng_trq_max_hot_map * fd_ratio .* gear_ratio(idx);
        end
    end
    ptc_s_veh_spd_upshift_index(1) = 0;
    for idx=2:length(gear_ratio),
        for cpt=1:length(eng_spd_max_hot_index),
            if wh_trq_max_ratio_map(idx-1,cpt)>wh_trq_max_ratio_map(idx,cpt),
                ptc_s_veh_spd_upshift_index(idx) = veh_spd_max_ratio_map(idx-1,cpt);
            end
        end
    end
    
    ptc_s_acc_up_index     = [0:1];
    ptc_s_gear_upshift_map = [gear_index; gear_index];
end
clear gear_ratio gear_index