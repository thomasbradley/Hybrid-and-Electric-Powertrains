%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_shift_perfo.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the shifting law for a 	    %
% performance study                                                 %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 07/04/01				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear ptc_s_veh_spd_upshift_index ptc_s_gear_upshift_map;

if ~strcmp(model.drivetrain.trans,'ct')
    gear_ratio=tx_ratio_map;
    gear_index=tx_gear_index;
    
    if min(tx_ratio_map)==0,
        gear_ratio(1)='';
        gear_index(1)='';  
    end
    
    idx = find(mc_trq_cont_map < mc_trq_cont_map(1));
    if strcmp(model.drivetrain.trans,'au') | strcmp(model.drivetrain.trans,'dm')
        n = idx(1)-1;
    else n = idx(1)-2;
    end
    ptc_spd_shift_opt = mc_spd_cont_index(n);
    if strcmp(model.drivetrain.axle,'4 wheel drive')    
        veh_spd_opt_max=ptc_spd_shift_opt*wh_radius/fd_ratio/trc_ratio./gear_ratio;
    else
        veh_spd_opt_max=ptc_spd_shift_opt*wh_radius/fd_ratio./gear_ratio;
    end
    ptc_s_veh_spd_upshift_index(1) = 0;
    for idx=2:length(gear_ratio),
        ptc_s_veh_spd_upshift_index(idx) = veh_spd_op_max(idx-1);
    end
    
    ptc_s_acc_up_index     = [0:1];
    ptc_s_gear_upshift_map = [gear_index; gear_index];
end
