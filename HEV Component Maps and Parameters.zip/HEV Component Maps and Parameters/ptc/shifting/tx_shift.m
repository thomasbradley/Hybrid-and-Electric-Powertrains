%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_shift.m								   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the shifting law for the 		    %
% conversion of the gear ratio in gear number for the parallel PCT 	   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 11/16/99					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 		    : 												%
% A.Rousseau - 02/18/00 - change the calculation of tx_gear_gm_dnshift  % 
% for	the manual transmission, it is now the same as automatic	    %
%																	    %
%C.Kwon - 06/01/00 - we have a warning such as "Warning: Ignoring	   	% 
%duplicate values" on sft_ratio_upshift_index. This comes from the zero %
%gear ratio in tx_ratio_map_sort and we can't avoid this problem as 	%
%long as sqrt has been used to calculate tx_gear_gm.					% 
%=> Sqrt calculation has been replaced by average calculation			%
%   that is, sqrt(a(i)+a(i+1)) => (a(i)+a(i+1))/2						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Tables to be used in the discrete step drivetrains to map gear ratio 
% command from the power controller into gear number; includes hysteresis
% to prevent high speed chattering.
disp('tx_shift')
ptc_s_ratio_upshift_index    = [];
ptc_s_gear_upshift_1map 		= [];
tx_upshift_curve 			= [];
ptc_s_ratio_dnshift_index    = [];
ptc_s_gear_dnshift_1map 		= [];
tx_ratio_map_sort = sort(tx_ratio_map);

for i = 1:length(tx_ratio_map_sort)-1,
   
   tx_gear_gm    = 0.5*(tx_ratio_map_sort(i)+ tx_ratio_map_sort(i+1));
   tx_gear_gm_upshift = 0.5*(tx_gear_gm + tx_ratio_map_sort(i+1));
   tx_gear_gm_dnshift =  tx_gear_gm_upshift + 0.9*(tx_ratio_map_sort(i+1)- tx_gear_gm_upshift);
   
   ptc_s_ratio_upshift_index(4*(i-1)+1)    = tx_ratio_map_sort(i);
   ptc_s_ratio_upshift_index(4*(i-1)+2)    = tx_gear_gm_upshift;
   ptc_s_ratio_upshift_index(4*(i-1)+3)    = tx_gear_gm_upshift;
   ptc_s_ratio_upshift_index(4*(i-1)+4)    = tx_ratio_map_sort(i+1);
   
   ptc_s_gear_upshift_1map(4*(i-1)+1) = length(tx_ratio_map_sort) - i + 1;
   ptc_s_gear_upshift_1map(4*(i-1)+2) = length(tx_ratio_map_sort) - i + 1;
   ptc_s_gear_upshift_1map(4*(i-1)+3) = length(tx_ratio_map_sort) - i;
   ptc_s_gear_upshift_1map(4*(i-1)+4) = length(tx_ratio_map_sort) - i;
   
   ptc_s_ratio_dnshift_index(4*(i-1)+1)    = tx_ratio_map_sort(i);
   ptc_s_ratio_dnshift_index(4*(i-1)+2)    = tx_gear_gm_dnshift;
   ptc_s_ratio_dnshift_index(4*(i-1)+3)    = tx_gear_gm_dnshift;
   ptc_s_ratio_dnshift_index(4*(i-1)+4)    = tx_ratio_map_sort(i+1);
   
   ptc_s_gear_dnshift_1map(4*(i-1)+1) = length(tx_ratio_map_sort) - i + 1;
   ptc_s_gear_dnshift_1map(4*(i-1)+2) = length(tx_ratio_map_sort) - i + 1;
   ptc_s_gear_dnshift_1map(4*(i-1)+3) = length(tx_ratio_map_sort) - i;
   ptc_s_gear_dnshift_1map(4*(i-1)+4) = length(tx_ratio_map_sort) - i;
   
end

% the following tables are used when the vehicle is braking
ptc_tx_spd_shift_brake_index 	= [0 5 25 45];%m/s
ptc_tx_spd_shift_brake_map 	= [eng_spd_idle 2800*c_rpm_radps  2800*c_rpm_radps eng_spd_hot_max];

ptc_shift_up_table              = [ 1564	1672	1721	1700; 1564	1672	1721	1700; 1564	1967	2072	2050;
									2265	2689	2775	2775; 3020	3246	3337	3325; 3775	3804	3794	3800;
									3775	3804	3794	3800]*c_rpm_radps;%DESCRIPTION: (rad/s) up shift maps from Daimler (THB)
                                
ptc_shift_down_table            = [ 787     787	    878	    1000	1143; 
                                    787     787	    878	    1000	1143; 
                                    787     787	    878	    1000	1143;
									787	    918	    1581	1650	1683; 
									787	    1115	1756	1950	2015; 
                                    787     1377	1862	2175	2597; 
                                    787     1377	1862	2175	2597]*c_rpm_radps;%DESCRIPTION: (rad/s) down shift maps from Daimler (THB)
clear i
