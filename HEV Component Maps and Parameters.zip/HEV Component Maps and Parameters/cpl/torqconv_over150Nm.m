%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: torqconv_over150Nm.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% torque converter													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 10/13/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 							                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/09/00  maximum torque before scaling	                %
% Bob Lawrie - 6/1/01 new input data for v2 torconverter model      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : this file should be run after model.drivetrain.eng.init, model.drivetrain.mc.init			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cpl_spd_idle 			= 0;				% starting engine speed set to 0 or fc_spd_idle
cpl_lock_thresh 		= 40.0; 			% spd difference < thresh enables lock up
cpl_inertia_in 		    = 0.08; 			% factor of 20 introduced to conform to data provided by Joe Steiber 
cpl_inertia_out 		= 0.025; 			% same as above
cpl_pump_spd_thresh 	= 10;
cpl_mass                = 25;

% load steady-state test data for 150K
SR=[0:.1: .9];																					% Speed ratio
TR=[2.200	2.064	1.929	1.793	1.658	1.522	1.387	1.251	1.116	0.980];				% Torque ratio
w_in=[1395	1400	1410	1430	1470	1525	1600	1710	1850	2100]*pi/30;		% impeller speed
T_in=ones(1,10)*87.5*4.448/3.281;															    % impeller data based on constant input torque (lb-ft==>Nm)
k_in=w_in./T_in.^.5;																			% K=N/sqrt(T)
cpl_slip_ratio_in_index = [SR 0.925 0.950	0.975	1.000	1.050];
cpl_coeff_in_map = [1./k_in.^2  0.00210	0.00164	0.00098	0.00000	-0.00300] ;		                % Impeller torque in N-m/(rad/s)^2
cpl_torque_ratio_map = [TR 0.980	0.980	0.980	0.980	0.980];								% Torque ratio

% Lock up info
ptc_lock_map        =  [0.0, 0.0, 1.0, 1.0]; % Converter lockup table command
ptc_lock_spd_index  =  [0.00, 15.30, 15.40, 53.80]; 
% Unlock info
ptc_unlock_map      =  [0.0, 0.0, 1.0, 1.0];% Converter Unlock table
ptc_unlock_spd_index=  [0.0, 14.20, 14.30, 53.80]; 	% Converter unlock table speed in m/s

cpl_pump_trq_eff_index = [	13.56, 84.75, 169.5, 254.25, 339.0];% Pump efficiency torque axis in N-m
cpl_pump_spd_eff_index = [	52.36, 104.72,157.08,209.44,261.08,314.16,366.52,418.88,471.24,523.60,575.96,628.32];% Pump efficiency Speed axis in rad/s
cpl_pump_eff_map = ...                               % Pump efficiency
    [0.813,0.799,0.776,0.751,0.722,0.688,0.654,0.618,0.575,0.531,0.375,0.320;...
        0.968,0.966,0.963,0.959,0.954,0.949,0.943,0.938,0.931,0.923,0.897,0.883;...
        0.975,0.976,0.974,0.972,0.970,0.967,0.965,0.962,0.959,0.956,0.951,0.943;...
        0.986,0.988,0.988,0.987,0.986,0.985,0.984,0.983,0.982,0.981,0.979,0.976;...
        0.975,0.979,0.979,0.978,0.977,0.976,0.975,0.973,0.971,0.970,0.967,0.964];

cpl_pump_spd_loss_index = cpl_pump_spd_eff_index;
cpl_pump_trq_loss_index = cpl_pump_trq_eff_index;
% Change pump efficiency table into torque loss table
for i=1:size(cpl_pump_trq_loss_index,2)
    for j=1:size(cpl_pump_spd_loss_index,2)
        cpl_pump_trq_loss_map(i,j) = (1-cpl_pump_eff_map(i,j))*cpl_pump_trq_loss_index(i);
    end;
end;

