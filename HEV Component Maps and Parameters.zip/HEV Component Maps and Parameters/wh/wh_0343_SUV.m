%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: wh_0343_suv.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% wheel model														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: DAVID ALEXANDER - Univ Idaho - 05/01/01	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

wh_trq_brake_max_i_p 		= 2000;					        % N-m
wh_radius_i_p 				= 0.343;					    % m
wh_inertia_i_p 				= 181/2.205*wh_radius_i_p^2/2;	% kg-m^2
wh_circ 					= 2*pi*wh_radius_i_p ;		    % m
wh_slip_thresh_i 		    = 0.01;					        % rad/s
wh_mass 					= 30;					        % kg
wh_brk_bklash_i 			= 0.05;
wh_mass_frac_front_i_p 		= 0.60; 					    % percent weight on the front wheels


