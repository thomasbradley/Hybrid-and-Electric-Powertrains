%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: wh_044_silverado_rear.m					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% wheel model														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


wh2_trq_brake_max_i_p 		= 2000;					% N-m
wh2_inertia_i_p 			= 1.0;
wh2_radius_i_p 				= 0.44;					% m
wh2_mass 					= 15;					% kg
wh2_circ 					= 2*pi*wh2_radius_i_p ; % m
wh2_brk_bklash_i_p			= 0.05;
wh2_slip_time_const         = 2.0;                  % Hz - wheel slip time constant - slow slip calculation down
wh_mass_frac_front_i_p	    = 0.65; 				% percent weight on the front wheels
wh2_trq_brake_drag_const_i_p= 4.84;

% dimensionless - wheel friction coefficient (tractive force on the tires)/(weight on axle)
wh2_friction_coeff=[-1.06 -1.0212 -.9616 -.8540 -.6715 -.3913 0 0.3913 0.6715 0.8540 0.9616 1.0212 1.06];

% wheel slip map - reference Car Suspension & Handling, 3rd Edition page 138 by D. Bastow and G Howard
% slip=(omega * r)/v -1
wh2_slip_map=[-.15 -.125 -.10 -.075 -.050 -.025 0 0.025 0.050 0.075 0.10 0.125 0.15];


