%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_pb_16_144_hawker.m					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Hawker Odyssey sealed lead acid model battery	16Ah and 144 		%
% elements(24 modlues of 6 elements).Hawker Genesis LAcid Battery   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			:Chad Lela, Tim Norton- University Tennesse %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% Number of cells per module: 6x2V=12V/module						%
% Capacity (C/20): 16Ah/3.5kWh										%
% Peak power, 10s at 50% SOC: 30kW									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	= 6;
ess_num_module			= 24;  						    % value for number of modules
ess_num_cell	 		= ess_num_module * ess_element_per_module;
ess_volt_min			= 11.58/ess_element_per_module; %ess_voc_map(1)-ess_cap_max_map/5*ess_rint_dis_map(1);
ess_volt_max			= 15.6/ess_element_per_module;	%ess_voc_map(end)+ess_cap_max_map/5*ess_rint_chg_map(end);
ess_mass_module			= 6.1;  						% (kg), mass of each individual battery
ess_mass 				= ess_mass_module/ess_element_per_module;
env_temp_amb			= 20;
env_air_cap				= 1009;         % J/kgK  ave cp of air
env_temp_init_mod		= 35;   		% C      initial eng cyl temp
ess_soc_min 			= 0.1;
ess_soc_max 			= 1.0;

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_soc_index           = [0:.2:1];  	% SOC RANGE over which data is defined
ess_temp_index          = [0 22 40];  % Temperature range over which data is defined (C), map is independent of temperature
ess_cap_max_map         = [16 16 16];	% (A*h), max. capacity at C/3 rate, indexed by ess_temp_index
ess_eff_coulomb         = [.95 .95 .95];  % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index (0 .2 .4 .6 .8 1)
ess_rint_dis_map=[21 16.1 12.4 9.9 8.6 8.5;
    21 16.1 12.4 9.9 8.6 8.5;
    21 16.1 12.4 9.9 8.6 8.5]/ess_element_per_module/1000; % (ohm)
ess_r_dis=ess_rint_dis_map;

% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
%Note: last Rchg number (150 mohm) is an extrapolation since test data limited
ess_rint_chg_map=[21 16.1 12.4 9.9 8.6 8.5;
    21 16.1 12.4 9.9 8.6 8.5;
    21 16.1 12.4 9.9 8.6 8.5]/ess_element_per_module/1000; % (ohm)
ess_r_chg=ess_rint_chg_map;

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[11.575 11.82458 12.07416 12.32374 12.57332 12.8229;
   11.575 11.82458 12.07416 12.32374 12.57332 12.8229;
   11.575 11.82458 12.07416 12.32374 12.57332 12.8229] /ess_element_per_module; % (V)
ess_voc=ess_voc_map;

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_th_calc=0;                             												% --     0=no ess thermal calculations, 1=do calc's
ess_therm_on=0;                             												% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module=660;                            									% J/kgK  ave heat capacity of module
ess_temp_reg=25;                            												% C      thermostat temp of module when cooling fan comes on
ess_area_module=0.2;                         											% m^2    total module surface area exposed to cooling air
ess_flow_air_mod=0.07/12;                   												% kg/s   cooling air mass flow rate across module (140 cfm=0.07 kg/s at 20 C)
ess_therm_flow_area_module=0.002;                   									% m^2    cross-sec flow area for cooling air per module
ess_case_thk=2/1000;                   													% m      thickness of module case
ess_therm_case_cond=0.20;                 												% W/mK   thermal conductivity of module case material
ess_speed_air=ess_flow_air_mod/(1.16*ess_therm_flow_area_module); 				% m/s  ave velocity of cooling air
ess_therm_air_htcoef=30*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on=((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off=((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
% set bounds on flow rate and thermal resistance
ess_flow_air_mod=max(ess_flow_air_mod,0.001);
ess_therm_res_on=min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_therm_flow_area_module ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef

