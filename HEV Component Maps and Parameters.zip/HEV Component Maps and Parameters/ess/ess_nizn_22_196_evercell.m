%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nizn_22_196_evercell.m				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 22 Ah Evercel NiZn battery				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: Zeki Gore - Georges Washington - 04/23/01	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module	    = 7;
ess_num_module				= 28;
ess_num_cell				= ess_num_module *ess_element_per_module;
ess_volt_min				= 1.1;
ess_volt_max				= 1.7;
ess_mass_module			    = 8.1;
ess_mass					= ess_mass_module/ess_element_per_module;
env_temp_amb_i				= 20;
env_air_cap					= 1009;
env_temp_init_mod_i		    = 35;
ess_soc_min_i 				= 0.3;
ess_soc_max_i 				= 1.0;

%Loss and Effiecieny parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_soc_index			    = [0 10 20 30 40 50 60 70 80 90 100];
ess_temp_index			    = [26 33];
ess_cap_max_map		        = [22.88 22.81];%Parameters vary by Soc and temp vertic
ess_eff_coulomb		        = [0.96 0.99];%ave coulombic eff

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map		=[0.018 0.0119 0.009 0.0075 0.007 0.0068 0.0067 0.0062 0.0057 0.005 0.0035;
   0.018 0.014 0.0119 0.0097 0.0076 0.0074 0.0064 0.0063 0.0054 0.005 0.0048];	%ohm *7

% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map		=[0.013 0.012 0.0111 0.0107 0.0104 0.0102 0.0101 0.0099 0.0097 0.0081 0.0083;
   0.014 0.0125 0.0116 0.011 0.0105 0.0104 0.01 0.0098 0.0095 0.0083 0.008];%ohm *7 

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map				=[1.642 1.691 1.72 1.74 1.75 1.755 1.757 1.762 1.768 1.801 1.901;
   1.64 1.682 1.714 1.738 1.758 1.76 1.769 1.77 1.779 1.807 1.89]; % v*7

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= 1;                             									% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module	    = 1175;                            									% J/kgK  ave heat capacity of module (estimated for NiMH)
ess_temp_reg			= 30;                            									% C      thermostat temp of module when cooling fan comes on
ess_area_module		    = .0811;          													% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= .07/7;                      										% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= .001;    															% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= .002;                   											% m      thickness of module case (typ from Optima)
ess_therm_case_cond	    = 20;                 												% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);						% m/s  ave velocity of cooling air
ess_therm_air_htcoef	= 30*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod1