%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_li_14_96_lump.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Li-Ion model battery - 14Ah - 96 elements							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: B.Deville (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 									    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%    CMT                                							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/09/00 change data per pack to data per cell			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% USCAR PROPRIETARY: The data contained in this file is sensitive	%
%                    USCAR battery data.							%
% Assumption: all cells in a pack are in series 	 				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% constant parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_num_cell				= 96;
ess_soc_min 				= 0.3;							% no units
ess_soc_max 				= 1.0;								% no units
ess_mass 					= 66.3/ess_num_cell;			% Kg
ess_cap 					= 14.3*3600;					% amp-seconds
ess_volt_min                = 2;
ess_volt_max			    = 3.9;


%  The usable system energy is ess_energy_max*(max_soc-min_soc)
ess_energy_max 			    = 4.89.*1000.*3600./ess_num_cell;	% joules

% Open circuit voltage equation coefficients 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_voc_coeff_a = -6.052;
ess_voc_coeff_b = 12.554;
ess_voc_coeff_c = -8.815;
ess_voc_coeff_d = 3.0565;
ess_voc_coeff_e = 3.1655;
ess_voc_max = ess_voc_coeff_a + ess_voc_coeff_b + ess_voc_coeff_c + ess_voc_coeff_d + ess_voc_coeff_e;

%Lumped-parameter
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_ohm_resist = 0.01842/(ess_cap/3600)*0.978;
ess_rcoll_resist = 0.01976;
ess_polar_resist = 0.02388/ess_cap*0.978;
ess_polar_time = 27;

% Battery limits
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max_i          = 217;
ess_curr_dis_max_i          = 217;
ess_curr_chg_max            = 217;
ess_curr_dis_max            = 217;
ess_pwr_chg                 = (ess_voc_max*ess_curr_chg_max_i*ess_num_cell + (ess_ohm_resist*ess_num_cell + ess_rcoll_resist)*ess_curr_chg_max_i^2)/ess_num_cell;%per cell
ess_pwr_dis                 = (ess_voc_max*ess_curr_dis_max_i*ess_num_cell - (ess_ohm_resist*ess_num_cell + ess_rcoll_resist)*ess_curr_dis_max_i^2)/ess_num_cell;%per cell
