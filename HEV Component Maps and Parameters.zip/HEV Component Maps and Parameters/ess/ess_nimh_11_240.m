%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nimh_11_240.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% NiMh model battery11Ah and 240 elements (10 modules of 24 elements%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: J.Bayer - (UW-Madison) 4/30/01			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		:										    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark (per cell data) : 											%
% Cell type = Cs													%
% Nominal Voltage = 1.2V											%
% Nominal Capacity (C/3) = 2.2Ah	Configured as 5 parallel cells	%
% Dimensions (L * W * H) = 22mm diameter 42mm height				%
% Weight = .58 g									    			%
% Volume  = 16000 mm^3												%
% Nominal Energy (C/3) = 2.64 Wh									%
% Peak Power (10s pulse @ 50%DOD @ 35 deg. C) = 60W					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	= 24;
ess_num_module			= 10;  									% value for number of modules
ess_num_cell 			= ess_num_module * ess_element_per_module;
ess_volt_min			= 1.0;
ess_volt_max			= 1.5;
ess_mass_module			= 24*1.392;  								% (kg), mass of 24 cell stick (it to ya)
ess_mass 				= ess_mass_module/ess_element_per_module;

% Data added by A.Rousseau (ANL) to match with the current PCT (12/19/99) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
env_temp_amb_i			= 20;
env_air_cap				= 1009;     % J/kgK  ave cp of air
env_temp_init_mod_i	    = 35;   		% C      initial eng cyl temp
ess_soc_min_i 			= 0.404;
ess_soc_max_i 			= 1.0;

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           = [0:.2:1];  % SOC RANGE over which data is defined
ess_temp_index          = [0 25 40];  % % Temperature range over which data is defined(C) 
ess_cap_max_map         = [ 11   11   11];	% (A*h), max. capacity at C/3 rate, indexed by ess_temp_index
ess_eff_coulomb         = [   .99   .99   .99];  % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map=[
   1.4024    0.9680    0.8136    0.7244    0.6181    0.3104
    1.4024    0.9680    0.8136    0.7244    0.6181    0.3104
    1.4024    0.9680    0.8136    0.7244    0.6181    0.3104]/ess_num_cell;  
 
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map=[
    0.5542    0.6448    0.6923    0.7259    0.7745    1.0263
    0.5542    0.6448    0.6923    0.7259    0.7745    1.0263
    0.5542    0.6448    0.6923    0.7259    0.7745    1.0263]/ess_num_cell;  

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[
   291.3 302.6 307.9 311.44 316.28 337.28
   291.3 302.6 307.9 311.44 316.28 337.28
   291.3 302.6 307.9 311.44 316.28 337.28]/ess_num_cell; %these numbers are good ss: 4/27/99

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

%battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on				= 1;                             								% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module			= 521;                            							    % 521 J/kgK  ave heat capacity of module from calorimeter test
ess_temp_reg				= 35;                            								% C      thermostat temp of module when cooling fan comes on
ess_dia						= 0.0322;														% m
ess_length					= 0.374; 														% m
ess_area_module				= pi*ess_dia*ess_length;       								    % m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod			= 0.01;                      									% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_therm_flow_area_module	= 2*0.00317*ess_length;    										% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk				= .1/1000;                   									% m      thickness of module case (typ from Optima)
ess_mod_case_th_cond		= 0.20;                 										% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air				= ess_flow_air_mod/(1.16*ess_therm_flow_area_module);	        % m/s  ave velocity of cooling air
ess_therm_air_htcoef		= 30*(ess_speed_air/5)^0.8;      								% W/m^2K cooling air heat transfer coef.
ess_therm_res_on			= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_mod_case_th_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off			= ((1/4)+(ess_case_thk/ess_mod_case_th_cond))/ess_area_module;% K/W  tot thermal res key off (cold soak)
ess_flow_air_mod			= max(ess_flow_air_mod,0.001);
ess_therm_res_on			= min(ess_therm_res_on,ess_therm_res_off);

clear ess_dia ess_length ess_area_module ess_therm_flow_area_module ess_case_thk ess_mod_case_th_cond ess_speed_air ess_therm_air_htcoef ess_area_scale

