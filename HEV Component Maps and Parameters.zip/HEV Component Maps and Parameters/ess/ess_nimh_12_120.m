%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nimh_12_120.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% NiMh model battery - 12.5Ah - 120 elements						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%     Harold Haskins												%
%     Ford Motor Co./US Advanced Battery Consortium					%
%     Electric Vehicle Center Annex									%
%     15001 North Commerce Park										%
%     Dearborn, MI 48120											%
%     (313)845-9248													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/09/00 change data per pack to data per cell			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% USCAR PROPRIETARY: The data contained in this file is sensitive	%
%                    USCAR battery data.							%
% Assumption: all cells in a pack are in series 					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_num_cell			= 120;
ess_soc_min_i 			= 0.225;							% no units
ess_soc_max_i 			= 0.896;							% no units
ess_volt_min			= 1;		% 1 volt time the number of cells
ess_volt_max			= 1.5;	%1.5 volt times the number of cell
ess_mass 				= 83.8./ess_num_cell;			% Kg
ess_cap_coeff_corr 	    = 0.0;							% no units
ess_cap 				= 12.57*3600;					% amp-seconds

% The usable system energy is ess_energy_max*(max_soc-min_soc)
ess_energy_max 		    = 4.51.*1000.*3600./ess_num_cell;	% joules

ess_soc_voc_index       = [0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1];	% no units
ess_voc_map             = polyval([84,-126,90,336],ess_soc_voc_index)./ess_num_cell; % volts

ess_soc_rint_index      = ess_soc_voc_index;					% no units
ess_rint_map            = polyval([0.1418],ess_soc_rint_index)./ess_num_cell;			% ohms
  
ess_soc_rc_index        = ess_soc_voc_index;						% no units
ess_rc_map              = polyval([-0.1772,0.1418],ess_soc_rc_index)./ess_num_cell;	% ohms

ess_soc_tau_index       = ess_soc_voc_index;						% no units
ess_tau_map             = polyval([2,6,6],ess_soc_tau_index);		% ohms

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_map));%per cell
