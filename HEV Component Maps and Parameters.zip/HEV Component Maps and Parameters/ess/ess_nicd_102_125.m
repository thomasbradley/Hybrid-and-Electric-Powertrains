%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nicd_102_125.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% NiCd model battery102Ah and 125 elements(25 modlues of 5 elements)%
% Saft STM 5-100 6-V battery										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Testing at the University of California, Davis, 1995-1996			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/10/00 change data per module to data per cell			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 											    			%
% At C/1.1, these modules produce 33.1 Wh/kg.  Their energy  		%
% efficiency was measured at 84 to 87%.  Data includes Ah capacity, %
% and open-circuit voltage and internal resistance as a function 	%
% of SOC. C/3.75 capacity is 110 Ah.								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	    = 5;
ess_num_module				= 25;  								% value for number of modules
ess_num_cell 				= ess_num_module * ess_element_per_module;
ess_volt_min				= 5.9/ess_element_per_module;	%ess_voc(1)-ess_cap_max_map/5*ess_rint_dis_map(1);
ess_volt_max				= 6.9/ess_element_per_module;	%ess_voc(end)+ess_cap_max_map/5*ess_rint_chg_map(end);
ess_mass_module			    = 14;  								% (kg), mass of entire module(including fan,ecu,case)
ess_mass 					= ess_mass_module /ess_element_per_module;
env_temp_amb_i			    = 20;
env_air_cap				    = 1009;  % J/kgK  ave cp of air
env_temp_init_mod_i	        = 35;   	% C      initial eng cyl temp
ess_soc_min_i 			    = 0.404;
ess_soc_max_i 			    = 1.0;

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_soc_index               = [0.0667 0.167 0.33 0.5 0.667 0.833 0.967];  % SOC RANGE over which data is defined
ess_temp_index              = [0 22 40];  % % Temperature range over which data is defined(C)
ess_cap_max_map             = [   102   102   102];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb             = [   1   1   1];  % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map=[
   3.661 3.738  3.808 3.813 3.896  4.05  4.233
   3.661 3.738  3.808 3.813 3.896  4.05  4.233
   3.661 3.738  3.808 3.813 3.896  4.05  4.233
   ]/ess_element_per_module*1E-3; % (ohm)
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map=[
   3.661 3.738  3.808 3.813 3.896  4.05  4.233
   3.661 3.738  3.808 3.813 3.896  4.05  4.233
   3.661 3.738  3.808 3.813 3.896  4.05  4.233
   ]/ess_element_per_module*1E-3; % (ohm), no other data available
% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[
   6.029333 6.145583 6.258583 6.375292 6.433667 6.5325 6.8
   6.029333 6.145583 6.258583 6.375292 6.433667 6.5325 6.8
   6.029333 6.145583 6.258583 6.375292 6.433667 6.5325 6.8
	]/ess_element_per_module; % (V)
   
% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell
   
% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on				= 1;                             				% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module			= 770;                            				% J/kgK  ave heat capacity of module (estimated for NiCd)
ess_temp_reg				= 35;                            				% C      thermostat temp of module when cooling fan comes on
ess_area_mod				= 1.3*(ess_mass_module/11)^0.7;   				% --     if module dimensions are unknown, assume rectang shape and scale vs PB25
ess_area_module				= 0.2*ess_area_mod;          						% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod			= 0.01;                      						% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_therm_flow_area_module	= 0.005*ess_area_mod;    							% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk				= 2/1000;                   						% m      thickness of module case (typ from Optima)
ess_therm_case_cond			= 0.20;                 							% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air				= ess_flow_air_mod/(1.16*ess_therm_flow_area_module); % m/s  ave velocity of cooling air
ess_air_htcoef				= 30*(ess_speed_air/5)^0.8;      							% W/m^2K cooling air heat transfer coef.
ess_therm_res_on			= ((1/ess_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off			= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod			= max(ess_flow_air_mod,0.001);
ess_therm_res_on			= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_therm_flow_area_module ess_case_thk ess_therm_case_cond ess_speed_air ess_air_htcoef ess_area_mod

