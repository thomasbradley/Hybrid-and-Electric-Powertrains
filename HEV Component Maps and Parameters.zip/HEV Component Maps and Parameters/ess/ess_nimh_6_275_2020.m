%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_empty.m							    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% battery model							                            %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			:                       					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : name nomenclature = 										%
%               "ess"_ess type_Max capacity_number of elements      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module= 11;
ess_num_module			= 25;  	% value for number of modules
ess_num_cell 			= ess_num_module * ess_element_per_module;
ess_volt_min			= 11/ess_element_per_module;
ess_volt_max			= 16.5/ess_element_per_module;
ess_curr_chg_max_i   = 250;
ess_curr_dis_max_i   = 200;
ess_mass_module	   = 1.7452/11;  	% (kg), mass of a single cell
ess_mass 				= ess_mass_module/ess_element_per_module;

% Data added by A.Rousseau (ANL) to match with the current PCT (11/19/99) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
env_temp_amb_i			= 20;
env_air_cap				= 1009;   %defaults = 1009; % J/kgK  ave cp of air
env_temp_init_mod_i	= 35;   %defaults = 35;   % C      initial eng cyl temp
ess_soc_min_i 			= 0;   %between 0/1
ess_soc_max_i 			= 1;   %between 0/1


% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           =[0:.1:1];  % SOC RANGE over which data is defined
ess_temp_index          =[0 22 40];  % Temperature range over which data is defined (C)
ess_cap_max_map         =[6.35   6.35   6.35];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb         =[1 1 1];  % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index
ess_rint_dis_map        =[
   		  1.60 1.22 1.07 1.06 1.05 1.04 1.04 1.04 1.04 1.04 1.04
           1.60 1.22 1.07 1.06 1.05 1.04 1.04 1.04 1.04 1.04 1.04
           1.60 1.22 1.07 1.06 1.05 1.04 1.04 1.04 1.04 1.04 1.04]/1000/(1/3.9582);  % (ohm) - module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map        =ess_rint_dis_map;  % (ohm) - module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_voc_map             =[
         1.12 1.222 1.241 1.265 1.285 1.296 1.317 1.338 1.358 1.379 1.4
         1.12 1.222 1.241 1.265 1.285 1.296 1.317 1.338 1.358 1.379 1.4
         1.12 1.222 1.241 1.265 1.285 1.296 1.317 1.338 1.358 1.379 1.4];  % (V) - module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index

% Updated way to calculate Pmax = VocI-RI2 rather than Voc2/(4R) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_pwr_chg     = max(ess_voc_map(1,:))*ess_curr_chg_max_i - min(ess_rint_chg_map(1,:))*ess_curr_chg_max_i^2;%per cell
ess_pwr_dis     = max(ess_voc_map(1,:))*ess_curr_dis_max_i - min(ess_rint_dis_map(1,:))*ess_curr_dis_max_i^2;%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= 1;                         		        % --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module	= 830;                        				% J/kgK  ave heat capacity of module (estimated for NiMH)
ess_temp_reg			= 35;                          				% C      thermostat temp of module when cooling fan comes on
ess_area_mod			= 1.6*(ess_mass_module/11)^0.7;  				% --     if module dimensions are unknown, assume rectang shape and scale vs PB25
ess_area_module		= 2*ess_area_mod;          		% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= 0.01;                      					% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= 0.005*ess_area_mod;   					% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= 2/1000;                   					% m      thickness of module case (typ from Optima)
ess_therm_case_cond	= 0.2;                 							% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);	% m/s  ave velocity of cooling air
ess_therm_air_htcoef	= 30*(ess_speed_air/5)^0.8;      				% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod

