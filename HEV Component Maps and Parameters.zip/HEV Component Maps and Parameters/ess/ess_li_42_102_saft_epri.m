%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_li_6_75_saft.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Saft Li-ion 	6Ah battery pack									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% SAFT																%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 	Avernethy Francisco/Tom Bradley - EPRI										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	= 6;%-updated-02/19/04-ABF
ess_num_module			= 17; % value for number of modules-updated-02/19/04-ABF
ess_num_cell 			= ess_num_module * ess_element_per_module;
ess_volt_min			= 2.7;%(2.3 for peak)http://www.saft-batteries.com/120-Techno/20-10_produit.asp?sSegment=&sSegmentLien=&sSecteurLien=&secteur=&Intitule_Produit=MRliion&page=2
ess_volt_max			= 4.1;%(4.1 for peak)http://www.saft-batteries.com/120-Techno/20-10_produit.asp?sSegment=&sSegmentLien=&sSecteurLien=&secteur=&Intitule_Produit=MRliion&page=2
%max current 300 A, 30s peak (VL 41 M)
%from fritz's data max current is 200 A for 30s. model exhibits 200 A ceiling due to voltage limit.
ess_mass_module			= 8;  								% (kg), mass of a single ~6 V module-updated-02/19/04-ABF
ess_mass 				= ess_mass_module/ess_element_per_module;

% Data added by A.Rousseau (ANL) to match with the current PCT (11/19/99) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
env_temp_amb_i			= 20;
env_air_cap				= 1009;           % J/kgK  ave cp of air
env_temp_init_mod_i	    = 35;   		% C      initial eng cyl temp
ess_soc_min_i 			= 0.15;
ess_soc_max_i 			= 1.0;


% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           = [0:10:100]/100;  % SOC RANGE over which data is defined-updated-02/19/04-ABF
ess_temp_index          = [0 20	40];  % Temperature range over which data is defined (C)
ess_cap_max_map         = [38.2 43 45.1];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index-updated-02/25/04-ABF
ess_eff_coulomb         = [0.968 0.99 0.992]; % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
%-updated-02/19/04-ABF taken from 'Excel sheet from battery group meeting', sheet,'Max. power disch at 20�C','Max. power disch at 0�C  '
%Uses power curve for discharge of 200A for 30s since max power is defined by USABC as that sustainable for 30s
%Uses a formula P=2/9*(Voc^2)/R
ess_rint_dis_map=[0.006830739	0.006209962	0.005748896	0.005328032	0.005007515	0.005010413	0.005013934	0.005063606	0.005120613	0.005218212	0.005315576;
				  0.005018502	0.004849119	0.004723417	0.004570772	0.004458304	0.004484043	0.004509436	0.004580262	0.004657175	0.004732797	0.004808249;
				  0.005018502	0.004849119	0.004723417	0.004570772	0.004458304	0.004484043	0.004509436	0.004580262	0.004657175	0.004732797	0.004808249]; % (ohm)
   
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index-updated-02/25/04-ABF
% data taken from power charging charts for 0 and 20 C.  No data for 40C so 20C data is repeated
% data exists for different duration of pulse charging 1s, 10s, 30s.  Data is taken from 30s set.
ess_rint_chg_map=[0.004374,0.004079,0.003784,0.0037995,0.003815,0.004097,0.004379,0.0046555,0.004932,0.005723,0.006514;
                  0.00263,0.00245,0.00227,0.00219,0.00211,0.002175,0.00224,0.00221,0.00218,0.002445,0.00271;
                  0.00263,0.00245,0.00227,0.00219,0.00211,0.002175,0.00224,0.00221,0.00218,0.002445,0.00271];  % (ohm)

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index-updated-02/19/04-ABF
ess_voc_map=[3.321	3.386	3.489	3.55	3.588	3.626	3.682	3.775	3.843	3.909	3.991;
			 3.321	3.386	3.489	3.55	3.588	3.626	3.682	3.775	3.843	3.909	3.991;
			 3.321	3.386	3.489	3.55	3.588	3.626	3.682	3.775	3.843	3.909	3.991]; % (V)

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= 1;                             									% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module	    = 795;                            									% J/kgK  ave heat capacity of module (estimated for NiMH)
ess_temp_reg			= 20;                            									% C      thermostat temp of module when cooling fan comes on
ess_area_module		    = .032;          													% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= .07/12;                      										% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= .0011;    														% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= .001;                   											% m      thickness of module case (typ from Optima)
ess_therm_case_cond	    = 15;                 												% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);						% m/s  ave velocity of cooling air
ess_therm_air_htcoef	= 30*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod


