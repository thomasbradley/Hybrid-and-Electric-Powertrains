%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_pb_25_150.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% lead acid model battery	25Ah and 150 elements(25 modules of 6	%
% elements).Hawker Genesis 12V26Ah10EP sealed valve-regulated		%
% lead-acid (VRLA) battery.											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Testing done by Virginia Tech										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/10/00 change data per module to data per cell			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	    = 6;
ess_num_module				= 25;  									% value for number of modules
ess_num_cell 				= ess_num_module * ess_element_per_module;
ess_volt_min				= 9.5/ess_element_per_module;		    %ess_voc_map(1)-ess_cap_max_map/5*ess_rint_dis_map(1);
ess_volt_max				= 16.5/ess_element_per_module;	        %ess_voc_map(end)+ess_cap_max_map/5*ess_rint_chg_map(end);
ess_mass_module			    = 11;  									% (kg), mass of entire pack(including fan,ecu,case) divided by 40 modules
ess_mass 					= ess_mass_module /ess_element_per_module;
env_temp_amb_i			    = 20;
env_air_cap				    = 1009;         % J/kgK  ave cp of air
env_temp_init_mod_i	        = 35;   		% C      initial eng cyl temp
ess_soc_min_i 			    = 0.404;
ess_soc_max_i 			    = 1.0;

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index               = [0:.1:1];  % SOC RANGE over which data is defined
ess_temp_index              = [0 22 40];  % Temperature range over which data is defined (C)
ess_cap_max_map             = [   25   25   25];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb             = [   .9   .9   .9]; % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map=[
   40.7 37.0 33.8 26.9 19.3 15.1 13.1 12.3 11.7 11.8 12.2
   40.7 37.0 33.8 26.9 19.3 15.1 13.1 12.3 11.7 11.8 12.2
   40.7 37.0 33.8 26.9 19.3 15.1 13.1 12.3 11.7 11.8 12.2]/ess_element_per_module/1000; % (ohm)
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map=[
   31.6 29.8 29.5 28.7 28.0 26.9 23.1 25.0 26.1 28.8 47.2
   31.6 29.8 29.5 28.7 28.0 26.9 23.1 25.0 26.1 28.8 47.2
   31.6 29.8 29.5 28.7 28.0 26.9 23.1 25.0 26.1 28.8 47.2]/ess_element_per_module/1000; % (ohm)
% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[
   11.70 11.85 11.96 12.11 12.26 12.37 12.48 12.59 12.67 12.78 12.89
   11.70 11.85 11.96 12.11 12.26 12.37 12.48 12.59 12.67 12.78 12.89
   11.70 11.85 11.96 12.11 12.26 12.37 12.48 12.59 12.67 12.78 12.89]/ess_element_per_module; % (V)

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on				= 1;                             							% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module			= 660;                            							% J/kgK  ave heat capacity of module
ess_temp_reg				= 35;                            							% C      thermostat temp of module when cooling fan comes on
ess_area_module				= 0.2;                         								% m^2    total module surface area exposed to cooling air
ess_flow_air_mod			= 0.07/5;                   									% kg/s   cooling air mass flow rate across module (140 cfm=0.07 kg/s at 20 C)
ess_therm_flow_area_module	= 0.0025;                  									% m^2    cross-sec flow area for cooling air per module (10-mm gap btwn mods)
ess_case_thk				= 2/1000;                   									% m      thickness of module case
ess_therm_case_cond			= 0.20;                 										% W/mK   thermal conductivity of module case material
ess_speed_air				= ess_flow_air_mod/(1.16*ess_therm_flow_area_module); % m/s  ave velocity of cooling air
ess_therm_air_htcoef		= 30*(ess_speed_air/5)^0.8;      							% W/m^2K cooling air heat transfer coef.
ess_therm_res_on			= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off			= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod			= max(ess_flow_air_mod,0.001);
ess_therm_res_on			= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_therm_flow_area_module ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef

