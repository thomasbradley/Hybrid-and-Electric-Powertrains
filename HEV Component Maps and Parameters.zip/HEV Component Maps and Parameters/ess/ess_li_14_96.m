%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_li_14_96.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Li-Ion model battery - 14Ah - 96 elements							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 									    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%     Harold Haskins												%
%     Ford Motor Co./US Advanced Battery Consortium					%
%     Electric Vehicle Center Annex									%
%     15001 North Commerce Park										%
%     Dearborn, MI 48120											%
%     (313)845-9248													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/09/00 change data per pack to data per cell			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% USCAR PROPRIETARY: The data contained in this file is sensitive	%
%                    USCAR battery data.							%
% Assumption: all cells in a pack are in series 	 				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% constant parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_num_cell				= 96;
ess_soc_min_i 				= 0.3;							% no units
ess_soc_max_i 				= 1.0;								% no units
ess_mass 					= 83.3./ess_num_cell;			% Kg
ess_cap_coeff_corr 		    = 0.0;							% no units
ess_cap 					= 13.96*3600;					% amp-seconds
ess_volt_min			    = 3.2;
ess_volt_max			    = 3.9;

%  The usable system energy is ess_energy_max*(max_soc-min_soc)
ess_energy_max 			    = 4.79.*1000.*3600./ess_num_cell;	% joules

% tables 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_soc_voc_index           = [0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1];% no units
ess_voc_map                 = polyval([-445.248,1190.4,-1176.96,569.952,242.976],ess_soc_voc_index)./ess_num_cell; % volts

ess_soc_rint_index          = ess_soc_voc_index;% no units
ess_rint_map                = polyval([0.1034],ess_soc_rint_index)./ess_num_cell;		% ohms

ess_soc_rc_index            = ess_soc_voc_index;	% no units
ess_rc_map                  = polyval([-0.1471,0.1811],ess_soc_rc_index)./ess_num_cell;	% ohms

ess_soc_tau_index           = ess_soc_voc_index;	% no units
ess_tau_map                 = polyval([2.3,-8.8,8.7],ess_soc_tau_index);	% ohms

ess_curr_chg_max_i          = min(min(250,ess_voc_map./ess_rint_map));
ess_curr_dis_max_i          = ess_curr_chg_max_i;
ess_pwr_chg                 = max(ess_voc_map)*ess_curr_chg_max_i - min(ess_rint_map)*ess_curr_chg_max_i^2;%per cell
ess_pwr_dis                 = max(ess_voc_map)*ess_curr_dis_max_i - min(ess_rint_map)*ess_curr_dis_max_i^2;%per cell
