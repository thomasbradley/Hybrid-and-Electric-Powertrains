%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_li_6_75_saft.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Saft Li-ion 	6Ah battery pack									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% SAFT																%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	= 3;
ess_num_module			= 25;  									% value for number of modules
ess_num_cell 			= ess_num_module * ess_element_per_module;
ess_volt_min			= 3.2;
ess_volt_max			= 3.9;
ess_mass_module			= .37824*3;  								% (kg), mass of a single ~6 V module
ess_mass 				= ess_mass_module/ess_element_per_module;

% Data added by A.Rousseau (ANL) to match with the current PCT (11/19/99) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
env_temp_amb_i			= 20;
env_air_cap				= 1009;           % J/kgK  ave cp of air
env_temp_init_mod_i	    = 35;   		% C      initial eng cyl temp
ess_soc_min_i 			= 0.0;
ess_soc_max_i 			= 1.0;


% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           = [0 10 20 40 60 80 100]/100;  % SOC RANGE over which data is defined
ess_temp_index          = [0 25	41];  % Temperature range over which data is defined (C)
ess_cap_max_map         = [5.943 7.035 7.405];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb         = [0.968 0.99 0.992]; % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map=[0.0419 	0.0288 	0.0221 	0.014 	0.0145 	0.0145 	0.0162;
						0.072 	0.01515 	0.00839 	0.00493 	0.00505 	0.005524 0.005722;
						0.0535 	0.0133 	0.0082 	0.0059 	0.0059 	0.006 	0.0063]; % (ohm)
   
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map=[0.021  0.018  0.0177   0.0157  0.0138  0.0138  0.015;
						0.0124 0.0068 0.005426 0.00442 0.00463 0.00583 0.00583;
						0.0104 0.0079 0.0072   0.0064  0.0059  0.0058  0.006];% (ohm)

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[3.44  3.473 3.496 3.568 3.637 3.757 3.896;
				 3.124 3.349 3.433 3.518 3.616 3.752 3.898;
				 3.128 3.36  3.44  3.528 3.623 3.761 3.899]; % (V)

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= 1;                             									% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module	    = 795;                            									% J/kgK  ave heat capacity of module (estimated for NiMH)
ess_temp_reg			= 35;                            									% C      thermostat temp of module when cooling fan comes on
ess_area_module		    = .032;          													% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= .07/12;                      										% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= .0011;    														% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= .001;                   											% m      thickness of module case (typ from Optima)
ess_therm_case_cond	    = 15;                 												% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);						% m/s  ave velocity of cooling air
ess_therm_air_htcoef	= 30*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod

