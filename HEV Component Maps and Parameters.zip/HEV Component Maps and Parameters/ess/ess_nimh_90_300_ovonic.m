%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nimh_90_300_ovonic.m					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Ovonic NiMh model battery 28Ah and 300 elements					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Ovonic sales data via UC Davis except VOC (from ESS_NIMH93)		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% Nominal Voltage = 12V												%
% Nominal Capacity (C/3) = 90Ah									    %
% Dimensions (L * W * H) = 385mm X 102mm X 168mm					%
% Weight = 16.7kg													%
% Volume (modules only) = 6.1L										%
% Nominal Energy (C/3) = 1100 Wh									%
% Peak Power (10s pulse @ 50%DOD @ 35 deg. C) = 7.0kW				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	= 12;
ess_num_module			= 25;  									% value for number of modules
ess_num_cell 			= ess_num_module * ess_element_per_module;
ess_volt_min			= 0.7;
ess_volt_max			= 1.3;
ess_mass_module			= 11.6;  								% (kg), mass of a single ~6 V module
ess_mass 				= ess_mass_module/ess_element_per_module;
env_temp_amb_i		    = 20;
env_air_cap			    = 1009;           % J/kgK  ave cp of air
env_temp_init_mod_i	    = 21;   		% C      initial battery module temp
ess_soc_min_i 			= 0.0;
ess_soc_max_i 			= 1.0;


% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           = [0:.1:1];  % SOC RANGE over which data is defined
ess_temp_index          = [0 22 40];  % Temperature range over which data is defined (C)
ess_cap_max_map         = [90	90	90];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb         = [0.975	0.975	0.975]; % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map=[1.167 0.631	0.594	0.552	0.541	0.530	0.523	0.536	0.574	0.615	0.585
   					1.167 0.631	0.594	0.552	0.541	0.530	0.523	0.536	0.574	0.615	0.585
   					1.167 0.631	0.594	0.552	0.541	0.530	0.523	0.536	0.574	0.615	0.585]*10/1000/ess_element_per_module; % (ohm)
   
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map=fliplr(ess_rint_dis_map);% (ohm), no other data available

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[12.5 12.8 13.1 13.3 13.4 13.4 13.5 13.6 13.7 13.9 14.2;
   			 12.5 12.8 13.1 13.3 13.4 13.4 13.5 13.6 13.7 13.9 14.2;
   			 12.5 12.8 13.1 13.3 13.4 13.4 13.5 13.6 13.7 13.9 14.2]/ess_element_per_module; % (V)

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= 1;                             									% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module	    = 830;                            									% J/kgK  ave heat capacity of module (estimated for NiMH)
ess_temp_reg			= 35;                            									% C      thermostat temp of module when cooling fan comes on
ess_area_mod			= 1.6*(ess_mass_module/11)^0.7;  									% --     if module dimensions are unknown, assume rectang shape and scale vs PB25
ess_area_module		    = 2*(0.385*0.168+0.102*0.168);          											% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= 0.01;                      											% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= 0.005*2*(0.385+0.102);    												% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= 2/1000;                   											% m      thickness of module case (typ from Optima)
ess_therm_case_cond	    = 0.2;                 												% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);						% m/s  ave velocity of cooling air
ess_therm_air_htcoef	= 30*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod

