%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_pb_104_150.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% lead acid model battery	104Ah and 150 elements(25 modlues of 6	%
% elements).GNB 12-EVB-1180 valve-regulated lead-acid battery		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 	Manufacturer					    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/10/00 change data per module to data per cell			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% At C/1.1, these modules produce 33.1 Wh/kg.  Their energy 		% 
% efficiency was measured at 84 to 87%.  Data includes Ah capacity, %
% and open-circuit voltage and internal resistance as a function 	%
% of SOC.															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	= 6;
ess_num_module			= 25;  									% value for number of modules
ess_num_cell 			= ess_num_module * ess_element_per_module;
ess_volt_min			= 9.5/ess_element_per_module;		% caution, this value may be too low(compared with other lead acid batteries)
ess_volt_max			= 16.5/ess_element_per_module;
ess_mass_module			= 30;  									% (kg), mass of entire module(including fan,ecu,case)
ess_mass 				= ess_mass_module /ess_element_per_module;

% Data added by A.Rousseau (ANL) to match with the current PCT (12/19/99) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
env_temp_amb_i			= 20;
env_air_cap				= 1009;     % J/kgK  ave cp of air
env_temp_init_mod_i	    = 35;   		% C      initial eng cyl temp
ess_soc_min_i 			= 0.404;
ess_soc_max_i 			= 1.0;

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           = [0:.2:1];  % SOC RANGE over which data is defined
ess_temp_index          = [0 22 40];  % Temperature range over which data is defined (C)
ess_cap_max_map         = [   104   104   104];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb         = [   .9   .9   .9];  % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map=[
   0.0095 0.0050 0.0045 0.0041 0.0040 0.0040
   0.0095 0.0050 0.0045 0.0041 0.0040 0.0040
   0.0095 0.0050 0.0045 0.0041 0.0040 0.0040   ]/ess_element_per_module; % (ohm)
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map=[
   0.0095 0.0050 0.0045 0.0041 0.0040 0.0040
   0.0095 0.0050 0.0045 0.0041 0.0040 0.0040
   0.0095 0.0050 0.0045 0.0041 0.0040 0.0040]/ess_element_per_module; % (ohm), no other data available
% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[
   11.6 12 12.2 12.4 12.7 13
   11.6 12 12.2 12.4 12.7 13
   11.6 12 12.2 12.4 12.7 13   ]/ess_element_per_module; % (V)

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= 1;                             									% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module		= 660;                            									% J/kgK  ave heat capacity of module (typical Pb bat - from Optima)
ess_temp_reg			= 35;                            									% C      thermostat temp of module when cooling fan comes on
ess_area_mod			= (ess_mass_module/11)^0.7;   										% --     if module dimensions are unknown, assume rectang shape and scale vs PB25
ess_area_module			= 0.2*ess_area_mod;          										% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= 0.01;                      										% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= 0.005*ess_area_mod;    											% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= 2/1000;                   										% m      thickness of module case (typ from Optima)
ess_therm_case_cond		= 0.20;                 											% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);						% m/s  ave velocity of cooling air
ess_air_htcoef			= 30*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_air_htcoef ess_area_mod

