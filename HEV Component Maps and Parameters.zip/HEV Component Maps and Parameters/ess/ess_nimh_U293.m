%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nimh_U293.m					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% U293 NiMH battery                             					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: Zachary Slaton/Thomas Bradley           	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Zachary Slaton, Ford Motor Company.  All information within this  %
% document is Ford confidential.  Unauthorized use will be pros-    %
% ecuted to the fullest extent of the law.                          %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: Avernethy Francisco, Thomas Bradley		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : Comments below for entire pack, not per module			%
% Cell type =   													%
% Nominal Voltage = 340V											%
% Nominal Capacity (C/3) = 5.5Ah									%
% Dimensions (L * W * H) =                  						%
% Weight = 120         												%
% Volume (modules only) = 120L										%
% Nominal Energy (C/3) = 1.80 kWh									%
% Peak Power (10s pulse @ 50%DOD @ 35 deg. C) = 39kW				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ess_file_name           = 'ess_nimh_U293';
disp(ess_file_name)
ess_element_per_module 	= 5;                        % --    number of battery cells per module, Ford U293 Battery Model                                   
ess_num_module			= 50;  						% --    number of modules per battery pack, Ford U293 Battery Model
ess_num_cell 			= ess_num_module * ess_element_per_module;  % --    number of battery cells per pack
ess_volt_min			= 4.32/5;                   % V     minimum battery voltage per cell, Ford U293 Battery Model
ess_volt_max			= 7.94/5;                   % V     maximum battery voltage per cell, Ford U293 Battery Model
ess_mass_module		    = 1.8;  					% kg    mass of a single ~6.8 V module, Ford U293 Battery Model
ess_mass 				= ess_mass_module/ess_element_per_module;   %kg mass of a single battery cell, will be mutiplied by ess_num_cell to get pack mass
env_air_cap				= 1009;                     % J/kgK heat capacity of ambient air
env_temp_init_mod	    = 19.9;   				    % C     initial module temperature
ess_soc_min_i 			= 0.0;                      % --    minimum battery state of charge (SOC)
ess_soc_max_i 			= 1;                      % --    maximum battery state of charge

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           = [0.2:.1:0.9];                 % --    SOC RANGE over which data is defined
ess_temp_index          = [-35 -15 5 25 45];            % C     Temperature range over which data is defined
ess_cap_max_map         = [5.5 5.5 5.5 5.5 5.5];	    % A*hrs max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb         = [0.99	0.99 0.99 0.99 0.99];   % --    average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index, Ford U293 Battery Model 
ess_rint_dis_map        = [ 0.144479546	0.138431641	0.134936363	0.132637847	0.131184773	0.130856316	0.132672902	0.139005103
                            0.069211907	0.066314701	0.064640313	0.063539225	0.06284314	0.062685795	0.063556018	0.066589414
                            0.030579832	0.029299762	0.028559969	0.028073476	0.027765926	0.027696406	0.028080896	0.029421139
                            0.016333705	0.015649977	0.015254829	0.014994977	0.014830704	0.014793572	0.01499894	0.015714808
                            0.014223912	0.0136285	0.013284392	0.013058104	0.01291505	0.012882714	0.013061556	0.013684956]/ess_element_per_module; % ohm    
   
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map        = (ess_rint_dis_map);% ohm, no other data available

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index, Ford U293 Battery Model
ess_voc_map             = [ 6.220122932	6.291708027	6.334890727	6.368889126	6.400554988	6.434335812	6.480842099	6.581732297
                            6.220122932	6.291708027	6.334890727	6.368889126	6.400554988	6.434335812	6.480842099	6.581732297
                            6.220122932	6.291708027	6.334890727	6.368889126	6.400554988	6.434335812	6.480842099	6.581732297
                            6.220122932	6.291708027	6.334890727	6.368889126	6.400554988	6.434335812	6.480842099	6.581732297
                            6.220122932	6.291708027	6.334890727	6.368889126	6.400554988	6.434335812	6.480842099	6.581732297]/ess_element_per_module; % V

% Updated way to calculate Pmax = VocI-RI2 rather than Voc2/(4R) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max_i      = min(min(min(90,ess_voc_map(4,:)./ess_rint_chg_map(4,:))));
ess_curr_dis_max_i      = min(min(min(180,ess_voc_map(4,:)./ess_rint_dis_map(4,:))));
ess_pwr_chg             = max(ess_voc_map(4,:))*ess_curr_chg_max_i - min(ess_rint_chg_map(4,:))*ess_curr_chg_max_i^2;   %per cell
ess_pwr_dis             = max(ess_voc_map(4,:))*ess_curr_dis_max_i - min(ess_rint_dis_map(4,:))*ess_curr_dis_max_i^2;   %per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on					= 0;                             									    % --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module 			= 40e3/ess_num_module;   												% J/K	heat capacity of pack, Ford CDA #2660

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% variable geometry battery model %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_area_module					= 2*(0.275*0.106 + 0.0196*0.106)*5/6*5.5/6.5;					        % m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod_ambient		= 67.5*0.0283*1.2/60;        											% kg/s   cooling air mass flow rate across module from ambient air cooling
ess_flow_air_mod		        = 67.5*0.0283*1.2/60;        											% kg/s   cooling air mass flow rate across module from ambient air cooling%			(20 cfm=0.01 kg/s at 20 C), Ford CDA #2660
ess_flow_air_mod_AC				= 110*0.0283*1.2/60;         											% kg/s   cooling air mass flow rate across module from air conditioned cooling
																														% 			(20 cfm=0.01 kg/s at 20 C), Ford CDA #2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% U293 specific battery model %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
ess_therm_res_on_ambient		= 1/20; 						% K/W  tot thermal res key on, with ambient cooling, Ford CDA 2660
ess_therm_res_on        		= 1/20; 						% K/W  tot thermal res key on, with ambient cooling, Ford CDA 2660
ess_therm_res_on_AC				= 1/30;		 					% K/W  tot thermal res key on, with air conditioned cooling, Ford CDA 2660
ess_therm_res_off				= 1/40;
ess_therm_cp_pack  				= 40e3;							% J/K	heat capacity of pack, Ford CDA #2660
ess_temp_amb_AC                 = 12;                     	    % C     temperature of the inlet air to the pack under air cond. cooling, Ford CDA 2660
ess_temp_reg                    = 25
ess_temp_control_hyst           = 3;                            % C     temperature hysteresis for battery pack cooling control
ess_temp_control_amb_on     	= 27;                           % C     pack temperature at which ambient cooling turns on 
ess_temp_control_oppAC_on   	= 30;   			            % C     pack temperature at which opportunistic AC turns on 
ess_temp_control_nonoppAC_on	= 38;                         	% C     pack temperature at which non-opportunistic AC turns on
ess_ambient_control_oppAC_on	= 20;                           % C     ambient air temperature at which non-opportunistic AC turns on 
ess_cool_system_tau             = 5;                            % sec   time constant of the air supply system to the battery pack

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod
%disp('... Done')

