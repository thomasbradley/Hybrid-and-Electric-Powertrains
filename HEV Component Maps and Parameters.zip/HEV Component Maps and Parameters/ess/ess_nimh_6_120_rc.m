%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nimh_6_120_rc.m						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: B.Deville (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% Assumption: all cells in a pack are in series 	 				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_num_cell 			= 120;
ess_soc_min_i 			= 0.3;
ess_soc_max_i 			= 0.97;
ess_volt_min				= 1;		% 1 volt time the number of cells
ess_volt_max				= 1.5;	%1.5 volt times the number of cell
ess_mass 				= 75.9 / ess_num_cell;
ess_cap_coeff_corr 	    = 0.0;
ess_cap 				= 6.0*3600;						% amp-seconds

% The usable system energy is ess_bt_rated_energy*(max_soc-min_soc)
ess_energy_max 		    = 4.51 * 1000 * 3600 / ess_num_cell;% joules

ess_soc_voc_index 	    = [0,0.2,0.4,0.6,0.8,1];
ess_voc_map 			= [145.65 151.3 153.95 155.72  158.14  168.64] / ess_num_cell;% volts

ess_soc_rint_index 	    = ess_soc_voc_index;
ess_rint_map 			= [0.7621    0.5261    0.4421    0.3937    0.3359    0.1687] / ess_num_cell;

ess_soc_rc_index 		= ess_soc_voc_index;
ess_rc_map 				= polyval([-0.1772,0.1418],ess_soc_rc_index)*6.2 / ess_num_cell;% ohms

ess_soc_tau_index 	    = ess_soc_voc_index;
ess_tau_map 			= polyval([2,6,6],ess_soc_tau_index);% ohms

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_map));%per cell
