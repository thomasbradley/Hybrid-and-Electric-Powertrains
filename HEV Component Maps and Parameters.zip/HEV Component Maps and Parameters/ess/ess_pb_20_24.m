%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_pb_20_24.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Lead Acid model battery											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%     Tom Kenney and Corey Weaver									%
%		Ford Research Laboratory									%
%		Ford Motor Company											%
%		P.O. 2053/MD 2629/SRL										%
%     Dearborn, MI 48121-2053										%
%     (313)322-5234													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% Xi Wei - 08/09/00 change data per pack to data per cell			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
% Assumption: all cells in a pack are in series 	 				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% constant parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_element_per_module = 6;
ess_num_cell		   = 24;
ess_cap_coeff_corr     = 0.004; 									% no units  
ess_cap  			   = 20*3600;									% amp-seconds	
ess_soc_min_i 	       = 0;% no units
ess_soc_max_i 	       = 1;% no units
ess_volt_min           = 9.5/ess_element_per_module;		    %ess_voc_map(1)-ess_cap_max_map/5*ess_rint_dis_map(1);
ess_volt_max           = 16.5/ess_element_per_module;	        %ess_voc_map(end)+ess_cap_max_map/5*ess_rint_chg_map(end);
ess_mass 			   = 1.8;										% Kg
ess_pwr_dens 		   = 200;										% W/Kg ; ess_pwr_dens = ess_pwr_max ./ ess_mass;
ess_energy_dens 	   = 22.8;										% Wh/Kg ; ess_energy_dens = ess_energy_max ./ ess_mass ./ 3600;

% The usable system energy is ess_energy_max*(max_soc-min_soc)
ess_energy_max 		= 6.0192*1000*3600/ess_num_cell;	% joules

% tables
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_soc_voc_index 	= [0,.1,.2,.3,.4,.5,.6,.7,.8,.9,1];% no units
ess_voc_map 	    = [316,320,323,327,331,334,337,340,342,345,348]./27;% volts

ess_soc_rint_index 	= ess_soc_voc_index;% no units
ess_rint_map        = [.9768, .9018, .8539, .7303, .6378, .5672, .4880,.5048, .5104, .5484, .8016]./27; % ohms

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_map));%per cell
