%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_nimh_45_300_ovonic.m					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Ovonic NiMh model battery 28Ah and 300 elements					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: Dr. Claus Schmitz, System Technology 												%
						% VARTA Automotive GmbH
						% Advanced Systems -
						% Am Leineufer 51
						% 30419 Hannover
						% Tel.: +49 511 975 1802; FAX -1801
	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 	Thomas Bradley - EPRI										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	    = 12;
ess_num_module				= 24;  									% value for number of modules
ess_num_cell 				= ess_num_module * ess_element_per_module;
ess_volt_min				= 0.7;
ess_volt_max				= 1.6;
ess_mass_module			    = 8.4;  								% (kg), mass of a single ~6 V module
ess_mass 					= ess_mass_module/ess_element_per_module;
env_temp_amb_i			    = 20;
env_air_cap				    = 1009;           % J/kgK  ave cp of air
env_temp_init_mod_i	        = 35;   		% C      initial eng cyl temp
ess_soc_min_i 			    = 0.0;
ess_soc_max_i 			    = 1.0;

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index               = [0:.1:1];  % SOC RANGE over which data is defined
ess_temp_index              = [0 22 40];  % Temperature range over which data is defined (C)
ess_cap_max_map             = [40	40	40];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb             = [0.975	0.975	0.975];  % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% cell's resistance to being discharged, indexed by ess_soc_index and ess_temp_index, from Varta
ess_rint_dis_map = [0.001646760   0.0015831520   0.0015195440   0.0014559360   0.0014191750   0.0013950   0.0013797180 0.0013762630   0.0013953690   0.0014619670   0.0015285650
0.001646760   0.0015831520   0.0015195440   0.0014559360   0.0014191750   0.0013950   0.0013797180 0.0013762630   0.0013953690   0.0014619670   0.0015285650
0.001646760   0.0015831520   0.0015195440   0.0014559360   0.0014191750   0.0013950   0.0013797180 0.0013762630   0.0013953690   0.0014619670   0.0015285650]; %(ohm);

% cell's resistance to being charged, indexed by ess_soc_index and ess_temp_index, from Varta
ess_rint_chg_map = [0.00189   0.00182   0.001742262   0.001669331   0.001627182   0.001599464   0.001581942 0.001577981   0.0015998870   0.001676246   0.001750
0.00189   0.00182   0.001742262   0.001669331   0.001627182   0.001599464   0.001581942 0.001577981   0.0015998870   0.001676246   0.001750
0.00189   0.00182   0.001742262   0.001669331   0.001627182   0.001599464   0.001581942 0.001577981   0.0015998870   0.001676246   0.001750];% (ohm)

% cell's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index, from Varta
ess_voc_map=[   1.210666667	1.239333333	1.268	1.296666667	1.325333333	1.354	1.382666667	1.411333333	1.44	1.468666667	1.497333333
				1.210666667	1.239333333	1.268	1.296666667	1.325333333	1.354	1.382666667	1.411333333	1.44	1.468666667	1.497333333
				1.210666667	1.239333333	1.268	1.296666667	1.325333333	1.354	1.382666667	1.411333333	1.44	1.468666667	1.497333333]; % (V)

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= 0;                             									% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module	    = 830;                            									% J/kgK  ave heat capacity of module (estimated for NiMH)
ess_temp_reg			= env_temp_amb_i + 5;                            									% C      thermostat temp of module when cooling fan comes on
ess_area_mod			= 1.6*(ess_mass_module/11)^0.7;  									% --     if module dimensions are unknown, assume rectang shape and scale vs PB25
ess_area_module		    = 2*(0.340*0.135+0.074*0.135);          											% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= 0.01;                      											% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= 0.005*2*(0.340+0.074);    												% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= 2/1000;                   											% m      thickness of module case (typ from Optima)
ess_therm_case_cond	    = 0.2;                 												% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);						% m/s  ave velocity of cooling air
ess_therm_air_htcoef	= 30*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod

