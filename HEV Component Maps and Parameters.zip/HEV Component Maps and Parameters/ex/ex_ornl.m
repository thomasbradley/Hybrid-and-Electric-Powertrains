%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ex_ornl.m												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: initialize the parameters used in the		%
% 3 way catalyst Exhaust Aftertreatment										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: P.Sharer (ANL)									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: ORNL															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 																			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EXHAUST GAS HEAT FLOW
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ex_gas_cp = 1089;

%Manifold
ex_cat_mon_sarea=0.1*(eng_pwr_max/1000/100)^0.67; % m^2  outer surface area of cat monolith (approx. 0.1 m^2/100 kW)
ex_cat_monf_sarea=ex_cat_mon_sarea/4;       % m^2  surface area of cat monolith front face
ex_cat_moni_sarea=ex_cat_mon_sarea*50;      % m^2  inner (honeycomb) surf area of cat monolith

%Interior
ex_cat_int_sarea=ex_cat_mon_sarea*1.3;   % m^2  surface area of cat interior

%Pipe 
ex_cat_pipe_sarea=ex_cat_mon_sarea/2;    % m^2  surface area of cat i/o pipes

%Exterior
ex_cat_ext_sarea=ex_cat_mon_sarea*1.4;   % m^2  surface area of cat ext shield

%Inlet Pipe
ex_cat_pipe_sarea = 1;

%Manifold
ex_man2cat_length=0.7;                   % m    length of exhaust pipe between manifold and cat conv
ex_manif_sarea=(eng_pwr_max/1000/600)*(0.3+ex_man2cat_length);    % m^2  surface area of manif & downpipe: pi*D*L

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EXHAUST SYSTEM HEAT FLOW
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Heat Transfer
%(pipe and interior) to monolith
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Radiation: Pipe to Monolith
ex_cat_m2p_emisv = 0.1;
%Condunction: Interior to Monolith
ex_cat_m2i_tmp=[-40 97 344 1200];                % C     corresponding temperature vector
ex_cat_m2i_th_cond=[0.7 1.3 2.65 6.5]*0.1/0.003 ; % W/K   cond btwn CERAMIC mono & int (from SAE#880282)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Heat Transfer
%(pipe and exterior) to interior
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Radation: Exterior to Interior
ex_cat_i2x_emisv=0.5;       %emissivity from cat int to cat ext shield
%Conduction: Exterior to Interior
ex_cat_i2x_th_cond   =1.0;   % W/K    conductance btwn cat int & ext
%Conduction: Pipe to Interior
ex_cat_i2p_th_cond   =0.2;    % W/K    conductance btwn cat int & pipe
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Heat Transfer
%Pipe to Air
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Radiation: Pipe to Air
ex_cat_pipe_emisv=0.7;      %        emissivity of cat i/o pipe
%Convection: Pipe to Air
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Heat Transfer
%Exterior to (Air and Pipe)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Conduction: Exterior to Pipe
ex_cat_p2x_th_cond   =0.02;  % W/K conductance btwn cat pipe & ext
%Radiation: Exterior to Air
ex_cat_ext_emisv=0.7;       %emissivity of cat ext shield
%Convection: Exterior to Air
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Heat Transfer
%Manifold to Air
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Convection: Manifold to Air
%Radiation: Manifold to Air
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_mass=0.3*eng_pwr_max/1000; 
ex_cat_mass=ex_mass*0.36; 

%TEMPERATURE CALCULATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Inital Temperatures
ex_cat_mon_init_tmp_i = 20;
ex_cat_int_init_tmp_i = 20;
ex_cat_pipe_init_tmp_i = 20;
ex_cat_ext_init_tmp_i = 20;
ex_manif_init_tmp_i = 20;

%Monolith Mass and Heat Capacity
ex_cat_mon_cp = 1070;
ex_cat_mon_mass = ex_cat_mass*0.22;


%Interior Mass and Heat Capacity
ex_cat_int_mass =  ex_cat_mass*0.33;
ex_cat_int_cp = 460;

ex_cat_pcm_mass = 0;

ex_cat_pcm_tmp  = [-100 1200]; % C   temp range for cat pcm ecp vec
ex_cat_pcm_ecp  = [0 0];      % J/kgK  ave eff heat cap of pcm (latent + sens)

%Pipe Mass and Heat Capacity
ex_cat_pipe_mass = 460;
ex_cat_pipe_cp =  ex_cat_mass*0.17;

%Exterior Mass and Heat Capacity
ex_cat_ext_cp = 460;
ex_cat_ext_mass =  ex_cat_mass*0.28;

%Manifold Mass and Heat Capacity
ex_manif_cp = 460;
ex_manif_mass = ex_mass*0.20;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%HC Conversion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% term1 = ((G1*Flow)^ex1) * e^(G2/temp) * G3)^ex2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_equ_hc_gain1 = 1;
ex_equ_hc_exp1 = 0.6436;

ex_equ_hc_gain2 = -2171;
ex_equ_hc_gain3 = 5.818;

ex_equ_hc_exp2 = -10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% term2 = (G5*e^(G4/temp))^ex3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_equ_hc_gain4 = -10956;
ex_equ_hc_gain5 = 3.731E11;
ex_equ_hc_exp3 = -10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%term3 = (term1 + term2)^ex4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_equ_hc_exp4  = -0.1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%1 - e^(((term3 * (O2_flow/air_flow)*air_mol_wght)/air_flow)*G6)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
env_air_mol_wght = 0.90475;
ex_equ_hc_gain6 = -3600;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%CO Conversion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ex_equ_co_exp1 = 0.6213;
ex_equ_co_gain1 = 0.3702;

ex_equ_co_gain2  = -16222;
ex_equ_co_gain3 = 7.989E16;

ex_equ_co_exp2 = -0.5;

ex_equ_co_gain4  = -3600;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NOx Conversion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_equ_nox_gain1  = 1;
ex_equ_nox_gain2  = 2.875;

ex_equ_nox_A0  = -1.2477959e2;
ex_equ_nox_A05 = 8.308073E-2;
ex_equ_nox_A1 = -6.671239E-4;
ex_equ_nox_A2 = 7.9852675E-9;
ex_equ_nox_A3 = -3.7023358E-14;

ex_equ_nox_B05 = 4.9229015e3;
ex_equ_nox_B1 = -5.4929168E4;
ex_equ_nox_B2 = 2.959987e6;
ex_equ_nox_B3 = -1.022441e8;

ex_equ_nox_C05 = -1.7874225E1;
ex_equ_nox_C1 = 1.3710201E1;
ex_equ_nox_C2 = -2.0607707;
ex_equ_nox_C3 = 1.3883777E-1;

ex_equ_nox_gain3 = 0.01;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%PM Conversion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_cat_tmp_range = [-100 1200]; % (deg. C)
ex_cat_pm_frac = [.98 .98];	%Diesel Particulate Filter (DPF)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Catalyst Saturation Limits
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_hc_cat_lim = 1.25;
ex_co_cat_lim = 17.0;
ex_nox_cat_lim = 2.0;
ex_pm_cat_lim = 0.4;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
