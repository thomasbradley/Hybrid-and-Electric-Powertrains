%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ex_ot_1.m												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: initialize the parameters used in the		%
% Exhaust Aftertreatment															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: A.Rousseau (ANL)									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : CON_INI												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 																				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ex_on_temp_i_p 	    = 220;	%catalyst ligth-off temperature in Degrees Celcius
ex_temp_hot_i_p	    = 350;	%temperature constant
ex_t_hot_i_p 		= 60;		% time to reach light off (seconds)
ex_t_cold_i_p 		= 3600;	% time to cool down (seconds)
ex_pm_eff_i_p 		= .9;		% Particulate trap efficiency
ex_mass 			= 3.5;

% Catalyst Data-preliminary internal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ex_temp_eff_index 	= [100:20:360];% Catalyst temperature (degrees Celcius)
% Efficiency Tables (HC, CO)
ex_hc_eff_map = [0.0,0.0,0.0,0.01,0.05,0.16,0.42,0.68,0.80,0.83,0.84,0.84,0.84,0.84];
ex_co_eff_map =[0.0,0.0,0.0,0.01,0.05,0.18,0.46,0.73,0.86,0.90,0.91,0.91,0.91,0.91];
