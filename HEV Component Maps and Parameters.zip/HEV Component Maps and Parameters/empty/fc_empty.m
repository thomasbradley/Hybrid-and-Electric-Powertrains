%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: fc_empty.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: DIRECT HYDROGEN FUEL CELL     		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: S.Buyuktur - ANL						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: Dr. Romesh Kumar, Argonne National Lab	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% 	(1)	A.Rousseau (ANL) - 01/24/00 - delete all the parameter		%
% 			scaling_ratio that is useless in the initialization file%
%	(2)	G.Monnet - 01/24/00 - Separation, fuel cell and fuel cell.	%
%		acessories initialisation file(deleting all the accesories 	%
%			parameters)												%
% 	(3)Xi Wei - 08/02/00 - maximum power and efficiency calculation	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fc_tau_i_p    			= xx;                  %  transient load delay for first order lag
fc_spd_launch 			= xx;                    % not used this phase
fc_temp_tau_hot_i_p     = xx;
fc_temp_tau_cold_i_p	= xx;
fc_warmup_init_i_p 	    = xx;
accmech_mass 			= xx;
fc_mass       			= xx; 
fc_mass_vol 			= xx;						% Capacity of tank in kg

% Only here to satisfy dependencies in other models.  
eng_spd_idle       			= xx;  %temporary for sft
fc_displ_init     	    = xx; 
fc_spd_opt_i_p          = xx;
fc_fuel_carbon_ratio    = xx;
fc_co2_init 			= xx;

% Define the following variable to satisfy the series power controller's dependency on an optimal point
fc_pwr_opt 				= xx ; % from the tables provided by ANL, max eff; W (7/7/00)

% Fuel Parameters 
fc_fuel_density_val     = xx;            % kg/m3 or g/L
fc_fuel_heating_val   = xx;     % J/kg; specific LHV of Hydrogen
fc_fuel_carbon_ratio = xx;              % since fuel is H2, this for

% Hot power
fc_pwr_hot_index   	= [ xx] * 1000; % W
fc_pwr_hot_max 		= max(fc_pwr_hot_index);           % Max DC power of fuel cell, W
fc_h2_hot_map 		= [xx] /1000;             % kg/s;

% Cold power
fc_pwr_cold_index   = [ xx] * 1000;          % W
fc_pwr_cold_max 	= max(fc_pwr_cold_index); % Max DC power of fuel cell, W
fc_h2_cold_map 		= [ xx ] /1000;           % kg/s converted from g/s;

% Polarization Curves
fc_stck_curr_hot_index 	= [ xx];      % A
fc_stck_volt_hot_map 	= [xx];           % V
fc_stck_curr_cold_index = [ xx ]; 
fc_stck_volt_cold_map 	= [xx];

% Power vs Voltage values                             % <------------- from data provided by ANL (10/04/00 - Selim)
fc_power_index 		= [xx]* 1000;                % W
fc_ucell_volt_map 	= [xx];        % V/cell 
fc_nb_cell 			= xx;  % later put it in the test file (fc_nb_cell = gui_*)

fc_h2_hot_max       = max(fc_h2_hot_map) ; % Direct hydrogen PEM fuel cell warmup factors
fc_mass 			= 1.6*fc_pwr_hot_max/1000 ;     %1.6 kg/kW
fc_pwr_max			= max(fc_pwr_hot_index);% maximum power calculation

% Hot accessory power
accmech_pwr_hot_pump     	  = [xx ] *1000;   % W; pump/fan
accmech_pwr_hot_compressor    = [xx ] *1000;   % W; compressor
accmech_pwr_hot_expander      = [xx ] *1000;   % W; expander
accmech_pwr_hot_radiator      = [ xx ] *1000;   % W; radiator duty

% Cold accesory power
accmech_pwr_cold_pump 			= [ xx]*1000;       	% W; pump/fan
accmech_pwr_cold_compressor	    = [ xx]*1000;        % W; compressor
accmech_pwr_cold_expander		= [xx ]*1000;        % W; expander
accmech_pwr_cold_radiator		= [ xx]*1000;        % W; radiator by-passed

%calculate the maximum efficiency
eff_hot=fc_pwr_hot_index/fc_fuel_heating_val./fc_h2_hot_map;
eff_cold=fc_pwr_cold_index/fc_fuel_heating_val./fc_h2_cold_map;
idx=find(eff_hot<0); eff_hot(idx)=0;
idx2=find(eff_cold<0); eff_cold(idx2)=0;
fc_eff_max=max(max(eff_hot));

clear idx idx2

