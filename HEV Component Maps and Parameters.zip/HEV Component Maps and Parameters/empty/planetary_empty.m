%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: planetary_empty.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: 										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: 	P.Sharer							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:									        %   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 	This planetary gear is designed for 4wd split.          %
%The addition of the transfer case requires a change in the ratios  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initialization of Planetary
tx_inertia_sun     	= xx;    % kgm^2
tx_inertia_carrier 	= xx;    % kgm^2
tx_inertia_ring    	= xx;    % kgm^2
tx_sun_nb_teeth		= xx;   
tx_ring_nb_teeth	= xx;  
tx_ratio_i_p     	= tx_sun_nb_teeth/tx_ring_nb_teeth; % sun radius to ring radius
tx_spd_ring_init 	= xx;
tx_spd_sun_init    	= xx; % init sun speed (rad/sec)
tx_spd_planet_init  = xx;  % init planet speed  (rad/sec)
tx_mass             = xx;

Jp  = xx;
mp  = xx;      %mass of planets
Np  = xx;        % number of planets
   
   
   

   