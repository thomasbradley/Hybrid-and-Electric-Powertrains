%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ex_empty.m												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description				: initialize the parameters used in the		%
%  catalyst Exhaust Aftertreatment										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 				: A.Rousseau (ANL)									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : CON_INI												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 																			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ex_temp_hot_i_p	    = xx;	% temperature constant
ex_on_temp_i_p		= xx; 	% catalyst ligth-off temperature in Degrees Celcius
ex_t_hot_i_p 		= xx;		% time to reach light off (seconds)
ex_t_cold_i_p		= xx;	% time to cool down (seconds)
ex_mass 			= xx;

% Catalyst Data-preliminary internal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ex_temp_eff_index 	= [xx];% Catalyst temperature (degrees Celcius)
ex_flow_coeff 		= [xx];% Exhaust equivalence ratio

% Efficiency Tables (HC, CO, NOx)
ex_hc_eff_map =...
		[xx];

ex_co_eff_map =...
		[xx];

ex_nox_eff_map =...
		[xx];

