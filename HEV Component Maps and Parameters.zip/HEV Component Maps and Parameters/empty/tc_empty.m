%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tc_empty.m									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% reduction bloc													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 11/05/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% A.Rousseau (ANL) - 11/17/99 - add the axl1 loss table calculation	%
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tc_ratio_i_p 		= xx;
tc_inertia_i_p 	    = xx;
tc_mass 			= xx;
tc_spd_thresh_i 	= xx;

tc_trq_eff_index    = [xx];
tc_spd_eff_index    = [xx];
tc_eff_trq_map      = ones(size(tc_trq_eff_index,2),size(tc_spd_eff_index,2)).*xx;

tc_trq_loss_index   = tc_trq_eff_index;
tc_spd_loss_index   = tc_spd_eff_index;
tc_trq_loss_map     =  zeros(length(tc_trq_loss_index), length(tc_spd_loss_index));

% create axle1 drive loss tables
for i=1:size(tc_trq_loss_index,2)
   for j=1:size(tc_spd_loss_index,2)
      tc_trq_loss_map(i,j) = (1-tc_eff_trq_map(i,j))*tc_trq_loss_index(i);
   end
end

% calculate the maximum efficiency 
tc_eff_max=max(max(tc_eff_trq_map));
