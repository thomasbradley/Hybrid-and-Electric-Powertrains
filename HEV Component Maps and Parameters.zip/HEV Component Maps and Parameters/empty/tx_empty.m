%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_empty.m						    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% automatic transmission											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 10/06/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files :                       					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% A.Rousseau (ANL)- 10/06/99 - simplification of the variable names	%
% A.Rousseau (ANL)- 10/13/99 - creation of a special file for the   %
% torque converter.													%
% A.Rousseau (ANL)- 10/20/99 - delete the variables dtr_eff2_torque	%
% and dtr_eff2_speed because they were only renamed variables		
% A.Rousseau (ANL) - 11/05/99 - modifed variable dtr_config_switch	%
% (0/1 initialy) .This parameter has now 4 values					%
% A.Rousseau (ANL) - 11/15/99 - del dtr_config_switch3 not use 		%
% anymore															%
% A.Rousseau (ANL) - 11/16/99 - move all the shift laws in dedicated%
% files and create specific files for each gearbox speed number		%
% A.Rousseau (ANL) - 11/17/99 -add the torque loss table calculation%
% C. Kwon (ANL) - 03/10/2000 - add "0" for the gear number and gear %
% ratio for the neutral
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear tx_trq_loss_map

tx_inertia_in_i_p 	    = xx;			% kg m^2
tx_inertia_out_i_p 	    = xx;				% kg m^2
tx_mass  				= xx;		%kg
tx_spd_thr_i 			= xx;
tx_nb_ratio             = xx;

tx_gear_index= [xx];
tx_ratio_map = [xx];  

tx_trq_eff_index = [xx];% input trq in Nm
tx_spd_eff_index = [xx];% input speeds in rd/s

tx_eff_trq_ratio1_map = ...		% Gear1 Efficiencies
[xx];
 

tx_eff_trq_ratio3_map = ...		% Gear3 Efficiencies
[xx]; 

tx_eff_trq_ratio5_map = ...		% Gear5 Efficiencies
[xx];

tx_eff_trq_ratio7_map = ...		% Gear7 Efficiencies
[xx];

tx_eff_trq_ratio9_map = ...		% Gear9 Efficiencies
[xx];

tx_eff_trq_ratio2_map = (tx_eff_trq_ratio1_map + tx_eff_trq_ratio3_map)/2;
tx_eff_trq_ratio4_map = (tx_eff_trq_ratio3_map + tx_eff_trq_ratio5_map)/2;
tx_eff_trq_ratio6_map = (tx_eff_trq_ratio5_map + tx_eff_trq_ratio7_map)/2;
tx_eff_trq_ratio8_map = (tx_eff_trq_ratio7_map + tx_eff_trq_ratio9_map)/2;
tx_eff_trq_ratio10_map = tx_eff_trq_ratio9_map;

% calculate the torque losses
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_trq_loss_index = tx_trq_eff_index;
tx_spd_loss_index = tx_spd_eff_index;
tx_coeff = tx_trq_eff_index(:)*ones(1,length(tx_spd_eff_index));
for cpt=1:tx_nb_ratio,
    eval(['tx_trq_loss_ratio',num2str(cpt),'_map = (1 - tx_eff_trq_ratio',num2str(cpt),'_map) .* tx_coeff;']);%calculate trq loss per ratio
    tx_trq_loss_map(:,:,cpt) = eval(['tx_trq_loss_ratio',num2str(cpt),'_map']);%create the 3 dimensions (trq, spd, ratio) map for trq loss
end

% calculate the maximum efficiency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for cpt=1:tx_nb_ratio,
   tx_eff(cpt)=max(max(eval(['tx_eff_trq_ratio',num2str(cpt),'_map'])));
end
tx_eff_max=max(tx_eff);
clear cpt