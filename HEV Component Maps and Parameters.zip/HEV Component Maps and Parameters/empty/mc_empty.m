%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_empty.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			:  data file for the Solectria ACgtx20/AC300%
% AC induction motor/controller. 						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 									    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_inertia_i_p 		    = xx; %unknown
mc_coeff_regen_i_p 	    = xx;
mc_volt_min_i			= xx; % (V), minimum voltage allowed by the controller and motor
mc_tau_i_p				= xx; % from 0 to 100 % of the torque in 50 ms
mc_t_max_trq            = xx; % Time the motor can remain at max torque
mc_mass 				= xx;% sum of motor and controller mass																		
mc_curr_max				= xx; % (A), maximum current allowed by the controller and motor
mc_spd_base 			= xx * c_rpm_radps;% rad/s

mc_spd_cont_index 	    = [xx]* c_rpm_radps;
mc_trq_cont_map 	    = [xx];

mc_spd_max_index 	    = [xx]* c_rpm_radps;
mc_trq_max_map 	        = xx.*mc_trq_cont_map;

mc_spd_eff_index 	    = [xx]* c_rpm_radps;
mc_trq_eff_index 	    = [xx];
mc_eff_trq_map 		    = [xx];

mc_pre_calculation

%Convert the above data to electrical power lost

%evaluatefile('mc1_pre_calculation','mc1_','mc_')