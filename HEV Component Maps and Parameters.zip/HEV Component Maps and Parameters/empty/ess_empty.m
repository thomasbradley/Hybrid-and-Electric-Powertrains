%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: ess_empty.m					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
%  battery 					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A. Rousseau (ANL) - 12/07/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Dennis Corrigan, Vice President of EV Battery Systems, Ovonic		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_element_per_module 	= xx;
ess_num_module			= xx;  									% value for number of modules
ess_num_cell 			= ess_num_module * ess_element_per_module;
ess_volt_min			= xx;
ess_volt_max			= xx;
ess_mass_module			= xx;  								% (kg), mass of a single ~6 V module
ess_mass 				= ess_mass_module/ess_element_per_module;
env_temp_amb_i			= xx;
env_air_cap				= xx;           % J/kgK  ave cp of air
env_temp_init_mod_i	    = xx;   		% C      initial eng cyl temp
ess_soc_min_i 			= xx;
ess_soc_max_i 			= xx;

% LOSS AND EFFICIENCY parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ess_soc_index           = [0:.1:1];  % SOC RANGE over which data is defined
ess_temp_index          = [xx];  % Temperature range over which data is defined (C)
ess_cap_max_map         = [xx];	% (A*h), max. capacity at C/5 rate, indexed by ess_temp_index
ess_eff_coulomb         = [xx];  % average coulombic (a.k.a. amp-hour) efficiency below, indexed by ess_temp_index

% module's resistance to being discharged, indexed by ess_soc_index and ess_temp_index
ess_rint_dis_map=[xx]/ess_element_per_module; % (ohm)
   
% module's resistance to being charged, indexed by ess_soc_index and ess_temp_index
ess_rint_chg_map=fliplr(ess_rint_dis_map);% (ohm), no other data available

% module's open-circuit (a.k.a. no-load) voltage, indexed by ess_soc_index and ess_temp_index
ess_voc_map=[xx]/ess_element_per_module; % (V)

% Max current and power when charging/discharging
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_curr_chg_max      = max(max((ess_volt_max-ess_voc_map)./ess_rint_chg_map));
ess_curr_dis_max      = max(max((ess_voc_map-ess_volt_min)./ess_rint_dis_map));
ess_pwr_chg     = max(max((ess_volt_max-ess_voc_map).*ess_volt_max./ess_rint_chg_map));%per cell
ess_pwr_dis     = max(max((ess_voc_map-ess_volt_min).*ess_volt_min./ess_rint_dis_map));%per cell

% battery thermal model
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_therm_on			= xx;                             									% --     0=no ess thermal calculations, 1=do calc's
ess_therm_cp_module	    = xx;                            									% J/kgK  ave heat capacity of module (estimated for NiMH)
ess_temp_reg			= xx;                            									% C      thermostat temp of module when cooling fan comes on
ess_area_mod			= xx*(ess_mass_module/xx)^0.7;  									% --     if module dimensions are unknown, assume rectang shape and scale vs PB25
ess_area_module		    = xx          											% m^2    total module surface area exposed to cooling air (typ rectang module)
ess_flow_air_mod		= xx;                      											% kg/s   cooling air mass flow rate across module (20 cfm=0.01 kg/s at 20 C)
ess_mod_flow_area		= xx;    												% m^2    cross-sec flow area for cooling air per module (assumes 10-mm gap btwn mods)
ess_case_thk			= xx;                   											% m      thickness of module case (typ from Optima)
ess_therm_case_cond	    = xx;                 												% W/mK   thermal conductivity of module case material (typ polyprop plastic - Optima)
ess_speed_air			= ess_flow_air_mod/(1.16*ess_mod_flow_area);						% m/s  ave velocity of cooling air
ess_therm_air_htcoef	= xx*(ess_speed_air/5)^0.8;      									% W/m^2K cooling air heat transfer coef.
ess_therm_res_on		= ((1/ess_therm_air_htcoef)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key on
ess_therm_res_off		= ((1/4)+(ess_case_thk/ess_therm_case_cond))/ess_area_module; % K/W  tot thermal res key off (cold soak)
ess_flow_air_mod		= max(ess_flow_air_mod,0.001);
ess_therm_res_on		= min(ess_therm_res_on,ess_therm_res_off);

clear ess_area_module ess_mod_flow_area ess_case_thk ess_therm_case_cond ess_speed_air ess_therm_air_htcoef ess_area_mod

