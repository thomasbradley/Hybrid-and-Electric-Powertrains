%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: torqconv_over150Nm.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% torque converter													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 10/13/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 							                %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% Xi Wei - 08/09/00  maximum torque before scaling	                %
% Bob Lawrie - 6/1/01 new input data for v2 torconverter model      %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : this file should be run after model.drivetrain.eng.init, model.drivetrain.mc.init			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cpl_spd_idle 			= xx;				% starting engine speed set to 0 or fc_spd_idle
cpl_lock_thresh 		= xx; 			% spd difference < thresh enables lock up
cpl_inertia_in 		    = xx; 			% factor of 20 introduced to conform to data provided by Joe Steiber 
cpl_inertia_out 		= xx; 			% same as above
cpl_pump_spd_thresh 	= xx;


% load steady-state test data for 150K
SR=[0:xx: xx];																					% Speed ratio
TR=[xx];				% Torque ratio
w_in=[xx]*pi/30;		% impeller speed
T_in=ones(1,10)*87.5*4.448/3.281;															    % impeller data based on constant input torque (lb-ft==>Nm)
k_in=w_in./T_in.^.5;																			% K=N/sqrt(T)
cpl_slip_ratio_in_index = [SR xx];
cpl_coeff_in_map = [1./k_in.^2  xx] ;		                % Impeller torque in N-m/(rad/s)^2
cpl_torque_ratio_map = [TR xx];								% Torque ratio

% Lock up info
ptc_lock_map        =  [xx]; % Converter lockup table command
ptc_lock_spd_index  =  [xx]; 
% Unlock info
ptc_unlock_map      =  [xx];% Converter Unlock table
ptc_unlock_spd_index=  [xx]; 	% Converter unlock table speed in m/s

cpl_pump_trq_eff_index = [	xx];% Pump efficiency torque axis in N-m
cpl_pump_spd_eff_index = [	xx];% Pump efficiency Speed axis in rad/s
cpl_pump_eff_map = ...                               % Pump efficiency
    [xx];

cpl_pump_spd_loss_index = cpl_pump_spd_eff_index;
cpl_pump_trq_loss_index = cpl_pump_trq_eff_index;
% Change pump efficiency table into torque loss table
for i=1:size(cpl_pump_trq_loss_index,2)
    for j=1:size(cpl_pump_spd_loss_index,2)
        cpl_pump_trq_loss_map(i,j) = (1-cpl_pump_eff_map(i,j))*cpl_pump_trq_loss_index(i);
    end;
end;

