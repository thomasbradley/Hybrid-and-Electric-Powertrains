%********************************%
%******* Power Conditioner ******%
%********************************%

pc_eff = xx;      % efficiency
pc_mass = xx;
