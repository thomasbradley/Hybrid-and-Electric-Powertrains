%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: fd_empty.m									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% final drive														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 11/05/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 									        %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 				    						%
% A.Rousseau (ANL) - 11/17/99 - add the final loss table calculation%
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


fd_ratio_i_p		= xx;% will be optimized in scaling algorithm
fd_inertia_i_p      = xx;
fd_mass				= xx;
fd_spd_thresh_i 	= xx;

fd_trq_eff_index    = [xx];
fd_spd_eff_index    = [xx];
fd_eff_trq_map      = ones(size(fd_trq_eff_index,2),size(fd_spd_eff_index,2)).* 0.94;

fd_trq_loss_index   = fd_trq_eff_index;
fd_spd_loss_index   = fd_spd_eff_index;
fd_trq_loss_map     = zeros(length(fd_trq_loss_index), length(fd_spd_loss_index));

% create final drive loss tables
for i=1:size(fd_trq_loss_index,2)
   for j=1:size(fd_spd_loss_index,2)
      fd_trq_loss_map(i,j) = (1-fd_eff_trq_map(i,j))*fd_trq_loss_index(i);	
   end
end

% calculate the maximum efficiency 
fd_eff_max=max(max(fd_eff_trq_map));

clear i j 