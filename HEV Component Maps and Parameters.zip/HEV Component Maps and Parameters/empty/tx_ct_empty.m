%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tx_ct_empty.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the	    %
% continuous variable transmission									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)						    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files :                       					%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% University of Maryland - 1995 - Fred Householder under the 		%
% supervision of Dr. David Holloway									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL)- 09/13/99 - creation of a special file for the   %
% clutch															%
% A.Rousseau (ANL)- 10/06/99 - simplification of the variable names	%
% A.Rousseau (ANL) - 11/05/99 - modifed variable dtr_config_switch	%
% (0/1 initialy) .This parameter has now 4 values					%
% A.Rousseau (ANL) - 11/17/99 -add the torque loss table calculation%
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Data were collected at two clamping pressures,one which is usually% 
% used at input torques above 40 ft-lb, and one which is used below %
% 40 ft-lb.  The two clamping conditions have been combined into a  %
% single set of maps. All data corresponding to input torques of    %
% 39.99 ft-lb and below are taken from the low-clamping-pressure    %
% data, where other data are taken from thehigh-clamping-pressure   %
% data set.															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear tx_trq_loss_map

tx_mass 				= xx;
tx_inertia_in_i_p 	    = xx;				% kg m^2
tx_inertia_out_i_p 	    = xx;					% kg m^2
tx_in_ratio_i_p 		= xx;					% Reduction ratio before the pulleys
tx_spd_thr_i 		    = xx;
tx_nb_ratio             = xx;
tx_ratio_map            = [xx];	% total gear ratios (pulley+final gearbox)
tx_tau                  = xx;    %Time to go from min->max ratio or max->min ratio
tx_spd_eff_index        = [xx]*pi/30;	% input speeds in rad/s
tx_trq_eff_index        = xx;	% input torques in N-m

% map corresponding to first element in tx_ratio_index is tx_eff_trq_ratio1_map
tx_eff_trq_ratio1_map=[	xx]';

tx_eff_trq_ratio2_map=[	xx]';

tx_eff_trq_ratio3_map=[xx]';

tx_eff_trq_ratio4_map=[	xx]';

tx_eff_trq_ratio5_map=[	xx]';

% data for the CVT pump
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_pump_displacement            = xx;%m3/tr
tx_length_belt                  = xx;%m
tx_length_between_pulley_axle   = xx;%m
tx_k_safety                     = xx;
tx_angle_flasque                = xx*pi/180;%11 degres
tx_coeff_friction_belt_pulley   = xx;
tx_section_secondary_pulley     = xx;%m2
tx_visquous_coef                = xx;%Nm/rad/s
tx_residual_trq_loss            = xx;

tx_primary_pulley_radius_map = [];
total_pwt_ratio = 1./(fliplr([min(tx_ratio_map):0.1:max(tx_ratio_map)])*tx_in_ratio_i_p*4);%4 default fd ratio
for cpt=total_pwt_ratio
    delta = fzero('angle_pulley',0,optimset('fzero'),tx_length_belt,tx_length_between_pulley_axle,cpt);
    tx_primary_pulley_radius_map(end+1) = (tx_length_belt-2*tx_length_between_pulley_axle*cos(delta))/((pi-2*delta)+(pi+2*delta)/cpt);
end

% calculate the torque losses
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tx_trq_loss_index = tx_trq_eff_index;
tx_spd_loss_index = tx_spd_eff_index;
tx_coeff = tx_trq_eff_index(:)*ones(1,length(tx_spd_eff_index));
for cpt=1:tx_nb_ratio,
    eval(['tx_trq_loss_ratio',num2str(cpt),'_map = (1 - tx_eff_trq_ratio',num2str(cpt),'_map) .* tx_coeff;']);%calculate trq loss per ratio
    tx_trq_loss_map(:,:,cpt) = eval(['tx_trq_loss_ratio',num2str(cpt),'_map']);%create the 3 dimensions (trq, spd, ratio) map for trq loss
end

% calculate the maximum efficiency
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for cpt=1:tx_nb_ratio,
   tx_eff(cpt)=max(max(eval(['tx_eff_trq_ratio',num2str(cpt),'_map'])));
end
tx_eff_max=max(tx_eff);
clear cpt