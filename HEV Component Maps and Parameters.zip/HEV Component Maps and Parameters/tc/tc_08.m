%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: tc_08.m									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% reduction bloc													%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL) - 11/05/99				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 											%
% A.Rousseau (ANL) - 11/17/99 - add the axl1 loss table calculation	%
% Xi Wei - 08/02/00 - maximum efficiency calculation				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tc_ratio_i_p 		= 0.8;
tc_inertia_i_p 	    = 0;
tc_mass 			= 10;
tc_spd_thresh_i 	= 10;

tc_trq_eff_index    = [51.40,52.40,104.7,157.1,209.4,261.8,314.2,366.5,418.9,471.2,523.6];
tc_spd_eff_index    = [0.500,6.000,33.90,67.80,101.7,135.6,169.5,203.4,237.3,271.2,305.1,339];
tc_eff_trq_map      = ones(size(tc_trq_eff_index,2),size(tc_spd_eff_index,2)).*0.94;

tc_trq_loss_index   = tc_trq_eff_index;
tc_spd_loss_index   = tc_spd_eff_index;
tc_trq_loss_map     =  zeros(length(tc_trq_loss_index), length(tc_spd_loss_index));

% create axle1 drive loss tables
for i=1:size(tc_trq_loss_index,2)
   for j=1:size(tc_spd_loss_index,2)
      tc_trq_loss_map(i,j) = (1-tc_eff_trq_map(i,j))*tc_trq_loss_index(i);
   end
end

% calculate the maximum efficiency 
tc_eff_max=max(max(tc_eff_trq_map));
