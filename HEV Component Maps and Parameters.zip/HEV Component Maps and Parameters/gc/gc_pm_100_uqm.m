%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: gc_pm_100_uqm.m							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Permanent Magnet generator model									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: B.Deville (ANL) - 06/06/02				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%     Unique Mobility, Inc.											%
%		425 Corporate Circle										%
%		Golden, CO  80401											%
%		(303)278-2002												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 	:                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%  This data is taken from a data sheet for a 32Kw Unique			%
%  Mobility SR218H brushless permanent magnet motor coupled			%
%  with its companion CA40-300L inverter and scaled to 100kW        %
%  continuous and 160kW peak                				    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gc_inertia_i_p 		    = .1469; 
gc_coeff_regen_i_p 	    = 1;
gc_volt_min_i			= 60; % (V), minimum voltage allowed by the controller and motor
gc_tau_i_p				= .05; % from 0 to 100 % of the torque in 50 ms
gc_str_trq_i_p 	        = 150;							% Torque provided by the generator required to start the engine (when the generator is used as a engine starter device)
gc_spd_opt_i_p	        = 3600 .* c_rpm_radps;
gc_ratio_i_p 	        = 2;
gc_gear_eff_i_p	        = 1;
gc_coeff_regen_i_p      = 1;
gc_mass 				= 191.1; % (kg), mass of motor and controller																		
gc_curr_max				= 300; % (A), maximum current allowed by the controller and motor
gc_spd_base				= 3000*c_rpm_radps;% rad/s

gc_spd_cont_index       = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
gc_trq_cont_map 	    = [468.7500  468.7500  468.7500  468.7500  428.1250  350.0000  281.2500  237.5000  203.1250 187.5000  143.7500  131.2500  131.2500]; % (N*m)

gc_spd_max_index 	    = [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
gc_trq_max_map 	        = [512.0000  512.0000  512.0000  512.0000  512.0000  509.2958  436.5393  381.9719  339.5305 305.5775  254.6479  218.2696  203.7183];  

gc_spd_eff_index 		= [0 1200 1500 2000 2500 3000 3500 4000 4500 5000 6000 7000 7500]* c_rpm_radps;
gc_trq_eff_index 	    = [0   11.3778   56.8889  113.7778  170.6667  227.5556  284.4444  341.3333  398.2222 455.1111  512.0000];
gc_eff_trq_map		=  0.01*[...
60 80.5 85   88   88   86   85   86   80   79   79     
60 80.5 85   88   88   86   85   86   80   79   79
60 81   85   89   89   88   87   86   82   80   79.5
60 80   87   90   90.5 90   89   88   86   85   83
60 78   88   91.5 91.5 91   91   90   89   86   85
60 79   91   92.5 93   92.5 92   91   90   87   87
60 79   93   94   93.5 93   93   92   90   90   90    
60 86   93   94   94   93   92.5 92   92   92   92
60 79   90   92   93   92   91   91   91   91   91
60 79   86   91   92   92   92   92   92   92   92
60 77.5 86   91   92   92   92   92   92   92   92
60 77.5 83   90   90.5 90.5 90.5 90.5 90.5 90.5 90.5
60 77.5 81   90   90   90   90   90   90   90   90];   

gc_pre_calculation