%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: gc_pm_2.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Permanent Magnet generator model									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%     Unique Mobility, Inc.											%
%		425 Corporate Circle										%
%		Golden, CO  80401											%
%		(303)278-2002												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% A.Rousseau (ANL) - 03/02/00 - integration of the gc_tau			%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
% Ben - 01/23/01 -corrections on map and calculation of trp_loss_map%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%  This data is taken from a data sheet for a 32Kw Unique			%
%  Mobility SR218H brushless permanent magnet motor coupled			%
%  with its companion CA40-300L inverter.					    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gc_inertia_i_p 	        = 0.01;						% kg-m^2 
gc_tau_i_p 		        = 0.05; 					    %0 to 100% of the max torque in 50ms
gc_str_trq_i_p 	        = 30;							% Torque provided by the generator required to start the engine (when the generator is used as a engine starter device)
gc_spd_opt_i_p	        = 3600 .* c_rpm_radps;
gc_ratio_i_p 	        = 1;
gc_gear_eff_i_p	        = 1;
gc_coeff_regen_i_p      = 1;
gc_mass 				= 6.5;								% Mass of the motor and controller in Kg
gc_spd_base 		    = 2200 .* c_rpm_radps;		% rad/s

gc_spd_cont_index 	= [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5500 ].*c_rpm_radps;
gc_trq_cont_map 	= [28.5 25 20.4 15.8 11.1 7.8 5.4 3.75 2.43 1.54 0];

gc_spd_max_index = gc_spd_cont_index; % rad/s
gc_trq_max_map = gc_trq_cont_map;

gc_spd_eff_index        = gc_spd_cont_index;% rad/s
gc_trq_eff_index        = [0 5 10 15 20 25 30 35 40 45];% N-m

% Efficiency data was provided; therfore, the motor loss data will be 
% entered as efficiencies and then converted to losses in watts.
gc_eff_trq_map = 0.9*ones(length(gc_spd_eff_index),length(gc_trq_eff_index))

gc_pre_calculation;