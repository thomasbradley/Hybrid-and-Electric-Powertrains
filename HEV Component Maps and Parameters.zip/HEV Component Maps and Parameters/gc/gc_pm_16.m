%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_16.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 16-kW PM induction motor/inverter		    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau - ANL - 12/08/99			    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
% Unique Mobility specification sheet for the DR156s/CR20-150	    %
% motor/controller combination at 180 V, dated 10/1/94				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 										    %
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mc_tau		%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
% Efficiency/loss data appropriate to a 180-V system.				%
% Efficiency/loss grid is very coarse.								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gc_inertia 			    = 0.0208; 
gc_coeff_regen 		    = 1;
gc_volt_min				= 30; % (V), minimum voltage allowed by the controller and motor
gc_tau				= 0.05; % from 0 to 100 % of the torque in 50 ms
gc_str_trq_i_p 	    = 200;	%Torque provided by the generator required to start the engine (when the generator is used as a engine starter device)
gc_mass 					= 8.4+12.2; % (kg), mass of motor and controller																		
gc_curr_max					= 300; % (A), maximum current allowed by the controller and motor
gc_spd_base 				= 1000*c_rpm_radps;% rad/s

gc_spd_cont_index 	        = [0 1000 2000 3000 4000 5000 6000 7500]* c_rpm_radps;
gc_trq_cont_map 	        = [18.3 18.1 17.8 17.6 17.3 17.1 16.8 0.0]*4.448/3.281;

gc_spd_max_index 	        = [0 1000 2000 3000 4000 5000 6000 7500]* c_rpm_radps;
gc_trq_max_map              = 1.45*gc_trq_cont_map; 

gc_spd_eff_index 		    = [0 1000 2000 3000 4000 5000 6000 7500]* c_rpm_radps;
gc_trq_eff_index 	        = [0 40 80 120 160 200 240]*4.448/3.281/12;
gc_eff_trq_map		= [...
	0.1	0.1	    0.1	    0.1	    0.1	    0.1	    0.1
	0.1	0.5	    0.77	0.69	0.78	0.67	0.5
	0.1	0.83	0.88	0.88	0.87	0.86	0.82
	0.1	0.88	0.9	    0.9	    0.9	    0.89	0.88
	0.1	0.87	0.9	    0.91	0.91	0.9	    0.9
	0.1	0.87	0.9	    0.91	0.91	0.9	    0.9
	0.1	0.88	0.9	    0.91	0.92	0.91	0.91
	0.1	0.88	0.9	    0.9	    0.91	0.91	0.91];		


gc_pre_calculation;