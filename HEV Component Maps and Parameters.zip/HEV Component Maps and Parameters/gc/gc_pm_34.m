%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: gc_pm_34.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% Permanent Magnet generator model									%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%     Unique Mobility, Inc.											%
%		425 Corporate Circle										%
%		Golden, CO  80401											%
%		(303)278-2002												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 				: 										%
% A.Rousseau (ANL) - 03/02/00 - integration of the gc_tau			%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
% Ben - 01/23/01 -corrections on map and calculation of trp_loss_map%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remarks : 														%
%  This data is taken from a data sheet for a 32Kw Unique			%
%  Mobility SR218H brushless permanent magnet motor coupled			%
%  with its companion CA40-300L inverter.					    	%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gc_inertia_i_p 	        = 0.0544;						% kg-m^2 
gc_tau_i_p 		        = 0.05; 					    %0 to 100% of the max torque in 50ms
gc_str_trq_i_p 	        = 150;							% Torque provided by the generator required to start the engine (when the generator is used as a engine starter device)
gc_spd_opt_i_p	        = 3600 .* c_rpm_radps;
gc_ratio_i_p 	        = 1;
gc_gear_eff_i_p	        = 1;
gc_coeff_regen_i_p      = 1;
gc_mass 				= 60;								% Mass of the motor and controller in Kg
gc_spd_base 		    = 2200 .* c_rpm_radps;		% rad/s

gc_spd_cont_index       = [    0,1000,1500,2200,2400,3000,3600,3900,4200,4800,5400,6000,6600,7200,7500] .* c_rpm_radps;% rad/s
gc_trq_cont_map         = [150.0,150.0,150.0,150.0,137.6,110.1,91.7,84.7,78.6,68.8,61.2,55.0,50.0,45.9,44.0];% N-m

gc_spd_max_index = gc_spd_cont_index; % rad/s
gc_trq_max_map = gc_trq_cont_map;   %% N-m from INEL Prius generator file

gc_spd_eff_index        = gc_spd_cont_index;% rad/s
gc_trq_eff_index        = [0,3,13,23,35,45,55,66,77,87,100,108,118,129,141,150];% N-m

% Efficiency data was provided; therfore, the motor loss data will be 
% entered as efficiencies and then converted to losses in watts.
gc_eff_trq_map = ...    
 [ .0, .00, .00, .00, .00, .00, .00, .00, .00, .00, .00, .00, .00, .00, .00, .00;...
   .0, .83, .87, .88, .88, .87, .87, .86, .86, .87, .86, .82, .80, .80, .80, .80;...
   .0, .84, .88, .89, .89, .89, .88, .88, .87, .87, .86, .84, .82, .81, .80, .80;...
   .0, .84, .88, .89, .89, .90, .90, .89, .88, .87, .86, .84, .83, .84, .82, .81;...
   .0, .86, .90, .91, .91, .91, .91, .91, .91, .90, .89, .88, .87, .86, .85, .83;...
   .0, .89, .92, .92, .93, .93, .92, .92, .92, .91, .91, .90, .89, .89, .89, .89;...
   .0, .89, .94, .94, .93, .94, .93, .93, .93, .93, .92, .92, .92, .92, .92, .92;...
   .0, .91, .94, .94, .93, .94, .93, .93, .92, .92, .92, .92, .92, .92, .92, .92;...
   .0, .90, .93, .93, .93, .93, .92, .92, .92, .92, .92, .92, .92, .92, .92, .92;...
   .0, .82, .89, .91, .91, .92, .91, .91, .91, .91, .91, .91, .91, .91, .91, .91;...
   .0, .80, .90, .91, .91, .92, .92, .92, .92, .92, .92, .92, .92, .92, .92, .92;...
   .0, .80, .89, .91, .91, .92, .92, .92, .92, .92, .92, .92, .92, .92, .92, .92;...
   .0, .79, .87, .90, .91, .91, .91, .91, .91, .91, .91, .91, .91, .91, .91, .91;...
   .0, .79, .86, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90;...
   .0, .79, .88, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90, .90 ];

gc_pre_calculation;