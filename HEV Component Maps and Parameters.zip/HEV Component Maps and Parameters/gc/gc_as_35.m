%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: gc_as_35.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: initialize the parameters used in the		%
% asynchronous generator model										%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)							%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 	Mutasim Salman (General Motors)			%
%     							(810)986-1238						%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			: 								    		%
% A.Rousseau (ANL) - 03/02/00 - integration of the gc_tau			%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
% Ben - 01/23/01 -corrections on map and calculation of trp_loss_map%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Value based on an estimate calculated from the rotor length of
% 5", rotor diameter of 6.164", and a rotor mass of 39Kg.  Inertia
% given by I = 0.5*m*r^2 kg-m^2
gc_inertia_i_p			= 0.03;		% kg-m^2; recommended by Mutasim Salman (GM); 03/25/1997
gc_tau_i_p				= 0.05; 	%0 to 100% of the max torque in 50ms
gc_str_trq_i_p			= 200;		% Torque provided by the generator required to start the engine (when the generator is used as a engine starter device)
gc_spd_opt_i_p			= .78 .* 13000 .* c_rpm_radps;% rad/s (For operating APU, choose the optimum spd at which the generator should run for best eff)
gc_gear_eff_i_p		    = 1;
gc_ratio_i_p			= 1;%select the gear ratio based upon the optimum operating spds of the generator and fuel converter
gc_coeff_regen_i_p 	    = 1;
gc_mass 				= 115;		% Mass of the motor and controller in Kg
gc_spd_base 			= 3200 .*c_rpm_radps;% rad/s

gc_spd_cont_index       = [ .00,.07,.21,.36,.50,.64,.78,.83,1.00] .* 13000 .* c_rpm_radps;% rad/s (entered as percent of max then multiplied by max)
gc_trq_cont_map         = [123.6,123.6,123.6,72.1,51.9,40.6,33.3,31.3,25.9];% N-m

gc_spd_max_index = gc_spd_cont_index; % rad/s
gc_trq_max_map = gc_trq_cont_map;   %% N-m from INEL Prius generator file

gc_spd_eff_index        = gc_spd_cont_index;
gc_trq_eff_index        = [ .00,.03,.06,.09,.12,.15,.18,.27,.36,.45,.55,.64,.73,.82,.91,1.00] .* 330;

% Efficiency data was provided; therfore, the motor loss data will be 
% entered as efficiencies and then converted to losses in watts.
gc_eff_trq_map = ...    
[0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00; ...
 0.00, 0.87, 0.88, 0.88, 0.87, 0.87, 0.86, 0.85, 0.83, 0.82, 0.81, 0.80, 0.79, 0.78, 0.77, 0.77; ...
 0.00, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.91, 0.91, 0.91, 0.90, 0.90, 0.90, 0.89, 0.89; ...
 0.00, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.93, 0.92, 0.92, 0.92, 0.92, 0.91, 0.91, 0.91; ...
 0.00, 0.93, 0.94, 0.94, 0.94, 0.94, 0.93, 0.93, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.91, 0.91, 0.91, 0.91, 0.91, 0.91; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92; ...
 0.00, 0.94, 0.94, 0.94, 0.94, 0.94, 0.93, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92, 0.92];

gc_pre_calculation;
