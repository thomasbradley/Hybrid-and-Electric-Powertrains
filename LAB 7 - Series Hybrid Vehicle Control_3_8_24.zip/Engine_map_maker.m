% clear 
% close all
c_rpm_radps = (2*pi)/60;
eng_si_1900_63_saturn_HOT


figure; plot(eng_spd_max_hot_index, eng_trq_max_hot_map)
xlabel('Engine Speed, rad/sec'); ylabel('Engine Torque, Nm')


hold on ; contourf(eng_spd_fuel_hot_index, eng_trq_fuel_hot_index,eng_fuel_hot_map', 10)
xlabel('Engine Speed, rad/sec'); ylabel('Engine Torque, Nm'); title('Fuel Flow Rate')


figure; plot(eng_spd_max_hot_index, eng_trq_max_hot_map,'LineWidth',6)
xlabel('Engine Speed, rad/sec'); ylabel('Engine Torque, Nm')
bsfc_map = (eng_fuel_hot_map*3600*1000) ./ ((eng_spd_fuel_hot_index' * eng_trq_fuel_hot_index)/1000)
hold on  ; [c,h]=contour(eng_spd_fuel_hot_index, eng_trq_fuel_hot_index,bsfc_map', 20); clabel(c,h)


efficiency_map = (bsfc_map * 11.8/1000).^(-1) ; %11.8 kwh/kg = Qlhv of gas, 1000 g/kg
figure ; [c,h]=contour(eng_spd_fuel_hot_index, eng_trq_fuel_hot_index,efficiency_map', 30); clabel(c,h)
% close all
legend('Maximum Torque Line','Efficiency Map')











