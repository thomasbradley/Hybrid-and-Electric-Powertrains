
% Series Electric Vehicle Init File
clc
clear variables

%Drive Cycle
%load Drive_Cycles/Schedule_FU505_Ten_Times.mat
load Schedule_FU505.mat;
%load Drive_Cycles/Schedule_Boston_Cab.mat;

%Vehicle Parameters
Vehicle_Mass = 1200;                %Vehicle mass, kg
Vehicle_Tire_Radius = 0.3;          %Tire radius, m
Vehicle_DShaft_Inertia = 1.5e-3;    %Driveshaft Inertia, kg m^2
Vehicle_Dr_HShaft_Inertia = 1.5e-3; %Driver Halfshaft Inertia, kg m^2
Vehicle_Pa_HShaft_Inertia = 1.5e-3; %Passenger Halfshaft Inertia, kg m^2
Vehicle_Rear_Diff_Ratio = 3.73;        %Rear Diff Ratio

%MG Parameters
mc_v2_pm_escape 
MG_Inertia = 0.1;                   %MG Moment of inertia in kg m^2
MGA_Max_Torque = 200;               %MGA Max Torque, Nm
MGB_Max_Torque = 200;               %MGB Max Torque, Nm

%Logging Parameters
Logging_Sample_Time_s = 1;

%Battery Parameters
Battery_Voltage = 366;                  %Battery Open Circuit Voltage, V
Battery_Resistance = 0.4;           %Ohms
Battery_Capacity = 8.5;             %Battery Max Capacity, Ahr
Battery_Initial_SOC = 0.7;          %Battery Initial State of Charge (SOC)

%Controller Parameters
battery_soc_low = 0.6;              %Battery SOC Low Value
battery_soc_high = 0.7;             %Battery SOC High Value

%Engine Parameters
% load Component_Data/Engine_Diesel_Data.mat;
Engine_Max_Torque = 200;            %Engine Max Torque, Nm
Engine_Inertia = 0.12;              %Engine Inertia, kg m^2


TC_data = [0.000	0.100	0.200	0.300	0.400	0.500	0.600	0.700	0.750	0.800	0.825	0.850	0.855	0.860	0.865	0.870	0.875	0.880	0.885	0.890	0.895	0.900	0.905	0.910	0.915	0.920	0.925	0.930	0.935	0.940	0.945	0.950	0.960	0.970	0.980	0.983	0.985	0.988	0.990	0.993	0.995	0.998	1.00495	1.00512	1.00531	1.00552	1.00574	1.00600	1.00646	1.00690	1.00705	1.00751	1.00797	1.00852	1.00917	1.01019	1.01134	1.01272	1.01423	1.01611	1.01819	1.02071	1.02404	1.02844	1.03339	1.03719	1.04172	1.04763	1.05405	1.06166	1.07061	1.08170	1.09374	1.10845	1.12694	1.14809	1.17379	1.20474	1.24071	1.28322	1.33630	1.39997	1.48222	1.70026	2.02556	2.58443	3.71170	7.08290
1.840	1.740	1.660	1.560	1.460	1.360	1.270	1.190	1.150	1.110	1.080	1.057	1.050	1.045	1.040	1.033	1.028	1.025	1.020	1.015	1.009	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1.000	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1	1
6.1066	6.2906	6.4720	6.6729	6.9192	7.1668	7.3878	7.3878	7.2051	6.8475	6.5602	6.2801	6.2078	6.1569	6.0966	6.0372	5.9787	5.9211	5.8642	5.7989	5.7438	5.6805	5.3958	5.0483	4.7061	4.3854	4.0637	3.7664	3.4448	3.1369	2.83966	2.53936	2.06284	1.47499	0.96218	0.83757	0.71439	0.59265	0.47235	0.35348	0.23605	0.12006	0.070939966	0.073777485	0.076439053	0.078939342	0.081178945	0.084858185	0.087832403	0.092050721	0.096658844	0.10136607	0.106512623	0.112190169	0.119969311	0.131311438	0.143720471	0.158638188	0.174700023	0.193997734	0.216315845	0.241321621	0.271340153	0.306828976	0.340957449	0.36612249	0.393075053	0.425424618	0.458197937	0.495377427	0.537291629	0.587503053	0.641855788	0.704440366	0.777627356	0.86163696	0.959629719	1.075847851	1.212485836	1.371975538	1.571632283	1.821946827	2.151893884	3.100036329	4.854034397	8.629394484	19.38340916	77.0427103
]
