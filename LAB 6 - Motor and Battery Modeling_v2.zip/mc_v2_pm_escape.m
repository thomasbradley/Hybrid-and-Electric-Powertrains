%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Name of the file 		: mc_pm_prius.m								%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description			: 						    				%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Written by 			: A.Rousseau (ANL)			    			%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other necessary files : 											%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Data provided by 		: 											%
%  The following data was provided for USCAR from:					%
%       Unique Mobility, Inc.											%
%		425 Corporate Circle										%
%		Golden, CO  80401											%
%		(303)278-2002												%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Modified by 			:											%
% A.Rousseau (ANL) - 03/02/00 - incorporate the new data mot_tau	%
% P. Sharer (ANL) - 03/24/00 - variable names changed				%
% Xi Wei - 08/02/00 - maximum power and efficiency calculation		%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Remark : 															%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
c_rpm_radps = 3.14/30
mc_tau_i_p				= 0.05;                 % from 0 to 100 % of the torque in 50 ms
mc_inertia  			= 0.0226;               % kg-m^2 
mc_coeff_regen_i_p 	    = 1;
mc_volt_min_i			= 0;                  % (V), minimum voltage allowed by the controller and motor
mc_mass 				= 38.1;                 % Mass of the motor and controller in Kg
mc_spd_base 			= 1000 *c_rpm_radps;    % rad/s

mc_spd_cont_index       = [0,2754,3000,3500,4000,4500,5000,5500,6000,6500,7000,7500,8000,8500,9000,9500,10000,10500,11000,11500,12000,12500,13000]*c_rpm_radps;% rad/s
mc_trq_cont_map         = [205.3,205.3,202.3,173.5,149.9,130,114.1,103.5,93.7,89.6,86.6,78.9,72.4,66.7,61.5,57.7,54.2,48,42.3,38.7,35.6,33.3,30];% N-m

mc_spd_max_index        = mc_spd_cont_index;    % rad/s
mc_trq_max_map          = [205.3,205.3,202.3,173.5,149.9,130,114.1,103.5,93.7,89.6,86.6,78.9,72.4,66.7,61.5,57.7,54.2,48,42.3,38.7,35.6,33.3,30];  %from Ford SMT
mc_volt_max_index       = [216	240	288	350];   % Volts
mc_volt_coeff_max_map   = [ 1.0064	1.0064	1.0065	1.0064	1.0040	0.9699	0.9333	0.8807	0.8474	0.7868	0.7258	0.6639	0.6375	0.6366	0.6336	0.6269	0.6199	0.6316	0.7541	0.7545	0.7556	0.7538	0.7533
							1.0294	1.0294	1.0294	1.0284	1.0262	1.0201	1.0123	0.9779	0.9637	0.9007	0.8364	0.7643	0.7324	0.7268	0.7182	0.6966	0.6721	0.6860	0.8203	0.8217	0.8202	0.8198	0.8200
							1.0064	1.0064	1.0065	1.0064	1.0054	1.0046	1.0018	0.9962	1.0000	1.0000	0.9977	0.9207	0.8927	0.8977	0.8978	0.8932	0.8842	0.8711	1.0000	1.0000	1.0000	1.0000	1.0000
							1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000	1.0000];%[Nm/Nm]
                        
%mc_volt_coeff_max_map   = ones(size(mc_volt_coeff_max_map))
mc_pwr_loss_spd_index   = [50,500,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000]*c_rpm_radps;% rad/s
mc_pwr_loss_trq_index   = fliplr([215,200,180,160,140,120,100,80,60,40,20,0,-20,-40,-60,-80,-100,-120,-140,-160,-180,-200,-215]);% N-m
mc_pwr_loss_map         = flipud([  7656,7799,8368,8566,8764,8962,9160,9358,9556,9754,9952,10150,10348,10546,10744;
									6770,6863,7628,7850,8072,8294,8516,8738,8960,9182,9404,9626,9848,10070,10292;
									5088,5213,5828,5999,6383,6767,7151,7535,7919,8303,8687,9071,9455,9839,10223;
									4297,4340,4785,4974,5204,5434,5664,5894,6124,6354,6584,6814,7044,7274,7504;
									3455,3523,3882,4063,4241,4419,4597,4775,4953,5131,5309,5487,5665,5843,6021;
									2817,2857,3103,3255,3561,4185,4809,5433,6057,6681,7305,7929,8553,9177,9801;
									2119,2210,2308,2508,2663,3166,4609,5000,5391,5782,6173,6564,6955,7346,7737;
									1628,1704,1789,1942,2040,2358,2790,4794,5000,5206,5412,5618,5824,6030,6236;
									1242,1313,1362,1473,1535,1649,2042,2591,3511,5000,6489,7978,9467,10956,12445;
									776,850,917,1050,1139,1183,1280,1557,2307,3323,3911,4499,5087,5675,6263;
									444,494,520,589,664,639,790,866,1366,1269,1387,1498,1997,2710,3543;
									121,139,157,159,194,187,261,290,518,439,500,529,755,1044,1381;
									495,456,428,355,454,255,602,599,711,910,906,1374,1791,1910,2475;
									714,736,761,797,919,1001,1124,1504,1878,2276,3130,3984,4838,5692,6546;
									1157,1173,1195,1192,1301,1574,1646,2202,3466,4730,5994,7258,8522,9786,11050;
									1462,1519,1594,1717,1839,1920,2545,3847,5149,6451,7753,9055,10357,11659,12961;
									2009,2065,2135,2233,2492,2683,4337,5991,7645,9299,10953,12607,14261,15915,17569;
									2572,2603,2860,2964,3185,4315,5445,6575,7705,8835,9965,11095,12225,13355,14485;
									3304,3354,3575,3752,4036,6549,9062,11575,14088,16601,19114,21627,24140,26653,29166;
									3971,4035,4393,4585,4908,5231,5554,5877,6200,6523,6846,7169,7492,7815,8138;
									5041,5101,5449,5699,6217,6735,7253,7771,8289,8807,9325,9843,10361,10879,11397;
									5830,5977,6448,6524,6600,6676,6752,6828,6904,6980,7056,7132,7208,7284,7360;
									7148,7134,7461,7454,7447,7440,7433,7426,7419,7412,7405,7398,7391,7384,7377]);

mc_spd_eff_index    = [50,500,1000,2000,3000,4000,5000,6000,7000,8000,9000,10000,11000,12000,13000]*c_rpm_radps;
mc_trq_eff_index    = fliplr([215,200,180,160,140,120,100,80,60,40,20,0]);
mc_eff_trq_map      = ((mc_trq_eff_index'*mc_spd_eff_index)-mc_pwr_loss_map([12:23],[1:length(mc_spd_eff_index)]))./(mc_trq_eff_index'*mc_spd_eff_index);



for I = 1:7,
   for J = 1:15,
      if(mc_eff_trq_map(I,J) < 0 | isinf(mc_eff_trq_map(I,J))) 
         mc_eff_trq_map(I,J) = 0;
      end
   end
end
mc_eff_trq_map = mc_eff_trq_map';


%mc_pwr_prop_map = mc_pwr_loss_map([7:13],:)';
%mc_pwr_regen_map = fliplr(mc_pwr_loss_map([1:7],:)');
mc_pwr_prop_map = mc_pwr_loss_map([12:23],:);%  data is adjusted in excel file to get monotonicity in every row.  error was resulting in filling in blanks with 10000's.  function in torque generation block in the powertrain constraints did not like non monotonically increasing rows


mc_pwr_regen_map = mc_pwr_loss_map([1:12],:);

% maximum and minimum calculations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_spd_cont_index_max 	= max(mc_spd_cont_index);                           % rad/s
mc_trq_cont_map_max 	= max(mc_trq_cont_map);                             % N-m
mc_pwr_cont_map_max 	= max(mc_spd_cont_index .* mc_trq_cont_map);        % Max motor power rating for road demand calculation

mc_spd_max_index_max 	= max(mc_spd_max_index);                            % rad/s
mc_trq_max_map_max 		= max(mc_trq_max_map);                              % N-m
mc_pwr_max_map_max 		= max(mc_spd_max_index .* mc_trq_max_map);          % Max motor power rating for road demand calculation

mc_pwr_max				= mc_pwr_max_map_max;                               % calculate maximum power (Watts)
mc_eff_max				= max(max(mc_eff_trq_map));                         % calculate the maximum efficiency

mc_curr_max             = 250.00;                                              % A, MC inverter current limit

% Initializations
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mc_cmd_hist_init             = 0;
mc_curr_hist_init            = 0;
mc_volt_hist_init            = mc_volt_min_i; 
mc_trq_hist_init             = 0; 
mc_spd_hist_init             = 0; 
mc_pwr_hist_init             = 0; 
mc_pwr_loss_hist_init        = 0; 
mc_temp_coeff_hist_init      = 0;


