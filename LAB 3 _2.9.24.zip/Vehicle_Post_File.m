% Post Processing

% Constants
Fuel_Heating_Value_B20 = 133393.1102;               %BTU/gal
Fuel_Heating_Value_RFG = 114871.7446;               %BTU/gal

% Calculations
Fuel_Consumed = Engine_Fuel_Consumed_grams(end);    %grams
Distance_Traveled = Vehicle_Distance_miles(end);    %miles

delta_SOC = Battery_SOC(end)-Battery_Initial_SOC;   %non-d
Amp_Hours_Consumed = delta_SOC*Battery_Capacity;    %amp hours
Electrical_Energy = Amp_Hours_Consumed*Battery_OCV; %Watt hours
Conversion_Efficiency = 0.25;                       %ANL data
Electrical_Energy_BTU = (Electrical_Energy/Conversion_Efficiency)*3.412;

Fuel_Consumed_B20_Gallons = Fuel_Consumed/3215;     %gallons
Fuel_Energy_BTU = Fuel_Consumed_B20_Gallons*Fuel_Heating_Value_B20;

Total_Energy_Consumed = Fuel_Energy_BTU-Electrical_Energy_BTU;  %BTU
Fuel_Consumed_RFG_Gal = Total_Energy_Consumed/Fuel_Heating_Value_RFG;
MPGGE_RFG_wSOC = Distance_Traveled/Fuel_Consumed_RFG_Gal;
MPG_Diesel = Distance_Traveled/Fuel_Consumed_B20_Gallons;


msg1=sprintf('            Simulation Results \n\n');
msg2=sprintf('Total Distance Traveled (miles)           %g \n',Distance_Traveled);
msg3=sprintf('Total Fuel Consumed (gal)                   %g \n',Fuel_Consumed_B20_Gallons);
msg4=sprintf('Fuel Energy Consumed (BTU)             %g \n',Fuel_Energy_BTU);
msg5=sprintf('Electrical Energy Consumed (BTU)    %g \n',Electrical_Energy_BTU);
msg6=sprintf('MPGGE with SOC Correction              %g \n',MPGGE_RFG_wSOC);
msg7=sprintf('MPG Diesel Only                                 %g \n',MPG_Diesel);

msg=[msg1,msg2,msg3,msg4,msg5,msg6,msg7];
h=msgbox(msg);

