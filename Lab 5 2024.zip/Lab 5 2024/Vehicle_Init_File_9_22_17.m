% Series Electric Vehicle Init File
clc
clear variables

%Drive Cycle
%load Drive_Cycles/Schedule_FU505_Ten_Times.mat
load Schedule_FU505.mat;
%load Drive_Cycles/Schedule_Boston_Cab.mat;

%Vehicle Parameters
Vehicle_Mass = 1200;                %Vehicle mass, kg
Vehicle_Tire_Radius = 0.3;          %Tire radius, m
Vehicle_DShaft_Inertia = 1.5e-3;    %Driveshaft Inertia, kg m^2
Vehicle_Dr_HShaft_Inertia = 1.5e-3; %Driver Halfshaft Inertia, kg m^2
Vehicle_Pa_HShaft_Inertia = 1.5e-3; %Passenger Halfshaft Inertia, kg m^2
Vehicle_Rear_Diff_Ratio = 3.73;        %Rear Diff Ratio

%MG Parameters
% load Component_Data\MG_Data.mat;
MG_Inertia = 0.1;                   %MG Moment of inertia in kg m^2
MGA_Max_Torque = 200;               %MGA Max Torque, Nm
MGB_Max_Torque = 200;               %MGB Max Torque, Nm

%Logging Parameters
Logging_Sample_Time_s = 1;

%Battery Parameters
Battery_Voltage = 366;                  %Battery Open Circuit Voltage, V
% load Component_Data\Battery_Data.mat;
Battery_Resistance = 0.4;           %Ohms
Battery_Capacity = 8.5;             %Battery Max Capacity, Ahr
Battery_Initial_SOC = 0.7;          %Battery Initial State of Charge (SOC)

%Controller Parameters
battery_soc_low = 0.6;              %Battery SOC Low Value
battery_soc_high = 0.7;             %Battery SOC High Value

%Engine Parameters
% load Component_Data/Engine_Diesel_Data.mat;
Engine_Max_Torque = 200;            %Engine Max Torque, Nm
Engine_Inertia = 0.12;              %Engine Inertia, kg m^2

